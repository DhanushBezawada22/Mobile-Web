// models/Coupon.js
import mongoose from 'mongoose';

const CouponSchema = new mongoose.Schema(
  {
    code: {
      type: String,
      required: [true, 'Please add a coupon code'],
      unique: true,
      trim: true,
      uppercase: true,
    },
    type: {
      type: String,
      enum: ['percentage', 'fixed'],
      required: [true, 'Please specify coupon type'],
    },
    value: {
      type: Number,
      required: [true, 'Please add a coupon value'],
      min: [0, 'Value must be positive'],
    },
    minPurchase: {
      type: Number,
      default: 0,
    },
    maxDiscount: {
      type: Number,
      default: null,
    },
    startDate: {
      type: Date,
      required: [true, 'Please add a start date'],
      default: Date.now,
    },
    endDate: {
      type: Date,
      required: [true, 'Please add an end date'],
    },
    isActive: {
      type: Boolean,
      default: true,
    },
    usageLimit: {
      type: Number,
      default: null,
    },
    usedCount: {
      type: Number,
      default: 0,
    },
    applicableProducts: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Product',
      },
    ],
    applicableCategories: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Category',
      },
    ],
    applicableVendors: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Vendor',
      },
    ],
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
  },
  { timestamps: true }
);

// Check if the coupon is valid based on date and usage
CouponSchema.methods.isValid = function() {
  const now = new Date();
  
  // Check if current date is between start and end dates
  if (now < this.startDate || now > this.endDate) {
    return false;
  }
  
  // Check if coupon is active
  if (!this.isActive) {
    return false;
  }
  
  // Check usage limit if it exists
  if (this.usageLimit !== null && this.usedCount >= this.usageLimit) {
    return false;
  }
  
  return true;
};

export default mongoose.model('Coupon', CouponSchema);