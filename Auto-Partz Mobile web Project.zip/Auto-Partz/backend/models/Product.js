// models/Product.js
import mongoose from 'mongoose';

const ProductSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Please add a product name'],
      trim: true,
      maxlength: [100, 'Product name cannot be more than 100 characters'],
    },
    description: {
      type: String,
      required: [true, 'Please add a description'],
    },
    price: {
      type: Number,
      required: [true, 'Please add a price'],
      min: [0, 'Price must be positive'],
    },
    originalPrice: {
      type: Number,
      min: [0, 'Price must be positive'],
    },
    images: {
      type: [String],
      default: ['default-product.jpg'],
    },
    quantity: {
      type: Number,
      required: [true, 'Please add a quantity'],
      min: [0, 'Quantity cannot be negative'],
      default: 0,
    },
    category: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Category',
      required: [true, 'Please add a category'],
    },
    subcategory: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Subcategory',
    },
    brand: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Brand',
      required: [true, 'Please add a brand'],
    },
    vendor: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Vendor',
      required: [true, 'Please add a vendor'],
    },
    vehicleType: {
      type: String,
      enum: ['car', 'bike', 'universal'],
      required: [true, 'Please specify vehicle type'],
    },
    vehicleModel: {
      type: String,
      required: [true, 'Please specify vehicle model'],
    },
    isAvailable: {
      type: Boolean,
      default: true,
    },
    sku: {
      type: String,
      unique: true,
    },
    specifications: {
      type: Object,
      default: {},
    },
    rating: {
      type: Number,
      min: 0,
      max: 5,
      default: 0,
    },
    numReviews: {
      type: Number,
      default: 0,
    },
    featured: {
      type: Boolean,
      default: false,
    },
  },
  { 
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true }
  }
);

// Create product SKU before saving
ProductSchema.pre('save', async function(next) {
  if (!this.sku) {
    // Generate SKU based on brand, category and unique identifier
    const prefix = this.brand.toString().substring(0, 3).toUpperCase();
    const timestamp = Date.now().toString().substring(8, 13);
    this.sku = `${prefix}${timestamp}`;
  }
  next();
});

// Cascade delete reviews when a product is deleted
ProductSchema.pre('remove', async function(next) {
  await this.model('Review').deleteMany({ product: this._id });
  next();
});

// Reverse populate with reviews
ProductSchema.virtual('reviews', {
  ref: 'Review',
  localField: '_id',
  foreignField: 'product',
  justOne: false
});

export default mongoose.model('Product', ProductSchema);