// models/Vendor.js
import mongoose from 'mongoose';

const VendorSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    shopName: {
      type: String,
      required: [true, 'Please add a shop name'],
      unique: true,
      trim: true,
      maxlength: [50, 'Shop name cannot be more than 50 characters'],
    },
    description: {
      type: String,
      required: [true, 'Please add a description'],
      maxlength: [500, 'Description cannot be more than 500 characters'],
    },
    phone: {
      type: String,
      maxlength: [20, 'Phone number cannot be longer than 20 characters'],
    },
    address: {
      type: String,
      required: [true, 'Please add an address'],
    },
    isVerified: {
      type: Boolean,
      default: false,
    },
    logo: {
      type: String,
      default: 'default-shop.jpg',
    },
    specialties: {
      type: [String],
      default: [],
    },
    brands: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Brand'
    }],
  },
  { timestamps: true }
);

export default mongoose.model('Vendor', VendorSchema);