// models/Brand.js
import mongoose from 'mongoose';
import slugify from 'slugify';

const BrandSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Please add a brand name'],
      unique: true,
      trim: true,
      maxlength: [50, 'Brand name cannot be more than 50 characters'],
    },
    slug: String,
    description: {
      type: String,
      maxlength: [500, 'Description cannot be more than 500 characters'],
    },
    logo: {
      type: String,
      default: 'default-brand.jpg',
    },
    website: {
      type: String,
    },
  },
  { timestamps: true }
);

// Create brand slug from the name
BrandSchema.pre('save', function (next) {
  this.slug = slugify(this.name, { lower: true });
  next();
});

export default mongoose.model('Brand', BrandSchema);