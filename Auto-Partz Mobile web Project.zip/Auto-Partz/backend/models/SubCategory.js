// models/Subcategory.js
import mongoose from 'mongoose';
import slugify from 'slugify';

const SubcategorySchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Please add a subcategory name'],
      trim: true,
      maxlength: [50, 'Subcategory name cannot be more than 50 characters'],
    },
    slug: String,
    category: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Category',
      required: true,
    },
    description: {
      type: String,
      maxlength: [500, 'Description cannot be more than 500 characters'],
    },
  },
  { timestamps: true }
);

// Create subcategory slug from the name
SubcategorySchema.pre('save', function (next) {
  this.slug = slugify(this.name, { lower: true });
  next();
});

// Make sure category and name combination is unique
SubcategorySchema.index({ category: 1, name: 1 }, { unique: true });

export default mongoose.model('Subcategory', SubcategorySchema);