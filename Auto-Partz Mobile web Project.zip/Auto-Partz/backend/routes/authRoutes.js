// routes/authRoutes.js
import express from 'express';
import {
  register,
  login,
  logout,
  getMe,
  updateDetails,
  updatePassword,
} from '../controllers/authController.js';
import { protect } from '../middleware/auth.js';
//import passport from '../config/passport.js';

const router = express.Router();

// Google OAuth routes
// router.get(
//   '/google',
//   passport.authenticate('google', { scope: ['profile', 'email'] })
// );

// router.get(
//   '/google/callback',
//   passport.authenticate('google', { failureRedirect: '/login' }),
//   (req, res) => {
//     // Create token
//     const token = req.user.getSignedJwtToken();
//     res.redirect(`${process.env.FRONTEND_URL}/oauth-success?token=${token}`);
//   }
// );

router.post('/register', register);
router.post('/login', login);
router.get('/logout', logout);
router.get('/me', protect, getMe);
router.put('/updatedetails', protect, updateDetails);
router.put('/updatepassword', protect, updatePassword);

export default router;