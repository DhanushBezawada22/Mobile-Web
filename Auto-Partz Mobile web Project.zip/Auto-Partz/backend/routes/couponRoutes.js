// routes/couponRoutes.js
import express from 'express';
import {
  getCoupons,
  getCoupon,
  createCoupon,
  updateCoupon,
  deleteCoupon,
  validateCoupon,
  getVendorCoupons,
} from '../controllers/couponController.js';
import { protect, authorize } from '../middleware/auth.js';

const router = express.Router();

// Public routes
router.post('/validate', validateCoupon);

// Protected routes
router.use(protect);

// Vendor routes
router.get('/vendor', authorize('vendor'), getVendorCoupons);

// Vendor and admin routes
router.post('/', authorize('vendor', 'admin'), createCoupon);
router.put('/:id', authorize('vendor', 'admin'), updateCoupon);
router.delete('/:id', authorize('vendor', 'admin'), deleteCoupon);

// Admin routes
router.get('/', authorize('admin'), getCoupons);
router.get('/:id', authorize('admin', 'vendor'), getCoupon);

export default router;