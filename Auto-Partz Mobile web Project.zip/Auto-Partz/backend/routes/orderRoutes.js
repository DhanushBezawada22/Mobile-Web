// routes/orderRoutes.js
import express from 'express';
import {
  createOrder,
  getOrders,
  getMyOrders,
  getVendorOrders,
  getOrderById,
  updateOrderStatus,
  updateOrderToPaid,
} from '../controllers/orderController.js';
import { protect, authorize } from '../middleware/auth.js';

const router = express.Router();

// Protected routes
router.use(protect);

// Customer routes
router.post('/', authorize('customer'), createOrder);
router.get('/myorders', authorize('customer'), getMyOrders);

// Vendor routes
router.get('/vendor', authorize('vendor'), getVendorOrders);

// Admin routes
router.get('/', authorize('admin'), getOrders);
router.put('/:id/pay', authorize('admin'), updateOrderToPaid);

// Shared routes
router.get('/:id', authorize('customer', 'vendor', 'admin'), getOrderById);
router.put('/:id/status', authorize('vendor', 'admin'), updateOrderStatus);

export default router;