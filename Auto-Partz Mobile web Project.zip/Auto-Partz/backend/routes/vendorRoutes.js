// routes/vendorRoutes.js
import express from 'express';
import {
  registerVendor,
  getVendors,
  getAllVendors,
  getVendor,
  updateVendor,
  deleteVendor,
  verifyVendor,
  getVendorProducts,
  uploadVendorLogo,
  getVendorByUser,
} from '../controllers/vendorController.js';
import { protect, authorize } from '../middleware/auth.js';
import { upload } from '../middleware/upload.js';

const router = express.Router();

// Public routes
router.get('/', getVendors);
router.get('/:id', getVendor);
router.get('/user/:userId', getVendorByUser);
router.get('/:id/products', getVendorProducts);

// Protected routes
router.use(protect);

// Customer and above can register as vendor
router.post('/', authorize('customer', 'vendor', 'admin'), registerVendor);

// Vendor and admin can update vendor
router.put('/:id', authorize('vendor', 'admin'), updateVendor);
router.put(
  '/:id/logo',
  authorize('vendor', 'admin'),
  upload.single('logo'),
  uploadVendorLogo
);

// Admin only routes
router.use(authorize('admin'));
router.get('/admin/all', getAllVendors);
router.put('/:id/verify', verifyVendor);
router.delete('/:id', deleteVendor);

export default router;