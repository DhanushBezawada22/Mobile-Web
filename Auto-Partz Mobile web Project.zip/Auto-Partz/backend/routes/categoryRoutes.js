// routes/categoryRoutes.js
import express from 'express';
import {
  getCategories,
  getCategory,
  createCategory,
  updateCategory,
  deleteCategory,
  createSubcategory,
  getSubcategories,
} from '../controllers/categoryController.js';
import { protect, authorize } from '../middleware/auth.js';
import { upload } from '../middleware/upload.js';

const router = express.Router();

// Public routes
router.get('/', getCategories);
router.get('/:id', getCategory);
router.get('/:categoryId/subcategories', getSubcategories);

// Admin routes
router.use(protect);
router.use(authorize('admin'));

router.post('/', createCategory);
router.post('/:categoryId/subcategories', createSubcategory);
router.put('/:id', updateCategory);
router.delete('/:id', deleteCategory);

export default router;