// File structure (organized in folders)
/*
/autopartz-backend
  /config
    - db.js
    - passport.js
  /controllers
    - authController.js
    - brandController.js
    - categoryController.js
    - couponController.js
    - orderController.js
    - productController.js
    - userController.js
    - vendorController.js
  /middleware
    - auth.js
    - errorHandler.js
    - roleCheck.js
    - upload.js
  /models
    - Brand.js
    - Category.js
    - Coupon.js
    - Order.js
    - Product.js
    - Subcategory.js
    - User.js
    - Vendor.js
  /routes
    - authRoutes.js
    - brandRoutes.js
    - categoryRoutes.js
    - couponRoutes.js
    - orderRoutes.js
    - productRoutes.js
    - userRoutes.js
    - vendorRoutes.js
  /utils
    - errorResponse.js
    - seeder.js
  - .env (example)
  - package.json
  - server.js
*/

// server.js - Main entry point
import express from 'express';
import dotenv from 'dotenv';
import cors from 'cors';
import morgan from 'morgan';
import connectDB from './config/db.js';
import errorHandler from './middleware/errorHandler.js';
import authRoutes from './routes/authRoutes.js';
import userRoutes from './routes/userRoutes.js';
import vendorRoutes from './routes/vendorRoutes.js';
import productRoutes from './routes/productRoutes.js';
import categoryRoutes from './routes/categoryRoutes.js';
import brandRoutes from './routes/brandRoutes.js';
import couponRoutes from './routes/couponRoutes.js';
import orderRoutes from './routes/orderRoutes.js';
import './models/Review.js';
import seedData from './utils/seeder.js';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Serve uploads directory as static files

// Load env vars
dotenv.config();

// Connect to database
connectDB();

const app = express();

// Body parser
app.use(express.json());

app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
// Enable CORS
app.use(cors());

// Dev logging middleware
if (process.env.NODE_ENV === 'development') {
  app.use(morgan('dev'));
}

// Mount routes
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/vendors', vendorRoutes);
app.use('/api/products', productRoutes);
app.use('/api/categories', categoryRoutes);
app.use('/api/brands', brandRoutes);
app.use('/api/coupons', couponRoutes);
app.use('/api/orders', orderRoutes);

app.get('/image/:folder/:filename', (req, res) => {
  const { folder, filename } = req.params;
  res.sendFile(path.join(__dirname, 'uploads', folder, filename));
});

// Seed route - for development only
app.get('/api/seed', seedData);

// Base route
app.get('/', (req, res) => {
  res.send('AutoPartz API is running');
});

// Error handling middleware
app.use(errorHandler);

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`Server running in ${process.env.NODE_ENV} mode on port ${PORT}`);
});

// Handle unhandled promise rejections
process.on('unhandledRejection', (err, promise) => {
  console.log(`Error: ${err.message}`);
  // Close server & exit process
  server.close(() => process.exit(1));
});