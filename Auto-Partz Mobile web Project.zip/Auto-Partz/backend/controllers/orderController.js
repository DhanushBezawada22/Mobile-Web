// controllers/orderController.js
import asyncHandler from 'express-async-handler';
import Order from '../models/Order.js';
import Product from '../models/Product.js';
import Vendor from '../models/Vendor.js';
import Coupon from '../models/Coupon.js';
import ErrorResponse from '../utils/errorResponse.js';

// @desc    Create new order
// @route   POST /api/orders
// @access  Private (Customer)
export const createOrder = asyncHandler(async (req, res, next) => {
  const {
    orderItems,
    shippingAddress,
    paymentMethod,
    couponCode
  } = req.body;

  if (!orderItems || orderItems.length === 0) {
    return next(new ErrorResponse('No order items', 400));
  }

  // Verify all products exist and are in stock
  for (const item of orderItems) {
    const product = await Product.findById(item.product);
    
    if (!product) {
      return next(new ErrorResponse(`Product ${item.product} not found`, 404));
    }
    
    if (product.quantity < item.quantity) {
      return next(new ErrorResponse(`Product ${product.name} is out of stock`, 400));
    }
    
    // Add vendor to order item
    item.vendor = product.vendor;
    
    // Add current product data in case it changes later
    item.name = product.name;
    item.price = product.price;
    item.image = product.images[0] || 'default-product.jpg';
  }

  // Calculate prices
  const itemsPrice = orderItems.reduce(
    (acc, item) => acc + item.price * item.quantity,
    0
  );
  
  // Apply coupon if provided
  let discountAmount = 0;
  let couponApplied = null;
  
  if (couponCode) {
    const coupon = await Coupon.findOne({ code: couponCode.toUpperCase() });
    
    if (!coupon || !coupon.isValid()) {
      return next(new ErrorResponse('Invalid or expired coupon', 400));
    }
    
    // Check minimum purchase requirement
    if (coupon.minPurchase > 0 && itemsPrice < coupon.minPurchase) {
      return next(new ErrorResponse(`Minimum purchase of $${coupon.minPurchase} required for this coupon`, 400));
    }
    
    // Calculate discount
    if (coupon.type === 'percentage') {
      discountAmount = (itemsPrice * coupon.value) / 100;
    } else {
      discountAmount = coupon.value;
    }
    
    // Apply maximum discount if set
    if (coupon.maxDiscount && discountAmount > coupon.maxDiscount) {
      discountAmount = coupon.maxDiscount;
    }
    
    // Increment coupon usage
    coupon.usedCount += 1;
    await coupon.save();
    
    couponApplied = coupon._id;
  }
  
  // Calculate final prices
  const taxRate = 0.10; // 10% tax
  const taxPrice = (itemsPrice - discountAmount) * taxRate;
  
  // Shipping is free over $100 after discount
  const shippingPrice = (itemsPrice - discountAmount) > 100 ? 0 : 10;
  
  const totalPrice = (itemsPrice - discountAmount) + taxPrice + shippingPrice;

  const order = await Order.create({
    user: req.user.id,
    orderItems,
    shippingAddress,
    paymentMethod,
    itemsPrice,
    taxPrice,
    shippingPrice,
    totalPrice,
    couponApplied,
    discountAmount
  });

  // Update product stock
  for (const item of orderItems) {
    await Product.findByIdAndUpdate(item.product, {
      $inc: { quantity: -item.quantity }
    });
  }

  res.status(201).json({
    success: true,
    data: order,
  });
});

// @desc    Get all orders
// @route   GET /api/orders
// @access  Private (Admin)
export const getOrders = asyncHandler(async (req, res) => {
  const orders = await Order.find()
    .populate('user', 'id name email')
    .sort('-createdAt');

  res.status(200).json({
    success: true,
    count: orders.length,
    data: orders,
  });
});

// @desc    Get logged in user orders
// @route   GET /api/orders/myorders
// @access  Private (Customer)
export const getMyOrders = asyncHandler(async (req, res) => {
  const orders = await Order.find({ user: req.user.id }).sort('-createdAt');

  res.status(200).json({
    success: true,
    count: orders.length,
    data: orders,
  });
});

// @desc    Get vendor orders
// @route   GET /api/orders/vendor
// @access  Private (Vendor)
export const getVendorOrders = asyncHandler(async (req, res, next) => {
  const vendor = await Vendor.findOne({ user: req.user.id });
  
  if (!vendor) {
    return next(new ErrorResponse('Vendor profile not found', 404));
  }
  
  // Find orders that contain products from this vendor
  const orders = await Order.find({
    'orderItems.vendor': vendor._id
  }).populate('user', 'id name email').sort('-createdAt');
  
  // For each order, filter items to only show those belonging to this vendor
  const filteredOrders = orders.map(order => {
    const vendorItems = order.orderItems.filter(
      item => item.vendor.toString() === vendor._id.toString()
    );
    
    // Calculate vendor-specific totals
    const vendorItemsPrice = vendorItems.reduce(
      (acc, item) => acc + item.price * item.quantity,
      0
    );
    
    return {
      _id: order._id,
      user: order.user,
      orderItems: vendorItems,
      status: order.status,
      isPaid: order.isPaid,
      isDelivered: order.isDelivered,
      createdAt: order.createdAt,
      vendorItemsPrice
    };
  });

  res.status(200).json({
    success: true,
    count: filteredOrders.length,
    data: filteredOrders,
  });
});

// @desc    Get order by ID
// @route   GET /api/orders/:id
// @access  Private (Customer/Vendor/Admin)
export const getOrderById = asyncHandler(async (req, res, next) => {
  const order = await Order.findById(req.params.id).populate(
    'user',
    'name email'
  );

  if (!order) {
    return next(new ErrorResponse(`Order not found with id of ${req.params.id}`, 404));
  }

  // Make sure user has permission to see this order
  if (req.user.role === 'customer' && order.user.toString() !== req.user.id) {
    return next(new ErrorResponse('Not authorized to access this order', 401));
  }
  
  // For vendors, make sure they can only see their part of the order
  if (req.user.role === 'vendor') {
    const vendor = await Vendor.findOne({ user: req.user.id });
    
    if (!vendor) {
      return next(new ErrorResponse('Vendor profile not found', 404));
    }
    
    // Check if this vendor has any items in this order
    const vendorItems = order.orderItems.filter(
      item => item.vendor.toString() === vendor._id.toString()
    );
    
    if (vendorItems.length === 0) {
      return next(new ErrorResponse('Not authorized to access this order', 401));
    }
  }

  res.status(200).json({
    success: true,
    data: order,
  });
});

// @desc    Update order status
// @route   PUT /api/orders/:id/status
// @access  Private (Vendor/Admin)
export const updateOrderStatus = asyncHandler(async (req, res, next) => {
  let order = await Order.findById(req.params.id);

  if (!order) {
    return next(new ErrorResponse(`Order not found with id of ${req.params.id}`, 404));
  }
  
  // For vendors, make sure they can only update their part of the order
  if (req.user.role === 'vendor') {
    const vendor = await Vendor.findOne({ user: req.user.id });
    
    if (!vendor) {
      return next(new ErrorResponse('Vendor profile not found', 404));
    }
    
    // Check if this vendor has any items in this order
    const vendorItems = order.orderItems.filter(
      item => item.vendor.toString() === vendor._id.toString()
    );
    
    if (vendorItems.length === 0) {
      return next(new ErrorResponse('Not authorized to update this order', 401));
    }
  }

  // Update the order status
  order = await Order.findByIdAndUpdate(
    req.params.id,
    { status: req.body.status },
    { new: true }
  );
  
  // If status is 'delivered', update isDelivered and deliveredAt
  if (req.body.status === 'delivered' && !order.isDelivered) {
    order = await Order.findByIdAndUpdate(
      req.params.id,
      { 
        isDelivered: true,
        deliveredAt: Date.now()
      },
      { new: true }
    );
  }

  res.status(200).json({
    success: true,
    data: order,
  });
});

// @desc    Update order to paid
// @route   PUT /api/orders/:id/pay
// @access  Private (Admin)
export const updateOrderToPaid = asyncHandler(async (req, res, next) => {
  const order = await Order.findById(req.params.id);

  if (!order) {
    return next(new ErrorResponse(`Order not found with id of ${req.params.id}`, 404));
  }

  const updatedOrder = await Order.findByIdAndUpdate(
    req.params.id,
    {
      isPaid: true,
      paidAt: Date.now(),
      paymentResult: {
        id: req.body.id,
        status: req.body.status,
        update_time: req.body.update_time,
        email_address: req.body.email_address,
      },
    },
    { new: true }
  );

  res.status(200).json({
    success: true,
    data: updatedOrder,
  });
});