// controllers/productController.js
import asyncHandler from 'express-async-handler';
import Product from '../models/Product.js';
import Vendor from '../models/Vendor.js';
import ErrorResponse from '../utils/errorResponse.js';

// @desc    Create new product
// @route   POST /api/products
// @access  Private (Vendor/Admin)
export const createProduct = asyncHandler(async (req, res, next) => {
  // If a vendor is creating the product
  if (req.user.role === 'vendor') {
    const vendor = await Vendor.findOne({ user: req.user.id });
    
    if (!vendor) {
      return next(new ErrorResponse('Vendor profile not found', 404));
    }
    
    if (!vendor.isVerified) {
      return next(new ErrorResponse('Your vendor account is not verified yet', 403));
    }
    
    req.body.vendor = vendor._id;
  }
  
  // If admin is creating product for a vendor
  if (req.user.role === 'admin' && req.body.vendor) {
    const vendor = await Vendor.findById(req.body.vendor);
    
    if (!vendor) {
      return next(new ErrorResponse(`Vendor not found with id of ${req.body.vendor}`, 404));
    }
  }

  const product = await Product.create(req.body);

  res.status(201).json({
    success: true,
    data: product,
  });
});

// @desc    Get all products
// @route   GET /api/products
// @access  Public
export const getProducts = asyncHandler(async (req, res) => {
  // Copy req.query
  const reqQuery = { ...req.query };

  // Fields to exclude
  const removeFields = ['select', 'sort', 'page', 'limit'];

  // Loop over removeFields and delete them from reqQuery
  removeFields.forEach(param => delete reqQuery[param]);

  // Create query string
  let queryStr = JSON.stringify(reqQuery);

  // Create operators ($gt, $gte, etc)
  queryStr = queryStr.replace(/\b(gt|gte|lt|lte|in)\b/g, match => `$${match}`);

  // Finding resource
  let query = Product.find(JSON.parse(queryStr))
    .populate('category', 'name')
    .populate('subcategory', 'name')
    .populate('brand', 'name')
    .populate('vendor', 'shopName');

  // Select Fields
  if (req.query.select) {
    const fields = req.query.select.split(',').join(' ');
    query = query.select(fields);
  }

  // Sort
  if (req.query.sort) {
    const sortBy = req.query.sort.split(',').join(' ');
    query = query.sort(sortBy);
  } else {
    query = query.sort('-createdAt');
  }

  // Pagination
  const page = parseInt(req.query.page, 10) || 1;
  const limit = parseInt(req.query.limit, 10) || 25;
  const startIndex = (page - 1) * limit;
  const endIndex = page * limit;
  const total = await Product.countDocuments(JSON.parse(queryStr));

  query = query.skip(startIndex).limit(limit);

  // Executing query
  const products = await query;

  // Pagination result
  const pagination = {};

  if (endIndex < total) {
    pagination.next = {
      page: page + 1,
      limit,
    };
  }

  if (startIndex > 0) {
    pagination.prev = {
      page: page - 1,
      limit,
    };
  }

  res.status(200).json({
    success: true,
    count: products.length,
    pagination,
    data: products,
  });
});

// @desc    Get single product
// @route   GET /api/products/:id
// @access  Public
export const getProduct = asyncHandler(async (req, res, next) => {
  const product = await Product.findById(req.params.id)
    .populate('category', 'name')
    .populate('subcategory', 'name')
    .populate('brand', 'name')
    .populate('vendor', 'shopName')
    .populate('reviews');

  if (!product) {
    return next(new ErrorResponse(`Product not found with id of ${req.params.id}`, 404));
  }

  res.status(200).json({
    success: true,
    data: product,
  });
});

// @desc    Update product
// @route   PUT /api/products/:id
// @access  Private (Vendor/Admin)
export const updateProduct = asyncHandler(async (req, res, next) => {
  let product = await Product.findById(req.params.id);

  if (!product) {
    return next(new ErrorResponse(`Product not found with id of ${req.params.id}`, 404));
  }

  // Make sure vendor is the owner or admin
  if (req.user.role === 'vendor') {
    const vendor = await Vendor.findOne({ user: req.user.id });
    
    if (!vendor) {
      return next(new ErrorResponse('Vendor profile not found', 404));
    }
    
    if (product.vendor.toString() !== vendor._id.toString()) {
      return next(
        new ErrorResponse(
          `Vendor ${vendor._id} is not authorized to update this product`,
          401
        )
      );
    }
  }

  product = await Product.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true,
  });

  res.status(200).json({
    success: true,
    data: product,
  });
});

// @desc    Delete product
// @route   DELETE /api/products/:id
// @access  Private (Vendor/Admin)
export const deleteProduct = asyncHandler(async (req, res, next) => {
  const product = await Product.findById(req.params.id);

  if (!product) {
    return next(new ErrorResponse(`Product not found with id of ${req.params.id}`, 404));
  }

  // Make sure vendor is the owner or admin
  if (req.user.role === 'vendor') {
    const vendor = await Vendor.findOne({ user: req.user.id });
    
    if (!vendor) {
      return next(new ErrorResponse('Vendor profile not found', 404));
    }
    
    if (product.vendor.toString() !== vendor._id.toString()) {
      return next(
        new ErrorResponse(
          `Vendor ${vendor._id} is not authorized to delete this product`,
          401
        )
      );
    }
  }

  await product.remove();

  res.status(200).json({
    success: true,
    data: {},
  });
});

// @desc    Upload product images
// @route   PUT /api/products/:id/images
// @access  Private (Vendor/Admin)
export const uploadProductImages = asyncHandler(async (req, res, next) => {
  const product = await Product.findById(req.params.id);

  if (!product) {
    return next(new ErrorResponse(`Product not found with id of ${req.params.id}`, 404));
  }

  // Make sure vendor is the owner or admin
  if (req.user.role === 'vendor') {
    const vendor = await Vendor.findOne({ user: req.user.id });
    
    if (!vendor) {
      return next(new ErrorResponse('Vendor profile not found', 404));
    }
    
    if (product.vendor.toString() !== vendor._id.toString()) {
      return next(
        new ErrorResponse(
          `Vendor ${vendor._id} is not authorized to update this product`,
          401
        )
      );
    }
  }

  if (!req.files) {
    return next(new ErrorResponse(`Please upload files`, 400));
  }

  const images = req.files.map(file => file.filename);

  const updatedProduct = await Product.findByIdAndUpdate(
    req.params.id,
    { images },
    { new: true }
  );

  res.status(200).json({
    success: true,
    data: updatedProduct,
  });
});

// @desc    Get featured products
// @route   GET /api/products/featured
// @access  Public
export const getFeaturedProducts = asyncHandler(async (req, res) => {
  const limit = parseInt(req.query.limit, 10) || 10;

  const products = await Product.find({ featured: true })
    .limit(limit)
    .populate('category', 'name')
    .populate('brand', 'name')
    .populate('vendor', 'shopName');

  res.status(200).json({
    success: true,
    count: products.length,
    data: products,
  });
});