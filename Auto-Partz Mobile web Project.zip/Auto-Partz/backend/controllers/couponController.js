// controllers/couponController.js
import asyncHandler from 'express-async-handler';
import Coupon from '../models/Coupon.js';
import ErrorResponse from '../utils/errorResponse.js';

// @desc    Create new coupon
// @route   POST /api/coupons
// @access  Private (Admin/Vendor)
export const createCoupon = asyncHandler(async (req, res) => {
  // Set the creator
  req.body.createdBy = req.user.id;

  const coupon = await Coupon.create(req.body);

  res.status(201).json({
    success: true,
    data: coupon,
  });
});

// @desc    Get all coupons
// @route   GET /api/coupons
// @access  Private (Admin)
export const getCoupons = asyncHandler(async (req, res) => {
  const coupons = await Coupon.find()
    .populate('createdBy', 'name email')
    .populate('applicableProducts', 'name price')
    .populate('applicableCategories', 'name')
    .populate('applicableVendors', 'shopName');

  res.status(200).json({
    success: true,
    count: coupons.length,
    data: coupons,
  });
});

// @desc    Get vendor coupons
// @route   GET /api/coupons/vendor
// @access  Private (Vendor)
export const getVendorCoupons = asyncHandler(async (req, res) => {
  const coupons = await Coupon.find({ createdBy: req.user.id })
    .populate('applicableProducts', 'name price')
    .populate('applicableCategories', 'name');

  res.status(200).json({
    success: true,
    count: coupons.length,
    data: coupons,
  });
});

// @desc    Get single coupon
// @route   GET /api/coupons/:id
// @access  Private (Admin/Vendor who created)
export const getCoupon = asyncHandler(async (req, res, next) => {
  const coupon = await Coupon.findById(req.params.id)
    .populate('createdBy', 'name email')
    .populate('applicableProducts', 'name price')
    .populate('applicableCategories', 'name')
    .populate('applicableVendors', 'shopName');

  if (!coupon) {
    return next(new ErrorResponse(`Coupon not found with id of ${req.params.id}`, 404));
  }

  // Make sure the coupon belongs to the vendor or is admin
  if (req.user.role === 'vendor' && coupon.createdBy.toString() !== req.user.id) {
    return next(new ErrorResponse(`Not authorized to access this coupon`, 401));
  }

  res.status(200).json({
    success: true,
    data: coupon,
  });
});

// @desc    Update coupon
// @route   PUT /api/coupons/:id
// @access  Private (Admin/Vendor who created)
export const updateCoupon = asyncHandler(async (req, res, next) => {
  let coupon = await Coupon.findById(req.params.id);

  if (!coupon) {
    return next(new ErrorResponse(`Coupon not found with id of ${req.params.id}`, 404));
  }

  // Make sure the coupon belongs to the vendor or is admin
  if (req.user.role === 'vendor' && coupon.createdBy.toString() !== req.user.id) {
    return next(new ErrorResponse(`Not authorized to update this coupon`, 401));
  }

  coupon = await Coupon.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true,
  });

  res.status(200).json({
    success: true,
    data: coupon,
  });
});

// @desc    Delete coupon
// @route   DELETE /api/coupons/:id
// @access  Private (Admin/Vendor who created)
export const deleteCoupon = asyncHandler(async (req, res, next) => {
  const coupon = await Coupon.findById(req.params.id);

  if (!coupon) {
    return next(new ErrorResponse(`Coupon not found with id of ${req.params.id}`, 404));
  }

  // Make sure the coupon belongs to the vendor or is admin
  if (req.user.role === 'vendor' && coupon.createdBy.toString() !== req.user.id) {
    return next(new ErrorResponse(`Not authorized to delete this coupon`, 401));
  }

  await coupon.remove();

  res.status(200).json({
    success: true,
    data: {},
  });
});

// @desc    Validate coupon
// @route   POST /api/coupons/validate
// @access  Public
export const validateCoupon = asyncHandler(async (req, res, next) => {
  const { code } = req.body;

  if (!code) {
    return next(new ErrorResponse('Please provide a coupon code', 400));
  }

  const coupon = await Coupon.findOne({ code: code.toUpperCase() });

  if (!coupon) {
    return next(new ErrorResponse('Invalid coupon code', 404));
  }

  if (!coupon.isValid()) {
    return next(new ErrorResponse('Coupon is expired or inactive', 400));
  }

  res.status(200).json({
    success: true,
    data: {
      code: coupon.code,
      type: coupon.type,
      value: coupon.value,
      minPurchase: coupon.minPurchase,
      maxDiscount: coupon.maxDiscount
    },
  });
});