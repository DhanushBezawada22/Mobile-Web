// controllers/vendorController.js
import asyncHandler from 'express-async-handler';
import User from '../models/User.js';
import Vendor from '../models/Vendor.js';
import Product from '../models/Product.js';
import ErrorResponse from '../utils/errorResponse.js';

// @desc    Register as vendor
// @route   POST /api/vendors
// @access  Private (Customer)
export const registerVendor = asyncHandler(async (req, res, next) => {
  const { shopName, description, phone, address, specialties } = req.body;

  // Check if user already registered as vendor
  const existingVendor = await Vendor.findOne({ user: req.user.id });

  if (existingVendor) {
    return next(new ErrorResponse('You are already registered as a vendor', 400));
  }

  // Create vendor
  const vendor = await Vendor.create({
    user: req.user.id,
    shopName,
    description,
    phone,
    address,
    specialties: specialties || [],
  });

  // Update user role to vendor
  await User.findByIdAndUpdate(req.user.id, { role: 'vendor' });

  res.status(201).json({
    success: true,
    data: vendor,
  });
});

// @desc    Get all vendors
// @route   GET /api/vendors
// @access  Public
export const getVendors = asyncHandler(async (req, res) => {
  // Only show verified vendors to public
  const vendors = await Vendor.find({ isVerified: true })
    .populate('user', 'name email')
    .populate('brands');

  res.status(200).json({
    success: true,
    count: vendors.length,
    data: vendors,
  });
});

// @desc    Get all vendors (including unverified ones)
// @route   GET /api/vendors/all
// @access  Private (Admin)
export const getAllVendors = asyncHandler(async (req, res) => {
  const vendors = await Vendor.find()
    .populate('user', 'name email')
    .populate('brands');

  res.status(200).json({
    success: true,
    count: vendors.length,
    data: vendors,
  });
});

// @desc    Get single vendor
// @route   GET /api/vendors/:id
// @access  Public
export const getVendor = asyncHandler(async (req, res, next) => {
  const vendor = await Vendor.findById(req.params.id)
    .populate('user', 'name email')
    .populate('brands');

    console.log(vendor);
  if (!vendor) {
    return next(new ErrorResponse(`Vendor not found with id of ${req.params.id}`, 404));
  }

  // If vendor is not verified, only allow admin or the vendor themselves to view
  if (!vendor.isVerified && 
      req.user.role !== 'admin' && 
      req.user.id !== vendor.user.toString()) {
    return next(new ErrorResponse(`Vendor not found with id of ${req.params.id}`, 404));
  }
 
  

  res.status(200).json({
    success: true,
    data: vendor,
  });
});

// @desc    Update vendor
// @route   PUT /api/vendors/:id
// @access  Private (Vendor/Admin)
export const updateVendor = asyncHandler(async (req, res, next) => {
  let vendor = await Vendor.findById(req.params.id);

  if (!vendor) {
    return next(new ErrorResponse(`Vendor not found with id of ${req.params.id}`, 404));
  }

  // Make sure vendor is the owner or admin
  if (vendor.user.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(
      new ErrorResponse(
        `User ${req.user.id} is not authorized to update this vendor`,
        401
      )
    );
  }

  // Don't allow non-admin to update isVerified field
  if (req.user.role !== 'admin' && req.body.isVerified !== undefined) {
    delete req.body.isVerified;
  }

  vendor = await Vendor.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true,
  });

  res.status(200).json({
    success: true,
    data: vendor,
  });
});

// @desc    Verify vendor
// @route   PUT /api/vendors/:id/verify
// @access  Private (Admin)
export const verifyVendor = asyncHandler(async (req, res, next) => {
  let vendor = await Vendor.findById(req.params.id);

  if (!vendor) {
    return next(new ErrorResponse(`Vendor not found with id of ${req.params.id}`, 404));
  }

  vendor = await Vendor.findByIdAndUpdate(
    req.params.id,
    { isVerified: true },
    {
      new: true,
      runValidators: true,
    }
  );

  res.status(200).json({
    success: true,
    data: vendor,
  });
});

// @desc    Get vendor products
// @route   GET /api/vendors/:id/products
// @access  Public
export const getVendorProducts = asyncHandler(async (req, res, next) => {
  const vendor = await Vendor.findById(req.params.id);

  if (!vendor) {
    return next(new ErrorResponse(`Vendor not found with id of ${req.params.id}`, 404));
  }

  // If vendor is not verified, only show products to admin or the vendor themselves
  if (!vendor.isVerified && 
      (!req.user || (req.user.role !== 'admin' && req.user.id !== vendor.user.toString()))) {
    return res.status(200).json({
      success: true,
      count: 0,
      data: []
    });
  }

  const products = await Product.find({ vendor: req.params.id })
    .populate('category', 'name')
    .populate('subcategory', 'name')
    .populate('brand', 'name');

  res.status(200).json({
    success: true,
    count: products.length,
    data: products,
  });
});

// @desc    Delete vendor
// @route   DELETE /api/vendors/:id
// @access  Private (Admin)
export const deleteVendor = asyncHandler(async (req, res, next) => {
  const vendor = await Vendor.findById(req.params.id);

  if (!vendor) {
    return next(new ErrorResponse(`Vendor not found with id of ${req.params.id}`, 404));
  }

  await vendor.remove();

  // Update user role back to customer
  await User.findByIdAndUpdate(vendor.user, { role: 'customer' });

  res.status(200).json({
    success: true,
    data: {},
  });
});

// @desc    Upload vendor logo
// @route   PUT /api/vendors/:id/logo
// @access  Private (Vendor/Admin)
export const uploadVendorLogo = asyncHandler(async (req, res, next) => {
  const vendor = await Vendor.findById(req.params.id);

  if (!vendor) {
    return next(new ErrorResponse(`Vendor not found with id of ${req.params.id}`, 404));
  }

  // Make sure vendor is the owner or admin
  if (vendor.user.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(
      new ErrorResponse(
        `User ${req.user.id} is not authorized to update this vendor`,
        401
      )
    );
  }

  if (!req.file) {
    return next(new ErrorResponse(`Please upload a file`, 400));
  }

  const updatedVendor = await Vendor.findByIdAndUpdate(
    req.params.id,
    { logo: req.file.filename },
    { new: true }
  );

  res.status(200).json({
    success: true,
    data: updatedVendor,
  });
});

// @route GET /api/vendors/user/:userId
export const getVendorByUser = asyncHandler(async (req, res, next) => {
  const vendor = await Vendor.findOne({ user: req.params.userId })
    .populate('user', 'name email')
    .populate('brands');

  if (!vendor) {
    return next(new ErrorResponse(`Vendor not found for user ID ${req.params.userId}`, 404));
  }

  res.status(200).json({
    success: true,
    data: vendor,
  });
});
