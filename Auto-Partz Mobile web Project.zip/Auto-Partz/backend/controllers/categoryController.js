// controllers/categoryController.js
import asyncHandler from 'express-async-handler';
import Category from '../models/Category.js';
import Subcategory from '../models/SubCategory.js';
import Product from '../models/Product.js';
import ErrorResponse from '../utils/errorResponse.js';

// @desc    Create new category
// @route   POST /api/categories
// @access  Private (Admin)
export const createCategory = asyncHandler(async (req, res, next) => {
  const category = await Category.create(req.body);

  res.status(201).json({
    success: true,
    data: category,
  });
});

// @desc    Get all categories
// @route   GET /api/categories
// @access  Public
export const getCategories = asyncHandler(async (req, res) => {
  const categories = await Category.find();

  res.status(200).json({
    success: true,
    count: categories.length,
    data: categories,
  });
});

// @desc    Get single category
// @route   GET /api/categories/:id
// @access  Public
export const getCategory = asyncHandler(async (req, res, next) => {
  const category = await Category.findById(req.params.id);

  if (!category) {
    return next(new ErrorResponse(`Category not found with id of ${req.params.id}`, 404));
  }

  res.status(200).json({
    success: true,
    data: category,
  });
});

// @desc    Update category
// @route   PUT /api/categories/:id
// @access  Private (Admin)
export const updateCategory = asyncHandler(async (req, res, next) => {
  let category = await Category.findById(req.params.id);

  if (!category) {
    return next(new ErrorResponse(`Category not found with id of ${req.params.id}`, 404));
  }

  category = await Category.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true,
  });

  res.status(200).json({
    success: true,
    data: category,
  });
});

// @desc    Delete category
// @route   DELETE /api/categories/:id
// @access  Private (Admin)
export const deleteCategory = asyncHandler(async (req, res, next) => {
  const category = await Category.findById(req.params.id);

  if (!category) {
    return next(new ErrorResponse(`Category not found with id of ${req.params.id}`, 404));
  }

  // Check if category has products
  const productCount = await Product.countDocuments({ category: req.params.id });
  
  if (productCount > 0) {
    return next(new ErrorResponse(`Cannot delete category with associated products`, 400));
  }

  // Delete all subcategories
  await Subcategory.deleteMany({ category: req.params.id });

  await category.remove();

  res.status(200).json({
    success: true,
    data: {},
  });
});

// @desc    Create new subcategory
// @route   POST /api/categories/:categoryId/subcategories
// @access  Private (Admin)
export const createSubcategory = asyncHandler(async (req, res, next) => {
  req.body.category = req.params.categoryId;

  const category = await Category.findById(req.params.categoryId);

  if (!category) {
    return next(
      new ErrorResponse(`Category not found with id of ${req.params.categoryId}`, 404)
    );
  }

  const subcategory = await Subcategory.create(req.body);

  res.status(201).json({
    success: true,
    data: subcategory,
  });
});

// @desc    Get all subcategories for category
// @route   GET /api/categories/:categoryId/subcategories
// @access  Public
export const getSubcategories = asyncHandler(async (req, res, next) => {
  const category = await Category.findById(req.params.categoryId);

  if (!category) {
    return next(
      new ErrorResponse(`Category not found with id of ${req.params.categoryId}`, 404)
    );
  }

  const subcategories = await Subcategory.find({ category: req.params.categoryId });

  res.status(200).json({
    success: true,
    count: subcategories.length,
    data: subcategories,
  });
});