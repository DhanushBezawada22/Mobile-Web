// controllers/brandController.js
import asyncHandler from 'express-async-handler';
import Brand from '../models/Brand.js';
import Product from '../models/Product.js';
import ErrorResponse from '../utils/errorResponse.js';

// @desc    Create new brand
// @route   POST /api/brands
// @access  Private (Admin)
export const createBrand = asyncHandler(async (req, res, next) => {
  const brand = await Brand.create(req.body);

  res.status(201).json({
    success: true,
    data: brand,
  });
});

// @desc    Get all brands
// @route   GET /api/brands
// @access  Public
export const getBrands = asyncHandler(async (req, res) => {
  const brands = await Brand.find();

  res.status(200).json({
    success: true,
    count: brands.length,
    data: brands,
  });
});

// @desc    Get single brand
// @route   GET /api/brands/:id
// @access  Public
export const getBrand = asyncHandler(async (req, res, next) => {
  const brand = await Brand.findById(req.params.id);

  if (!brand) {
    return next(new ErrorResponse(`Brand not found with id of ${req.params.id}`, 404));
  }

  res.status(200).json({
    success: true,
    data: brand,
  });
});

// @desc    Update brand
// @route   PUT /api/brands/:id
// @access  Private (Admin)
export const updateBrand = asyncHandler(async (req, res, next) => {
  let brand = await Brand.findById(req.params.id);

  if (!brand) {
    return next(new ErrorResponse(`Brand not found with id of ${req.params.id}`, 404));
  }

  brand = await Brand.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true,
  });

  res.status(200).json({
    success: true,
    data: brand,
  });
});

// @desc    Delete brand
// @route   DELETE /api/brands/:id
// @access  Private (Admin)
export const deleteBrand = asyncHandler(async (req, res, next) => {
  const brand = await Brand.findById(req.params.id);

  if (!brand) {
    return next(new ErrorResponse(`Brand not found with id of ${req.params.id}`, 404));
  }

  // Check if brand has products
  const productCount = await Product.countDocuments({ brand: req.params.id });
  
  if (productCount > 0) {
    return next(new ErrorResponse(`Cannot delete brand with associated products`, 400));
  }

  await brand.remove();

  res.status(200).json({
    success: true,
    data: {},
  });
});

// @desc    Upload brand logo
// @route   PUT /api/brands/:id/logo
// @access  Private (Admin)
export const uploadBrandLogo = asyncHandler(async (req, res, next) => {
  const brand = await Brand.findById(req.params.id);

  if (!brand) {
    return next(new ErrorResponse(`Brand not found with id of ${req.params.id}`, 404));
  }

  if (!req.file) {
    return next(new ErrorResponse(`Please upload a file`, 400));
  }

  const updatedBrand = await Brand.findByIdAndUpdate(
    req.params.id,
    { logo: req.file.filename },
    { new: true }
  );

  res.status(200).json({
    success: true,
    data: updatedBrand,
  });
});