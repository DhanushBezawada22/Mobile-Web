// middleware/upload.js
import multer from 'multer';
import path from 'path';
import fs from 'fs';

// Set storage engine
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    let uploadPath = 'uploads/';

    // Determine the folder based on file type
    if (file.fieldname === 'productImages') {
      uploadPath += 'products/';
    } else if (file.fieldname === 'logo') {
      uploadPath += 'vendors/';
    } else if (file.fieldname === 'brandLogo') {
      uploadPath += 'brands/';
    } else if (file.fieldname === 'categoryImage') {
      uploadPath += 'categories/';
    } else if (file.fieldname === 'userPhoto') {
      uploadPath += 'users/';
    } else {
      uploadPath += 'misc/';
    }

    // Create directory if it doesn't exist
    if (!fs.existsSync(uploadPath)) {
      fs.mkdirSync(uploadPath, { recursive: true });
    }

    cb(null, uploadPath);
  },
  filename: function (req, file, cb) {
    cb(
      null,
      `${file.fieldname}-${Date.now()}${path.extname(file.originalname)}`
    );
  }
});

// Check file type
function checkFileType(file, cb) {
  // Allowed ext
  const filetypes = /jpeg|jpg|png|gif/;
  // Check ext
  const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
  // Check mime
  const mimetype = filetypes.test(file.mimetype);

  if (mimetype && extname) {
    return cb(null, true);
  } else {
    cb(new Error('Images only!'));
  }
}

// Initialize upload variable
export const upload = multer({
  storage: storage,
  limits: { fileSize: 1000000 }, // 1MB
  fileFilter: function (req, file, cb) {
    checkFileType(file, cb);
  }
});