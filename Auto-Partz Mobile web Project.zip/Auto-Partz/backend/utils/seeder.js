// utils/seeder.js
import mongoose from 'mongoose';
import asyncHandler from 'express-async-handler';
import User from '../models/User.js';
import Brand from '../models/Brand.js';
import Category from '../models/Category.js';
import Subcategory from '../models/SubCategory.js';
import Vendor from '../models/Vendor.js';
import Product from '../models/Product.js';
import Review from '../models/Review.js';

const seedData = asyncHandler(async (req, res) => {
  // Clear existing data
  try{

    await mongoose.connection.dropDatabase();
  // await User.deleteMany();
  // await Brand.deleteMany();
  // await Category.deleteMany();
  // await Subcategory.deleteMany();
  // await Vendor.deleteMany();
  // await Product.deleteMany();

    // Rebuild indexes
     await Promise.all([
      User.init(),
      Brand.init(),
      Category.init(),
      Subcategory.init(),
      Vendor.init(),
      Product.init(),
      Review.init(),
    ]);

  }catch (err) {
    console.error('Error clearing users:', err.message);
  }

  // Create admin user
  const adminUser = await User.create({
    name: 'Admin User',
    email: 'admin@gmail.com',
    password: 'password123',
    role: 'admin',
  });

  // Create vendor users
  const vendor1 = await User.create({
    name: 'Honda Vendor',
    email: 'honda@example.com',
    password: 'password123',
    role: 'vendor',
  });

  const vendor2 = await User.create({
    name: 'BMW Vendor',
    email: 'bmw@example.com',
    password: 'password123',
    role: 'vendor',
  });

  // Create customer
  const customer = await User.create({
    name: 'John Customer',
    email: 'customer@example.com',
    password: 'password123',
    role: 'customer',
  });

  // Create brands
  const hondaBrand = await Brand.create({
    name: 'Honda',
    description: 'Japanese multinational conglomerate manufacturer',
    website: 'https://honda.com',
  });

  const bmwBrand = await Brand.create({
    name: 'BMW',
    description: 'German luxury automobile manufacturer',
    website: 'https://bmw.com',
  });

  // Create vendor profiles
  const hondaVendor = await Vendor.create({
    user: vendor1._id,
    shopName: 'Honda Parts Shop',
    description: 'Official Honda parts and accessories',
    phone: '123-456-7890',
    address: '123 Honda St, Tokyo, Japan',
    isVerified: true,
    specialties: ['Honda Motorcycles', 'Honda Cars'],
    brands: [hondaBrand._id],
  });

  const bmwVendor = await Vendor.create({
    user: vendor2._id,
    shopName: 'BMW Parts Shop',
    description: 'Official BMW parts and accessories',
    phone: '123-456-7891',
    address: '123 BMW St, Munich, Germany',
    isVerified: true,
    specialties: ['BMW Cars', 'BMW Motorcycles'],
    brands: [bmwBrand._id],
  });

  // Create categories and subcategories
  const engineCategory = await Category.create({
    name: 'Engine Parts',
    description: 'Parts related to the engine',
  });

  const engineSubcategories = await Subcategory.insertMany([
    {
      name: 'Pistons',
      category: engineCategory._id,
      description: 'Engine pistons',
    },
    {
      name: 'Spark Plugs',
      category: engineCategory._id,
      description: 'Engine spark plugs',
    },
  ]);

  const bodyCategory = await Category.create({
    name: 'Body Parts',
    description: 'External body parts',
  });

  const bodySubcategories = await Subcategory.insertMany([
    {
      name: 'Mirrors',
      category: bodyCategory._id,
      description: 'Side mirrors',
    },
    {
      name: 'Bumpers',
      category: bodyCategory._id,
      description: 'Front and rear bumpers',
    },
  ]);

  // Create products for Honda CB Shine (bike)
  const hondaProducts = await Product.insertMany([
    {
      name: 'Honda CB Shine Spark Plug',
      description: 'Original Honda spark plug for CB Shine 125cc motorcycle',
      price: 8.99,
      originalPrice: 10.99,
      quantity: 50,
      category: engineCategory._id,
      subcategory: engineSubcategories[1]._id, // Spark Plugs
      brand: hondaBrand._id,
      vendor: hondaVendor._id,
      vehicleType: 'bike',
      vehicleModel: 'Honda CB Shine',
      specifications: {
        type: 'Iridium',
        gap: '0.8mm',
        thread: '10mm',
      },
      featured: true,
    },
    {
      name: 'Honda CB Shine Side Mirror',
      description: 'OEM replacement side mirror for Honda CB Shine motorcycle',
      price: 15.99,
      originalPrice: 19.99,
      quantity: 20,
      category: bodyCategory._id,
      subcategory: bodySubcategories[0]._id, // Mirrors
      brand: hondaBrand._id,
      vendor: hondaVendor._id,
      vehicleType: 'bike',
      vehicleModel: 'Honda CB Shine',
      specifications: {
        position: 'Left',
        material: 'Plastic and Glass',
        color: 'Black',
      },
    },
  ]);

  // Create products for Honda Civic (car)
  await Product.insertMany([
    {
      name: 'Honda Civic Spark Plug Set',
      description: 'Set of 4 original Honda spark plugs for Civic',
      price: 39.99,
      originalPrice: 45.99,
      quantity: 30,
      category: engineCategory._id,
      subcategory: engineSubcategories[1]._id, // Spark Plugs
      brand: hondaBrand._id,
      vendor: hondaVendor._id,
      vehicleType: 'car',
      vehicleModel: 'Honda Civic',
      specifications: {
        type: 'Iridium',
        gap: '1.0mm',
        thread: '14mm',
        quantity: '4 pieces',
      },
    },
    {
      name: 'Honda Civic Front Bumper',
      description: 'OEM replacement front bumper for Honda Civic',
      price: 199.99,
      originalPrice: 249.99,
      quantity: 10,
      category: bodyCategory._id,
      subcategory: bodySubcategories[1]._id, // Bumpers
      brand: hondaBrand._id,
      vendor: hondaVendor._id,
      vehicleType: 'car',
      vehicleModel: 'Honda Civic',
      specifications: {
        material: 'Reinforced Plastic',
        color: 'Black (Unpainted)',
        fitment: '2018-2022 Models',
      },
      featured: true,
    },
  ]);

  // Create products for BMW S1000RR (bike)
  await Product.insertMany([
    {
      name: 'BMW S1000RR Performance Spark Plug',
      description: 'High-performance spark plug for BMW S1000RR motorcycle',
      price: 29.99,
      originalPrice: 34.99,
      quantity: 25,
      category: engineCategory._id,
      subcategory: engineSubcategories[1]._id, // Spark Plugs
      brand: bmwBrand._id,
      vendor: bmwVendor._id,
      vehicleType: 'bike',
      vehicleModel: 'BMW S1000RR',
      specifications: {
        type: 'Racing Iridium',
        gap: '0.7mm',
        thread: '10mm',
      },
      featured: true,
    },
    {
      name: 'BMW S1000RR Carbon Fiber Mirror Set',
      description: 'Premium carbon fiber mirror set for BMW S1000RR',
      price: 199.99,
      originalPrice: 249.99,
      quantity: 5,
      category: bodyCategory._id,
      subcategory: bodySubcategories[0]._id, // Mirrors
      brand: bmwBrand._id,
      vendor: bmwVendor._id,
      vehicleType: 'bike',
      vehicleModel: 'BMW S1000RR',
      specifications: {
        material: 'Carbon Fiber',
        weight: '200g each',
        finish: 'Glossy',
      },
    },
  ]);

  // Create products for BMW 3 Series (car)
  await Product.insertMany([
    {
      name: 'BMW 3 Series Piston Set',
      description: 'Complete piston set for BMW 3 Series',
      price: 499.99,
      originalPrice: 599.99,
      quantity: 8,
      category: engineCategory._id,
      subcategory: engineSubcategories[0]._id, // Pistons
      brand: bmwBrand._id,
      vendor: bmwVendor._id,
      vehicleType: 'car',
      vehicleModel: 'BMW 3 Series',
      specifications: {
        diameter: '84mm',
        material: 'Forged Aluminum',
        compression: '10.2:1',
        includes: 'Rings and Pins',
      },
    },
    {
      name: 'BMW 3 Series M Sport Bumper',
      description: 'M Sport front bumper for BMW 3 Series',
      price: 599.99,
      originalPrice: 699.99,
      quantity: 3,
      category: bodyCategory._id,
      subcategory: bodySubcategories[1]._id, // Bumpers
      brand: bmwBrand._id,
      vendor: bmwVendor._id,
      vehicleType: 'car',
      vehicleModel: 'BMW 3 Series',
      specifications: {
        material: 'Reinforced Polymer',
        design: 'M Sport',
        color: 'Unpainted',
        fitment: '2019-2023 Models',
      },
      featured: true,
    },
  ]);

  res.status(200).json({
    success: true,
    message: 'Data seeded successfully',
  });
}

);

export default seedData;