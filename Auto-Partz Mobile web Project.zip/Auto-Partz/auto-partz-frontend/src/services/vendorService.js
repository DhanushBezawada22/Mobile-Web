// src/services/vendorService.js
import api from './api'

const vendorService = {
  // Register as vendor
  registerVendor: async (vendorData) => {
    const response = await api.post('/vendors', vendorData)
    return response.data
  },

  // Get all vendors
  getVendors: async () => {
    const response = await api.get('/vendors')
    return response.data
  },

  // Get all vendors including unverified (admin)
  getAllVendors: async () => {
    const response = await api.get('/vendors/admin/all')
    return response.data
  },

  // Get single vendor
  getVendor: async (id) => {
    const response = await api.get(`/vendors/${id}`)
    return response.data
  },

  // Add this to vendorService.js
getVendorByUser: async (userId) => {
  const response = await api.get(`/vendors/user/${userId}`);
  return response.data;
},

  // Update vendor
  updateVendor: async (id, vendorData) => {
    const response = await api.put(`/vendors/${id}`, vendorData)
    return response.data
  },

  // Verify vendor (admin)
  verifyVendor: async (id) => {
    const response = await api.put(`/vendors/${id}/verify`)
    return response.data
  },

  // Delete vendor (admin)
  deleteVendor: async (id) => {
    const response = await api.delete(`/vendors/${id}`)
    return response.data
  },

  // Get vendor products
  getVendorProducts: async (id) => {
    const response = await api.get(`/vendors/${id}/products`)
    return response.data
  },

  // Upload vendor logo
  uploadVendorLogo: async (id, formData) => {
    const response = await api.put(`/vendors/${id}/logo`, formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    })
    return response.data
  },

  // Get vendor coupons
  getVendorCoupons: async () => {
    const response = await api.get('/coupons/vendor')
    return response.data
  },

  // Create coupon
  createCoupon: async (couponData) => {
    const response = await api.post('/coupons', couponData)
    return response.data
  },

  // Update coupon
  updateCoupon: async (id, couponData) => {
    const response = await api.put(`/coupons/${id}`, couponData)
    return response.data
  },

  // Delete coupon
  deleteCoupon: async (id) => {
    const response = await api.delete(`/coupons/${id}`)
    return response.data
  }
}

export default vendorService