// src/services/authService.js
import api from './api'

const authService = {
  // Register user
  register: async (userData) => {
    const response = await api.post('/auth/register', userData)
    return response.data
  },

  // Login user
  login: async (userData) => {
    const response = await api.post('/auth/login', userData)
    return response.data
  },

  // Logout user
  logout: async () => {
    const response = await api.get('/auth/logout')
    return response.data
  },

  // Get current user
  getCurrentUser: async () => {
    const response = await api.get('/auth/me')
    return response.data.data
  },

  // Update user profile
  updateProfile: async (userData) => {
    const response = await api.put('/auth/updatedetails', userData)
    return response.data.data
  },

  // Update password
  updatePassword: async (passwordData) => {
    const response = await api.put('/auth/updatepassword', passwordData)
    return response.data
  }
}

export default authService