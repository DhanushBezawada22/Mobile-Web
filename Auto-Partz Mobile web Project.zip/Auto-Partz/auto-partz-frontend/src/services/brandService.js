// src/services/brandService.js
import api from './api'

const brandService = {
  // Get all brands
  getBrands: async () => {
    const response = await api.get('/brands')
    return response.data
  },

  // Get single brand
  getBrand: async (id) => {
    const response = await api.get(`/brands/${id}`)
    return response.data
  },

  // Create brand (admin)
  createBrand: async (brandData) => {
    const response = await api.post('/brands', brandData)
    return response.data
  },

  // Update brand (admin)
  updateBrand: async (id, brandData) => {
    const response = await api.put(`/brands/${id}`, brandData)
    return response.data
  },

  // Delete brand (admin)
  deleteBrand: async (id) => {
    const response = await api.delete(`/brands/${id}`)
    return response.data
  },

  // Upload brand logo (admin)
  uploadBrandLogo: async (id, formData) => {
    const response = await api.put(`/brands/${id}/logo`, formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    })
    return response.data
  }
}

export default brandService