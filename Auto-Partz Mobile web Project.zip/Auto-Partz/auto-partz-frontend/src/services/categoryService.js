// src/services/categoryService.js
import api from './api'

const categoryService = {
  // Get all categories
  getCategories: async () => {
    const response = await api.get('/categories')
    return response.data
  },

  // Get single category
  getCategory: async (id) => {
    const response = await api.get(`/categories/${id}`)
    return response.data
  },

  // Create category (admin)
  createCategory: async (categoryData) => {
    const response = await api.post('/categories', categoryData)
    return response.data
  },

  // Update category (admin)
  updateCategory: async (id, categoryData) => {
    const response = await api.put(`/categories/${id}`, categoryData)
    return response.data
  },

  // Delete category (admin)
  deleteCategory: async (id) => {
    const response = await api.delete(`/categories/${id}`)
    return response.data
  },

  // Get subcategories
  getSubcategories: async (categoryId) => {
    const response = await api.get(`/categories/${categoryId}/subcategories`)
    return response.data
  },

  // Create subcategory (admin)
  createSubcategory: async (categoryId, subcategoryData) => {
    const response = await api.post(`/categories/${categoryId}/subcategories`, subcategoryData)
    return response.data
  }
}

export default categoryService