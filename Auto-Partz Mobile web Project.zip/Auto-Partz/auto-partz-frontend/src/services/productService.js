// src/services/productService.js
import api from './api'

const productService = {
  // Get all products with optional filtering
  getProducts: async (params) => {
    const response = await api.get('/products', { params })
    return response.data
  },

  // Get featured products
  getFeaturedProducts: async (limit = 8) => {
    const response = await api.get('/products/featured', { params: { limit } })
    return response.data
  },

  // Get single product by ID
  getProduct: async (id) => {
    const response = await api.get(`/products/${id}`)
    return response.data
  },

  // Create new product (vendor/admin)
  createProduct: async (productData) => {
    const response = await api.post('/products', productData)
    return response.data
  },

  // Update product (vendor/admin)
  updateProduct: async (id, productData) => {
    const response = await api.put(`/products/${id}`, productData)
    return response.data
  },

  // Delete product (vendor/admin)
  deleteProduct: async (id) => {
    const response = await api.delete(`/products/${id}`)
    return response.data
  },

  // Upload product images (vendor/admin)
  uploadProductImages: async (id, formData) => {
    const response = await api.put(`/products/${id}/images`, formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    })
    return response.data
  }
}

export default productService