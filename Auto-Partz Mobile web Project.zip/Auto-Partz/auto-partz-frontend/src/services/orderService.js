// src/services/orderService.js
import api from './api'

const orderService = {
  // Create new order (customer)
  createOrder: async (orderData) => {
    const response = await api.post('/orders', orderData)
    return response.data
  },

  // Get all orders (admin)
  getOrders: async () => {
    const response = await api.get('/orders')
    return response.data
  },

  // Get logged in user orders (customer)
  getMyOrders: async () => {
    const response = await api.get('/orders/myorders')
    return response.data
  },

  // Get vendor orders (vendor)
  getVendorOrders: async () => {
    const response = await api.get('/orders/vendor')
    return response.data
  },

  // Get order by ID (customer/vendor/admin)
  getOrderById: async (id) => {
    const response = await api.get(`/orders/${id}`)
    return response.data
  },

  // Update order status (vendor/admin)
  updateOrderStatus: async (id, status) => {
    const response = await api.put(`/orders/${id}/status`, { status })
    return response.data
  },

  // Update order to paid (admin)
  updateOrderToPaid: async (id, paymentResult) => {
    const response = await api.put(`/orders/${id}/pay`, paymentResult)
    return response.data
  },

  // Validate coupon code
  validateCoupon: async (code) => {
    const response = await api.post('/coupons/validate', { code })
    return response.data
  }
}

export default orderService