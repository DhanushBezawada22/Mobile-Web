// src/components/common/ProductCard.jsx
import { Card, Button, Badge } from 'react-bootstrap'
import { Link } from 'react-router-dom'
import { FaShoppingCart, FaStore } from 'react-icons/fa'
import StarRating from './StarRating'
import { formatCurrency } from '../../utils/formatters'
import useCart from '../../hooks/useCart'
import placeholderImg from '../../assets/placeholder.jpg'
import { getImageUrl } from '../../utils/imageHelper'

const ProductCard = ({ product }) => {
  const { addToCart } = useCart()
  
  const handleAddToCart = () => {
    addToCart(product, 1)
  }
  
  return (
    <Card className="h-100 product-card border-0 shadow-sm">
      <div className="position-relative">
        <Link to={`/product/${product._id}`}>
          <Card.Img 
            variant="top" 
            src={product.images && product.images.length > 0 
              ? getImageUrl(`api/image/products/${product.images[0]}`)
              : placeholderImg }
            alt={product.name}
            className="product-img"
            style={{ height: '200px', objectFit: 'cover' }}
          />
        </Link>
        {product.featured && (
          <Badge 
            bg="primary" 
            className="position-absolute top-0 start-0 m-2"
          >
            Featured
          </Badge>
        )}
      </div>
      
      <Card.Body className="d-flex flex-column">
        <div className="d-flex justify-content-between align-items-start mb-1">
          <Badge bg="secondary" className="text-capitalize">
            {product.vehicleType}
          </Badge>
          <small className="text-muted">
            {product.brand?.name || 'Brand'}
          </small>
        </div>
        
        <Card.Title as="h6" className="mb-1">
          <Link to={`/product/${product._id}`} className="text-decoration-none text-dark">
            {product.name}
          </Link>
        </Card.Title>
        
        <div className="d-flex align-items-center mb-2">
          <StarRating value={product.rating || 0} />
          <small className="ms-1 text-muted">
            ({product.numReviews || 0})
          </small>
        </div>
        
        <div className="d-flex align-items-center mb-2">
          <FaStore size={14} className="text-muted me-1" />
          <small>
            {product.vendor?.shopName || 'Vendor'}
          </small>
        </div>
        
        <div className="mt-auto">
          <div className="d-flex align-items-center mb-2">
            <span className="product-price">
              {formatCurrency(product.price)}
            </span>
            {product.originalPrice && product.originalPrice > product.price && (
              <span className="original-price">
                {formatCurrency(product.originalPrice)}
              </span>
            )}
          </div>
          
          <Button 
            variant="primary" 
            className="w-100 d-flex align-items-center justify-content-center"
            onClick={handleAddToCart}
            disabled={product.quantity <= 0}
          >
            <FaShoppingCart className="me-2" />
            {product.quantity > 0 ? 'Add to Cart' : 'Out of Stock'}
          </Button>
        </div>
      </Card.Body>
    </Card>
  )
}

export default ProductCard