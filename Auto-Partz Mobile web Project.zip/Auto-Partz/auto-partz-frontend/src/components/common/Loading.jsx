// src/components/common/Loading.jsx
import { Spinner, Container } from 'react-bootstrap'

const Loading = ({ size = 'lg', center = true }) => {
  if (center) {
    return (
      <Container className="d-flex justify-content-center align-items-center py-5">
        <Spinner animation="border" role="status" size={size} variant="primary">
          <span className="visually-hidden">Loading...</span>
        </Spinner>
      </Container>
    )
  }
  
  return (
    <Spinner animation="border" role="status" size={size} variant="primary">
      <span className="visually-hidden">Loading...</span>
    </Spinner>
  )
}

export default Loading