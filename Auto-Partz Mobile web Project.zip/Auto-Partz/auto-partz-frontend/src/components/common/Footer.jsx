// src/components/common/Footer.jsx
import { Container, Row, Col, ListGroup, Form, Button } from 'react-bootstrap'
import { Link } from 'react-router-dom'
import { FaFacebook, FaTwitter, FaInstagram, FaYoutube, FaEnvelope } from 'react-icons/fa'

const Footer = () => {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="bg-dark text-light py-5 mt-5">
      <Container>
        <Row className="g-4">
          <Col md={4}>
            <h5 className="fw-bold mb-4">AutoPartz</h5>
            <p className="mb-3">
              Your one-stop shop for quality vehicle parts. Find everything you need for your car or bike.
            </p>
            <div className="d-flex gap-3 mb-3">
              <a href="#" className="text-light fs-5" aria-label="Facebook">
                <FaFacebook />
              </a>
              <a href="#" className="text-light fs-5" aria-label="Twitter">
                <FaTwitter />
              </a>
              <a href="#" className="text-light fs-5" aria-label="Instagram">
                <FaInstagram />
              </a>
              <a href="#" className="text-light fs-5" aria-label="YouTube">
                <FaYoutube />
              </a>
            </div>
          </Col>
          
          <Col md={2} sm={6}>
            <h6 className="fw-bold mb-3">Quick Links</h6>
            <ListGroup variant="flush" className="footer-links">
              <ListGroup.Item className="bg-transparent border-0 ps-0 text-light py-1">
                <Link to="/" className="text-light text-decoration-none">Home</Link>
              </ListGroup.Item>
              <ListGroup.Item className="bg-transparent border-0 ps-0 text-light py-1">
                <Link to="/shop" className="text-light text-decoration-none">Shop</Link>
              </ListGroup.Item>
              <ListGroup.Item className="bg-transparent border-0 ps-0 text-light py-1">
                <Link to="/cart" className="text-light text-decoration-none">Cart</Link>
              </ListGroup.Item>
              <ListGroup.Item className="bg-transparent border-0 ps-0 text-light py-1">
                <Link to="/become-vendor" className="text-light text-decoration-none">Become a Vendor</Link>
              </ListGroup.Item>
            </ListGroup>
          </Col>
          
          <Col md={2} sm={6}>
            <h6 className="fw-bold mb-3">Categories</h6>
            <ListGroup variant="flush" className="footer-links">
              <ListGroup.Item className="bg-transparent border-0 ps-0 text-light py-1">
                <Link to="/shop?category=engine-parts" className="text-light text-decoration-none">Engine Parts</Link>
              </ListGroup.Item>
              <ListGroup.Item className="bg-transparent border-0 ps-0 text-light py-1">
                <Link to="/shop?category=body-parts" className="text-light text-decoration-none">Body Parts</Link>
              </ListGroup.Item>
              <ListGroup.Item className="bg-transparent border-0 ps-0 text-light py-1">
                <Link to="/shop?vehicleType=car" className="text-light text-decoration-none">Car Parts</Link>
              </ListGroup.Item>
              <ListGroup.Item className="bg-transparent border-0 ps-0 text-light py-1">
                <Link to="/shop?vehicleType=bike" className="text-light text-decoration-none">Bike Parts</Link>
              </ListGroup.Item>
            </ListGroup>
          </Col>
          
          <Col md={4}>
            <h6 className="fw-bold mb-3">Subscribe to Our Newsletter</h6>
            <p>Get the latest updates, offers and special announcements.</p>
            <Form className="d-flex mt-3">
              <Form.Control
                type="email"
                placeholder="Your email address"
                className="me-2"
              />
              <Button variant="primary" type="submit">
                <FaEnvelope />
              </Button>
            </Form>
          </Col>
        </Row>
        
        <hr className="my-4" />
        
        <Row>
          <Col>
            <p className="text-center mb-0">
              &copy; {currentYear} AutoPartz. All Rights Reserved.
            </p>
          </Col>
        </Row>
      </Container>
    </footer>
  )
}

export default Footer