// src/components/common/Breadcrumb.jsx
import { Breadcrumb as BootstrapBreadcrumb } from 'react-bootstrap'
import { Link, useLocation } from 'react-router-dom'

const Breadcrumb = ({ items }) => {
  const location = useLocation()
  
  // If no items are provided, generate them from the current path
  if (!items) {
    const paths = location.pathname.split('/').filter(x => x)
    items = [{ label: 'Home', path: '/' }]
    
    let currentPath = ''
    paths.forEach((path, i) => {
      currentPath += `/${path}`
      const isLast = i === paths.length - 1
      
      // Format the label from the path (capitalize, replace hyphens with spaces)
      const label = path
        .split('-')
        .map(word => word.charAt(0).toUpperCase() + word.slice(1))
        .join(' ')
      
      items.push({
        label,
        path: isLast ? null : currentPath
      })
    })
  }

  return (
    <BootstrapBreadcrumb className="my-3">
      {items.map((item, index) => (
        <BootstrapBreadcrumb.Item 
          key={index} 
          active={!item.path}
          linkAs={item.path ? Link : undefined}
          linkProps={item.path ? { to: item.path } : undefined}
        >
          {item.label}
        </BootstrapBreadcrumb.Item>
      ))}
    </BootstrapBreadcrumb>
  )
}

export default Breadcrumb