// src/components/common/VendorRoute.jsx
import { Navigate, Outlet } from 'react-router-dom'
import useAuth from '../../hooks/useAuth'
import Loading from './Loading'

const VendorRoute = () => {
  const { isAuthenticated, isVendor, loading } = useAuth()
  
  if (loading) {
    return <Loading />
  }
  
  return isAuthenticated && isVendor ? <Outlet /> : <Navigate to="/" />
}

export default VendorRoute