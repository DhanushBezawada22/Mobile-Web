// src/components/common/Sidebar.jsx
import { Nav } from 'react-bootstrap'
import { NavLink } from 'react-router-dom'
import { 
  FaHome, 
  FaShoppingCart, 
  FaBoxOpen, 
  FaUsers, 
  FaStore, 
  FaTags,
  FaLayerGroup,
  FaUserCog,
  FaCog,
  FaClipboardList
} from 'react-icons/fa'
import useAuth from '../../hooks/useAuth'

const Sidebar = ({ variant = 'admin' }) => {
  const { isAdmin } = useAuth()
  
  const adminLinks = [
    { path: '/admin/dashboard', name: 'Dashboard', icon: <FaHome /> },
    { path: '/admin/products', name: 'Products', icon: <FaBoxOpen /> },
    { path: '/admin/categories', name: 'Categories', icon: <FaLayerGroup /> },
    { path: '/admin/brands', name: 'Brands', icon: <FaTags /> },
    { path: '/admin/vendors', name: 'Vendors', icon: <FaStore /> },
    { path: '/admin/users', name: 'Users', icon: <FaUsers /> },
    { path: '/admin/orders', name: 'Orders', icon: <FaShoppingCart /> },
  ]
  
  const vendorLinks = [
    { path: '/vendor/dashboard', name: 'Dashboard', icon: <FaHome /> },
    { path: '/vendor/products', name: 'Products', icon: <FaBoxOpen /> },
    { path: '/vendor/orders', name: 'Orders', icon: <FaClipboardList /> },
    { path: '/vendor/settings', name: 'Shop Settings', icon: <FaCog /> },
  ]
  
  const customerLinks = [
    { path: '/profile', name: 'My Profile', icon: <FaUserCog /> },
    { path: '/orders', name: 'My Orders', icon: <FaClipboardList /> },
  ]

  const links = variant === 'admin' 
    ? adminLinks 
    : variant === 'vendor' 
      ? vendorLinks 
      : customerLinks

  return (
    <div className="sidebar bg-light p-3 rounded shadow-sm">
      <Nav className="flex-column">
        {links.map((link, index) => (
          <Nav.Link
            key={index}
            as={NavLink}
            to={link.path}
            className={({ isActive }) => 
              `d-flex align-items-center py-2 ${isActive ? 'active fw-bold bg-primary text-white rounded' : 'text-dark'}`
            }
          >
            <span className="me-2">{link.icon}</span> {link.name}
          </Nav.Link>
        ))}
      </Nav>
    </div>
  )
}

export default Sidebar