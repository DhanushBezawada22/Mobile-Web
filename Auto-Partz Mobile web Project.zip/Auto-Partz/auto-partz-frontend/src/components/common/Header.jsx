// src/components/common/Header.jsx
import { useState } from 'react'
import { Link, NavLink, useNavigate } from 'react-router-dom'
import { Navbar, Nav, Container, Button, Badge, Dropdown, Form, InputGroup } from 'react-bootstrap'
import { FaShoppingCart, FaUser, FaSearch, FaBars, FaTimes, FaCog } from 'react-icons/fa'
import useAuth from '../../hooks/useAuth'
import useCart from '../../hooks/useCart'
import logo from '../../assets/logo.svg'

const Header = () => {
  const { user, isAuthenticated, logout, isAdmin, isVendor } = useAuth()
  const { cartCount } = useCart()
  const navigate = useNavigate()
  const [searchTerm, setSearchTerm] = useState('')
  const [expanded, setExpanded] = useState(false)

  const handleSearch = (e) => {
    e.preventDefault()
    if (searchTerm.trim()) {
      navigate(`/shop?search=${encodeURIComponent(searchTerm.trim())}`)
      setSearchTerm('')
      setExpanded(false)
    }
  }

  const handleLogout = () => {
    logout()
    navigate('/')
  }

  return (
    <header>
      <Navbar 
        bg="white" 
        expand="lg" 
        className="py-3 shadow-sm"
        expanded={expanded}
        onToggle={() => setExpanded(!expanded)}
      >
        <Container>
          <Navbar.Brand as={Link} to="/" className="d-flex align-items-center">
            <img src={logo} alt="AutoPartz Logo" height="40" className="me-2" />
            <span className="fw-bold">AutoPartz</span>
          </Navbar.Brand>

          <div className="d-flex order-lg-2">
            <Link to="/cart" className="nav-link py-2 px-3 position-relative">
              <FaShoppingCart size={20} />
              {cartCount > 0 && (
                <Badge 
                  pill 
                  bg="danger" 
                  className="position-absolute top-0 start-100 translate-middle"
                >
                  {cartCount}
                </Badge>
              )}
            </Link>

            {isAuthenticated ? (
              <Dropdown align="end">
                <Dropdown.Toggle 
                  variant="light" 
                  id="dropdown-basic" 
                  className="border-0 bg-transparent"
                >
                  <div className="d-flex align-items-center">
                    <div className="rounded-circle bg-primary text-white d-flex justify-content-center align-items-center" 
                      style={{ width: '32px', height: '32px' }}>
                      {user.name.charAt(0).toUpperCase()}
                    </div>
                  </div>
                </Dropdown.Toggle>

                <Dropdown.Menu>
                  <Dropdown.Item disabled className="fw-bold text-dark">
                    Hi, {user.name}
                  </Dropdown.Item>
                  <Dropdown.Divider />
                  
                  {isAdmin && (
                    <>
                      <Dropdown.Item as={Link} to="/admin/dashboard">
                        Admin Dashboard
                      </Dropdown.Item>
                      <Dropdown.Divider />
                    </>
                  )}
                  
                  {isVendor && (
                    <>
                      <Dropdown.Item as={Link} to="/vendor/dashboard">
                        Vendor Dashboard
                      </Dropdown.Item>
                      <Dropdown.Divider />
                    </>
                  )}
                  
                  <Dropdown.Item as={Link} to="/profile">
                    <FaUser className="me-2" /> Profile
                  </Dropdown.Item>
                  <Dropdown.Item as={Link} to="/orders">
                    <FaCog className="me-2" /> My Orders
                  </Dropdown.Item>
                  <Dropdown.Divider />
                  <Dropdown.Item onClick={handleLogout}>
                    Logout
                  </Dropdown.Item>
                </Dropdown.Menu>
              </Dropdown>
            ) : (
              <Button 
                as={Link} 
                to="/login" 
                variant="outline-primary" 
                className="ms-3"
              >
                Login
              </Button>
            )}
          </div>

          <Navbar.Toggle aria-controls="navbarScroll">
            {expanded ? <FaTimes /> : <FaBars />}
          </Navbar.Toggle>

          <Navbar.Collapse id="navbarScroll" className="order-lg-1">
            <Nav className="me-auto my-lg-0">
              <Nav.Link 
                as={NavLink} 
                to="/" 
                onClick={() => setExpanded(false)}
                className={({ isActive }) => isActive ? "active fw-bold" : ""}
              >
                Home
              </Nav.Link>
              <Nav.Link 
                as={NavLink} 
                to="/shop" 
                onClick={() => setExpanded(false)}
                className={({ isActive }) => isActive ? "active fw-bold" : ""}
              >
                Shop
              </Nav.Link>
              {!isVendor && !isAdmin && (
                <Nav.Link 
                  as={NavLink} 
                  to="/become-vendor" 
                  onClick={() => setExpanded(false)}
                  className={({ isActive }) => isActive ? "active fw-bold" : ""}
                >
                  Become a Vendor
                </Nav.Link>
              )}
            </Nav>
            
            <Form className="d-flex mt-3 mt-lg-0" onSubmit={handleSearch}>
              <InputGroup>
                <Form.Control
                  type="search"
                  placeholder="Search products..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  aria-label="Search"
                />
                <Button variant="outline-primary" type="submit">
                  <FaSearch />
                </Button>
              </InputGroup>
            </Form>
          </Navbar.Collapse>
        </Container>
      </Navbar>
    </header>
  )
}

export default Header