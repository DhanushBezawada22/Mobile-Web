// src/components/common/StarRating.jsx
import { FaStar, FaStarHalfAlt, FaRegStar } from 'react-icons/fa'

const StarRating = ({ value, text, color = "#ffc107" }) => {
  return (
    <div className="rating-stars d-inline-flex">
      {[1, 2, 3, 4, 5].map((star) => (
        <span key={star} style={{ color }}>
          {value >= star ? (
            <FaStar />
          ) : value >= star - 0.5 ? (
            <FaStarHalfAlt />
          ) : (
            <FaRegStar />
          )}
        </span>
      ))}
      {text && <span className="ms-1">{text}</span>}
    </div>
  )
}

export default StarRating