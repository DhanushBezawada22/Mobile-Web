// src/components/common/SearchBox.jsx
import { useState } from 'react'
import { Form, Button, InputGroup } from 'react-bootstrap'
import { FaSearch } from 'react-icons/fa'

const SearchBox = ({ onSearch, placeholder = 'Search...' }) => {
  const [keyword, setKeyword] = useState('')

  const handleSubmit = (e) => {
    e.preventDefault()
    if (keyword.trim()) {
      onSearch(keyword.trim())
    }
  }

  return (
    <Form onSubmit={handleSubmit} className="d-flex">
      <InputGroup>
        <Form.Control
          type="text"
          name="keyword"
          value={keyword}
          onChange={(e) => setKeyword(e.target.value)}
          placeholder={placeholder}
          className="me-sm-2"
          aria-label="Search"
        />
        <Button type="submit" variant="outline-primary">
          <FaSearch />
        </Button>
      </InputGroup>
    </Form>
  )
}

export default SearchBox