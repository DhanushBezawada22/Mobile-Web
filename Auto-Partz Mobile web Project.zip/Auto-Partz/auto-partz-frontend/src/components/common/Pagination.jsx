// src/components/common/Pagination.jsx
import { Pagination as BootstrapPagination } from 'react-bootstrap'

const Pagination = ({ page, pages, onPageChange }) => {
  // Don't render if only one page
  if (pages <= 1) return null
  
  // Calculate range of pages to show
  const getPageNumbers = () => {
    const pageNumbers = []
    
    // Always show first page
    pageNumbers.push(1)
    
    // Add current page and surrounding pages
    for (let i = Math.max(2, page - 1); i <= Math.min(pages - 1, page + 1); i++) {
      if (!pageNumbers.includes(i)) {
        pageNumbers.push(i)
      }
    }
    
    // Always show last page if there's more than one page
    if (pages > 1) {
      pageNumbers.push(pages)
    }
    
    // Add ellipsis indicators
    const result = []
    let prev = 0
    
    pageNumbers.forEach(p => {
      if (p - prev > 1) {
        result.push('...')
      }
      result.push(p)
      prev = p
    })
    
    return result
  }
  
  return (
    <BootstrapPagination className="justify-content-center my-4">
      <BootstrapPagination.Prev 
        onClick={() => onPageChange(page - 1)} 
        disabled={page === 1}
      />
      
      {getPageNumbers().map((p, index) => (
        p === '...' ? (
          <BootstrapPagination.Ellipsis key={`ellipsis-${index}`} disabled />
        ) : (
          <BootstrapPagination.Item
            key={p}
            active={p === page}
            onClick={() => onPageChange(p)}
          >
            {p}
          </BootstrapPagination.Item>
        )
      ))}
      
      <BootstrapPagination.Next 
        onClick={() => onPageChange(page + 1)} 
        disabled={page === pages}
      />
    </BootstrapPagination>
  )
}

export default Pagination