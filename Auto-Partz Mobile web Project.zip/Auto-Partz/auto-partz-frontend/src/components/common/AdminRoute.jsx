// src/components/common/AdminRoute.jsx
import { Navigate, Outlet } from 'react-router-dom'
import useAuth from '../../hooks/useAuth'
import Loading from './Loading'

const AdminRoute = () => {
  const { isAuthenticated, isAdmin, loading } = useAuth()
  
  if (loading) {
    return <Loading />
  }
  
  return isAuthenticated && isAdmin ? <Outlet /> : <Navigate to="/" />
}

export default AdminRoute