// src/context/CartContext.jsx
import { createContext, useState, useEffect } from 'react'
import { toast } from 'react-toastify'

const CartContext = createContext()

export const CartProvider = ({ children }) => {
  const [cartItems, setCartItems] = useState(localStorage.getItem('cartItems') ? 
    JSON.parse(localStorage.getItem('cartItems')) : [])
  const [coupon, setCoupon] = useState(localStorage.getItem('coupon') ? 
    JSON.parse(localStorage.getItem('coupon')) : null)
  
  // Update localStorage whenever cart changes
  useEffect(() => {
    localStorage.setItem('cartItems', JSON.stringify(cartItems))
  }, [cartItems])
  
  // Update localStorage whenever coupon changes
  useEffect(() => {
    localStorage.setItem('coupon', JSON.stringify(coupon))
  }, [coupon])
  
  // Add item to cart
  const addToCart = (product, quantity = 1) => {
    const existingItem = cartItems.find(item => item.product === product._id)
    
    if (existingItem) {
      // Check if adding would exceed available stock
      if (existingItem.quantity + quantity > product.quantity) {
        toast.warn(`Sorry, only ${product.quantity} items in stock`)
        return false
      }
      
      setCartItems(
        cartItems.map(item => 
          item.product === product._id 
            ? { ...item, quantity: item.quantity + quantity } 
            : item
        )
      )
    } else {
      if (quantity > product.quantity) {
        toast.warn(`Sorry, only ${product.quantity} items in stock`)
        return false
      }
      
      setCartItems([
        ...cartItems, 
        {
          product: product._id,
          name: product.name,
          image: product.images[0] || 'default-product.jpg',
          price: product.price,
          quantity,
          vendor: product.vendor._id || product.vendor,
          countInStock: product.quantity
        }
      ])
    }
    
    toast.success(`${product.name} added to cart`)
    return true
  }
  
  // Remove item from cart
  const removeFromCart = (id) => {
    setCartItems(cartItems.filter(item => item.product !== id))
    toast.info('Item removed from cart')
  }
  
  // Update item quantity
  const updateQuantity = (id, quantity) => {
    const item = cartItems.find(item => item.product === id)
    
    if (quantity > item.countInStock) {
      toast.warn(`Sorry, only ${item.countInStock} items in stock`)
      return false
    }
    
    if (quantity < 1) {
      removeFromCart(id)
      return true
    }
    
    setCartItems(
      cartItems.map(item => 
        item.product === id 
          ? { ...item, quantity } 
          : item
      )
    )
    
    return true
  }
  
  // Clear cart
  const clearCart = () => {
    setCartItems([])
    setCoupon(null)
  }
  
  // Apply coupon
  const applyCoupon = (couponData) => {
    setCoupon(couponData)
    toast.success('Coupon applied successfully')
  }
  
  // Remove coupon
  const removeCoupon = () => {
    setCoupon(null)
    toast.info('Coupon removed')
  }
  
  // Calculate cart totals
  const calculateTotals = () => {
    const itemsPrice = cartItems.reduce(
      (acc, item) => acc + item.price * item.quantity,
      0
    )
    
    let discountAmount = 0
    
    if (coupon) {
      if (coupon.type === 'percentage') {
        discountAmount = (itemsPrice * coupon.value) / 100
      } else {
        discountAmount = coupon.value
      }
      
      // Apply maximum discount if set
      if (coupon.maxDiscount && discountAmount > coupon.maxDiscount) {
        discountAmount = coupon.maxDiscount
      }
    }
    
    const taxRate = 0.10 // 10% tax
    const taxPrice = (itemsPrice - discountAmount) * taxRate
    
    // Shipping is free over $100 after discount
    const shippingPrice = (itemsPrice - discountAmount) > 100 ? 0 : 10
    
    const totalPrice = (itemsPrice - discountAmount) + taxPrice + shippingPrice
    
    return {
      itemsPrice: parseFloat(itemsPrice.toFixed(2)),
      discountAmount: parseFloat(discountAmount.toFixed(2)),
      taxPrice: parseFloat(taxPrice.toFixed(2)),
      shippingPrice: parseFloat(shippingPrice.toFixed(2)),
      totalPrice: parseFloat(totalPrice.toFixed(2))
    }
  }
  
  return (
    <CartContext.Provider
      value={{
        cartItems,
        coupon,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        applyCoupon,
        removeCoupon,
        calculateTotals,
        cartCount: cartItems.reduce((acc, item) => acc + item.quantity, 0)
      }}
    >
      {children}
    </CartContext.Provider>
  )
}

export default CartContext