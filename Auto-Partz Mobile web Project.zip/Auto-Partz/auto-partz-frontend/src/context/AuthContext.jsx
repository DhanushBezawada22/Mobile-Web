// src/context/AuthContext.jsx
import { createContext, useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import authService from '../services/authService'
import { toast } from 'react-toastify'

const AuthContext = createContext()

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)
  const navigate = useNavigate()

  useEffect(() => {
    // Check if user is logged in when app loads
    const loadUser = async () => {
      const token = localStorage.getItem('token')
      if (token) {
        try {
          const userData = await authService.getCurrentUser()
          setUser(userData)
        } catch (error) {
          // Invalid token - clear localStorage
          localStorage.removeItem('token')
          console.error('Token validation error:', error)
        }
      }
      setLoading(false)
    }

    loadUser()
  }, [])

  // Register user
  const register = async (userData) => {
    try {
      setLoading(true)
      const response = await authService.register(userData)
      localStorage.setItem('token', response.token)
      setUser(response.user)
      toast.success('Registration successful!')
      navigate('/')
      return response
    } catch (error) {
      const message = error.response?.data?.error || 'Registration failed'
      toast.error(message)
      throw error
    } finally {
      setLoading(false)
    }
  }

  // Login user
  const login = async (userData) => {
    try {
      setLoading(true)
      const response = await authService.login(userData)
      localStorage.setItem('token', response.token)
      setUser(response.user)
      toast.success('Login successful!')
      window.location.reload();
      
      // Redirect based on user role
      if (response.user.role === 'admin') {
        navigate('/admin/dashboard')
      } else if (response.user.role === 'vendor') {
        navigate('/vendor/dashboard')
      } else {
        navigate('/')
      }
      
      return response
    } catch (error) {
      const message = error.response?.data?.error || 'Login failed'
      toast.error(message)
      throw error
    } finally {
      setLoading(false)
    }
  }

  // Logout user
  const logout = async () => {
    try {
      await authService.logout()
      localStorage.removeItem('token')
      setUser(null)
      toast.success('Logged out successfully')
      navigate('/')
    } catch (error) {
      console.error('Logout error:', error)
    }
  }

  // Update profile
  const updateProfile = async (userData) => {
    try {
      setLoading(true)
      const response = await authService.updateProfile(userData)
      setUser({ ...user, ...response })
      toast.success('Profile updated successfully')
      return response
    } catch (error) {
      const message = error.response?.data?.error || 'Profile update failed'
      toast.error(message)
      throw error
    } finally {
      setLoading(false)
    }
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        register,
        login,
        logout,
        updateProfile,
        isAuthenticated: !!user,
        isAdmin: user?.role === 'admin',
        isVendor: user?.role === 'vendor',
        isCustomer: user?.role === 'customer',
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export default AuthContext