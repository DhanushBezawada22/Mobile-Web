export const getImageUrl = (relativePath) => {
    
    const path = relativePath.startsWith('api/') 
      ? relativePath.substring(4) 
      : relativePath;
    
    return `http://localhost:5000/${path}`;
  };