// src/utils/constants.js
export const VEHICLE_TYPES = [
    { value: 'car', label: 'Car' },
    { value: 'bike', label: 'Motorcycle' },
    { value: 'universal', label: 'Universal' },
  ]
  
  export const USER_ROLES = [
    { value: 'customer', label: 'Customer' },
    { value: 'vendor', label: 'Vendor' },
    { value: 'admin', label: 'Admin' },
  ]
  
  export const ORDER_STATUSES = [
    { value: 'pending', label: 'Pending' },
    { value: 'processing', label: 'Processing' },
    { value: 'shipped', label: 'Shipped' },
    { value: 'delivered', label: 'Delivered' },
    { value: 'cancelled', label: 'Cancelled' },
  ]
  
  export const PAYMENT_METHODS = [
    { value: 'COD', label: 'Cash On Delivery' },
  ]
  
  export const COUPON_TYPES = [
    { value: 'percentage', label: 'Percentage (%)' },
    { value: 'fixed', label: 'Fixed Amount ($)' },
  ]