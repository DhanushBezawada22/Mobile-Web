// src/utils/formatters.js
// Format currency
export const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount)
  }
  
  // Format date
  export const formatDate = (dateString) => {
    const options = { year: 'numeric', month: 'long', day: 'numeric' }
    return new Date(dateString).toLocaleDateString('en-US', options)
  }
  
  // Format date with time
  export const formatDateTime = (dateString) => {
    const options = {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }
    return new Date(dateString).toLocaleDateString('en-US', options)
  }
  
  // Truncate text
  export const truncateText = (text, maxLength = 100) => {
    if (!text) return ''
    return text.length > maxLength ? text.substring(0, maxLength) + '...' : text
  }
  
  // Format order status
  export const formatOrderStatus = (status) => {
    const statusMap = {
      pending: { label: 'Pending', color: 'warning' },
      processing: { label: 'Processing', color: 'info' },
      shipped: { label: 'Shipped', color: 'primary' },
      delivered: { label: 'Delivered', color: 'success' },
      cancelled: { label: 'Cancelled', color: 'danger' },
    }
    
    return statusMap[status] || { label: status, color: 'secondary' }
  }