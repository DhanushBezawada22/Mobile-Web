// src/utils/validators.js
// Email validator
export const isValidEmail = (email) => {
    const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
    return re.test(String(email).toLowerCase())
  }
  
  // Password validator (min 6 chars)
  export const isValidPassword = (password) => {
    return password && password.length >= 6
  }
  
  // Phone number validator
  export const isValidPhone = (phone) => {
    const re = /^\+?[0-9]{10,15}$/
    return re.test(String(phone))
  }
  
  // URL validator
  export const isValidUrl = (url) => {
    try {
      new URL(url)
      return true
    } catch (error) {
      return false
    }
  }
  
  // Required field validator
  export const isRequired = (value) => {
    return value !== undefined && value !== null && value !== ''
  }
  
  // Min length validator
  export const minLength = (value, min) => {
    return value && value.length >= min
  }
  
  // Max length validator
  export const maxLength = (value, max) => {
    return value && value.length <= max
  }
  
  // Numeric validator
  export const isNumeric = (value) => {
    return !isNaN(parseFloat(value)) && isFinite(value)
  }
  
  // Positive number validator
  export const isPositive = (value) => {
    return parseFloat(value) > 0
  }