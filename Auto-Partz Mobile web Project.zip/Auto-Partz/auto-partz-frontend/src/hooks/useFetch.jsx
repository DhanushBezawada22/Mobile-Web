// src/hooks/useFetch.jsx
import { useState, useEffect, useCallback } from 'react'
import axios from 'axios'

const useFetch = (url, initialData = null) => {
  const [data, setData] = useState(initialData)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const fetchData = useCallback(async () => {
    try {
      setLoading(true)
      setError(null)
      
      const token = localStorage.getItem('token')
      const config = token ? { headers: { Authorization: `Bearer ${token}` } } : {}
      
      const response = await axios.get(url, config)
      setData(response.data.data)
    } catch (err) {
      setError(err.response?.data?.error || 'Something went wrong')
      console.error('Fetch error:', err)
    } finally {
      setLoading(false)
    }
  }, [url])

  useEffect(() => {
    fetchData()
  }, [fetchData])

  const refetch = () => {
    fetchData()
  }

  return { data, loading, error, refetch }
}

export default useFetch