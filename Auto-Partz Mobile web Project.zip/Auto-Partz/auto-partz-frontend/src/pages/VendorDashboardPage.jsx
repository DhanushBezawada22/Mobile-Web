// src/pages/VendorDashboardPage.jsx
import { useState, useEffect } from 'react'
import { Container, Row, Col, Card, Table, Button, Badge, ListGroup, Alert } from 'react-bootstrap'
import { Link } from 'react-router-dom'
import { 
  FaBox, 
  FaClipboardList, 
  FaShoppingCart, 
  FaChartBar, 
  FaStore,
  FaExclamationTriangle,
  FaInfoCircle
} from 'react-icons/fa'
import Breadcrumb from '../components/common/Breadcrumb'
import Sidebar from '../components/common/Sidebar'
import Loading from '../components/common/Loading'
import ErrorMessage from '../components/common/ErrorMessage'
import useAuth from '../hooks/useAuth'
import vendorService from '../services/vendorService'
import orderService from '../services/orderService'
import productService from '../services/productService'
import { formatCurrency, formatDate } from '../utils/formatters'

const VendorDashboardPage = () => {
  const { user } = useAuth()
  
  const [vendor, setVendor] = useState(null)
  const [recentOrders, setRecentOrders] = useState([])
  const [topProducts, setTopProducts] = useState([])
  const [stats, setStats] = useState({
    totalProducts: 0,
    totalOrders: 0,
    pendingOrders: 0,
    lowStockProducts: 0
  })
  
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  
  useEffect(() => {
    const fetchVendorDashboard = async () => {
      try {
        setLoading(true)
        setError(null)
        
        console.log("User in VendorDashboardPage:", user);
        // Get vendor profile
        const vendorResponse = await vendorService.getVendorByUser(user._id)
        setVendor(vendorResponse.data)
        
        // Get products
        const productsResponse = await productService.getProducts({
          vendor: vendorResponse.data._id,
          limit: 100 // Fetch all products for stats
        })
        
        const products = productsResponse.data
        setTopProducts(
          [...products]
            .sort((a, b) => b.numReviews - a.numReviews)
            .slice(0, 5)
        )
        
        // Get orders
        const ordersResponse = await orderService.getVendorOrders()
        const orders = ordersResponse.data
        setRecentOrders(orders.slice(0, 5))
        
        // Calculate stats
        setStats({
          totalProducts: products.length,
          totalOrders: orders.length,
          pendingOrders: orders.filter(order => 
            order.status === 'pending' || order.status === 'processing'
          ).length,
          lowStockProducts: products.filter(product => 
            product.quantity <= 5 && product.quantity > 0
          ).length
        })
      } catch (err) {
        setError(err.response?.data?.error || 'Failed to load dashboard data')
        console.error('Error fetching vendor dashboard:', err)
      } finally {
        setLoading(false)
      }
    }
    
    if (user) {
      fetchVendorDashboard()
    }
  }, [user])
  
  if (loading) return <Loading />
  if (error) return <ErrorMessage>{error}</ErrorMessage>
  
  return (
    <Container>
      <Breadcrumb items={[
        { label: 'Home', path: '/' },
        { label: 'Vendor Dashboard', path: null }
      ]} />
      
      <Row>
        <Col lg={3} className="mb-4">
          <Sidebar variant="vendor" />
        </Col>
        
        <Col lg={9}>
          {!vendor?.isVerified && (
            <Alert variant="warning" className="mb-4">
              <div className="d-flex align-items-center">
                <FaExclamationTriangle className="me-2" />
                <div>
                  <strong>Your vendor account is pending verification.</strong>
                  <div>You can add products, but they won't be visible to customers until your account is verified.</div>
                </div>
              </div>
            </Alert>
          )}
          
          {/* Stats Cards */}
          <Row className="g-4 mb-4">
            <Col sm={6} xl={3}>
              <Card className="border-0 shadow-sm h-100">
                <Card.Body className="d-flex align-items-center">
                  <div className="rounded-circle bg-primary bg-opacity-10 p-3 me-3">
                    <FaBox className="text-primary" size={24} />
                  </div>
                  <div>
                    <h6 className="mb-0 text-muted">Total Products</h6>
                    <h4 className="mt-1 mb-0">{stats.totalProducts}</h4>
                  </div>
                </Card.Body>
              </Card>
            </Col>
            
            <Col sm={6} xl={3}>
              <Card className="border-0 shadow-sm h-100">
                <Card.Body className="d-flex align-items-center">
                  <div className="rounded-circle bg-success bg-opacity-10 p-3 me-3">
                    <FaClipboardList className="text-success" size={24} />
                  </div>
                  <div>
                    <h6 className="mb-0 text-muted">Total Orders</h6>
                    <h4 className="mt-1 mb-0">{stats.totalOrders}</h4>
                  </div>
                </Card.Body>
              </Card>
            </Col>
            
            <Col sm={6} xl={3}>
              <Card className="border-0 shadow-sm h-100">
                <Card.Body className="d-flex align-items-center">
                  <div className="rounded-circle bg-warning bg-opacity-10 p-3 me-3">
                    <FaShoppingCart className="text-warning" size={24} />
                  </div>
                  <div>
                    <h6 className="mb-0 text-muted">Pending Orders</h6>
                    <h4 className="mt-1 mb-0">{stats.pendingOrders}</h4>
                  </div>
                </Card.Body>
              </Card>
            </Col>
            
            <Col sm={6} xl={3}>
              <Card className="border-0 shadow-sm h-100">
                <Card.Body className="d-flex align-items-center">
                  <div className="rounded-circle bg-danger bg-opacity-10 p-3 me-3">
                    <FaExclamationTriangle className="text-danger" size={24} />
                  </div>
                  <div>
                    <h6 className="mb-0 text-muted">Low Stock</h6>
                    <h4 className="mt-1 mb-0">{stats.lowStockProducts}</h4>
                  </div>
                </Card.Body>
              </Card>
            </Col>
          </Row>
          
          <Row className="g-4">
            {/* Recent Orders */}
            <Col lg={7} className="mb-4">
              <Card className="border-0 shadow-sm h-100">
                <Card.Header className="bg-white border-0 py-3">
                  <div className="d-flex justify-content-between align-items-center">
                    <h5 className="mb-0">Recent Orders</h5>
                    <Button 
                      as={Link} 
                      to="/vendor/orders" 
                      variant="outline-primary" 
                      size="sm"
                    >
                      View All
                    </Button>
                  </div>
                </Card.Header>
                <Card.Body className="p-0">
                  {recentOrders.length === 0 ? (
                    <div className="text-center py-5">
                      <FaClipboardList size={32} className="text-muted mb-3" />
                      <p className="mb-0">No orders yet</p>
                    </div>
                  ) : (
                    <div className="table-responsive">
                      <Table hover className="mb-0">
                        <thead>
                          <tr>
                            <th>Order ID</th>
                            <th>Date</th>
                            <th>Amount</th>
                            <th>Status</th>
                          </tr>
                        </thead>
                        <tbody>
                          {recentOrders.map(order => (
                            <tr key={order._id}>
                              <td>
                                <Link 
                                  to={`/vendor/orders/${order._id}`}
                                  className="text-decoration-none"
                                >
                                  #{order._id.substring(order._id.length - 6)}
                                </Link>
                              </td>
                              <td>{formatDate(order.createdAt)}</td>
                              <td>{formatCurrency(order.vendorItemsPrice)}</td>
                              <td>
                                <Badge 
                                  bg={
                                    order.status === 'pending' ? 'warning' :
                                    order.status === 'processing' ? 'info' :
                                    order.status === 'shipped' ? 'primary' :
                                    order.status === 'delivered' ? 'success' :
                                    'danger'
                                  }
                                  text={
                                    order.status === 'pending' || 
                                    order.status === 'warning' 
                                      ? 'dark' 
                                      : undefined
                                  }
                                >
                                  {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                                </Badge>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </Table>
                    </div>
                  )}
                </Card.Body>
              </Card>
            </Col>
            
            {/* Top Products */}
            <Col lg={5} className="mb-4">
              <Card className="border-0 shadow-sm h-100">
                <Card.Header className="bg-white border-0 py-3">
                  <div className="d-flex justify-content-between align-items-center">
                    <h5 className="mb-0">Top Products</h5>
                    <Button 
                      as={Link} 
                      to="/vendor/products" 
                      variant="outline-primary" 
                      size="sm"
                    >
                      View All
                    </Button>
                  </div>
                </Card.Header>
                <Card.Body className="p-0">
                  {topProducts.length === 0 ? (
                    <div className="text-center py-5">
                      <FaBox size={32} className="text-muted mb-3" />
                      <p className="mb-0">No products yet</p>
                    </div>
                  ) : (
                    <ListGroup variant="flush">
                      {topProducts.map(product => (
                        <ListGroup.Item key={product._id} className="py-3">
                          <div className="d-flex justify-content-between align-items-center">
                            <div>
                              <h6 className="mb-1">
                                <Link 
                                  to={`/vendor/products/edit/${product._id}`}
                                  className="text-decoration-none"
                                >
                                  {product.name}
                                </Link>
                              </h6>
                              <small className="text-muted">
                                {product.category.name} | {product.vehicleType.toUpperCase()}
                              </small>
                            </div>
                            <div className="text-end">
                              <div>{formatCurrency(product.price)}</div>
                              <small 
                                className={
                                  product.quantity <= 0 ? 'text-danger' :
                                  product.quantity <= 5 ? 'text-warning' :
                                  'text-success'
                                }
                              >
                                {product.quantity <= 0 
                                  ? 'Out of stock' 
                                  : `${product.quantity} in stock`}
                              </small>
                            </div>
                          </div>
                        </ListGroup.Item>
                      ))}
                    </ListGroup>
                  )}
                </Card.Body>
              </Card>
            </Col>
            
            {/* Shop Information */}
            <Col lg={12}>
              <Card className="border-0 shadow-sm">
                <Card.Header className="bg-white border-0 py-3">
                  <div className="d-flex justify-content-between align-items-center">
                    <h5 className="mb-0">Shop Information</h5>
                    <Button 
                      as={Link} 
                      to="/vendor/settings" 
                      variant="outline-primary" 
                      size="sm"
                    >
                      Edit Shop
                    </Button>
                  </div>
                </Card.Header>
                <Card.Body>
                  <Row>
                    <Col md={6}>
                      <div className="mb-4">
                        <div className="d-flex align-items-center mb-3">
                          <div className="rounded-circle bg-primary bg-opacity-10 p-2 me-2">
                            <FaStore className="text-primary" />
                          </div>
                          <h6 className="mb-0">Shop Details</h6>
                        </div>
                        
                        <div className="ms-4">
                          <div className="mb-2">
                            <strong>Name:</strong> {vendor.shopName}
                          </div>
                          <div className="mb-2">
                            <strong>Status:</strong>{' '}
                            {vendor.isVerified ? (
                              <Badge bg="success">Verified</Badge>
                            ) : (
                              <Badge bg="warning" text="dark">Pending Verification</Badge>
                            )}
                          </div>
                          <div>
                            <strong>Joined:</strong> {formatDate(vendor.createdAt)}
                          </div>
                        </div>
                      </div>
                    </Col>
                    
                    <Col md={6}>
                      <div className="mb-4">
                        <div className="d-flex align-items-center mb-3">
                          <div className="rounded-circle bg-primary bg-opacity-10 p-2 me-2">
                            <FaInfoCircle className="text-primary" />
                          </div>
                          <h6 className="mb-0">Contact Information</h6>
                        </div>
                        
                        <div className="ms-4">
                          <div className="mb-2">
                            <strong>Phone:</strong> {vendor.phone}
                          </div>
                          <div className="mb-2">
                            <strong>Email:</strong> {user.email}
                          </div>
                          <div>
                            <strong>Address:</strong> {vendor.address}
                          </div>
                        </div>
                      </div>
                    </Col>
                  </Row>
                  
                  <div className="mt-2">
                    <h6>Description</h6>
                    <p className="text-muted">{vendor.description}</p>
                  </div>
                  
                  {vendor.specialties && vendor.specialties.length > 0 && (
                    <div className="mt-3">
                      <h6>Specialties</h6>
                      <div className="d-flex flex-wrap gap-2">
                        {vendor.specialties.map((specialty, index) => (
                          <Badge key={index} bg="light" text="dark" className="px-3 py-2">
                            {specialty}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </Card.Body>
              </Card>
            </Col>
          </Row>
        </Col>
      </Row>
    </Container>
  )
}

export default VendorDashboardPage