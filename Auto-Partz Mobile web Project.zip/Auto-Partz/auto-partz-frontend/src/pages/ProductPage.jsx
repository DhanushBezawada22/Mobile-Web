// src/pages/ProductPage.jsx
import { useState, useEffect } from 'react'
import { useParams, Link } from 'react-router-dom'
import { Container, Row, Col, Button, Card, Image, Tabs, Tab, Badge, ListGroup, Form } from 'react-bootstrap'
import { FaShoppingCart, FaMinus, FaPlus, FaStore, FaTag, FaCar, FaMotorcycle, FaCog } from 'react-icons/fa'
import Breadcrumb from '../components/common/Breadcrumb'
import StarRating from '../components/common/StarRating'
import Loading from '../components/common/Loading'
import ErrorMessage from '../components/common/ErrorMessage'
import ProductCard from '../components/common/ProductCard'
import productService from '../services/productService'
import useCart from '../hooks/useCart'
import { formatCurrency } from '../utils/formatters'
import placeholderImg from '../assets/placeholder.jpg'
import { getImageUrl } from '../utils/imageHelper';

const ProductPage = () => {
  const { id } = useParams()
  const { addToCart } = useCart()
  const [product, setProduct] = useState(null)
  const [similarProducts, setSimilarProducts] = useState([])
  const [quantity, setQuantity] = useState(1)
  const [activeImage, setActiveImage] = useState(0)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    const fetchProduct = async () => {
      try {
        setLoading(true)
        setError(null)
        
        const response = await productService.getProduct(id)
        setProduct(response.data)
        setActiveImage(0)
        
        // Fetch similar products (same category or brand)
        const similarResponse = await productService.getProducts({
          category: response.data.category._id,
          limit: 4,
        })
        
        // Filter out the current product
        setSimilarProducts(
          similarResponse.data.filter(p => p._id !== response.data._id)
        )
      } catch (err) {
        setError(err.response?.data?.error || 'Failed to load product')
        console.error('Error fetching product:', err)
      } finally {
        setLoading(false)
      }
    }
    
    fetchProduct()
  }, [id])

  const handleIncrementQuantity = () => {
    if (quantity < product.quantity) {
      setQuantity(quantity + 1)
    }
  }

  const handleDecrementQuantity = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1)
    }
  }

  const handleAddToCart = () => {
    addToCart(product, quantity)
  }

  if (loading) return <Loading />
  if (error) return <ErrorMessage>{error}</ErrorMessage>
  if (!product) return <ErrorMessage>Product not found</ErrorMessage>

  return (
    <Container>
      <Breadcrumb items={[
        { label: 'Home', path: '/' },
        { label: 'Shop', path: '/shop' },
        { label: product.name, path: null }
      ]} />
      
      <Row className="mb-5">
        {/* Product Images */}
        <Col md={6} className="mb-4 mb-md-0">
          <Card className="border-0 shadow-sm mb-3">
            <Card.Body className="p-2">
              <Image
                src={product.images && product.images.length > 0
                  ? getImageUrl(`api/image/products/${product.images[0]}`)
                  : placeholderImg}
                //src={placeholderImg}
                alt={product.name}
                fluid
                className="product-main-image"
                style={{ height: '400px', objectFit: 'contain' }}
              />
            </Card.Body>
          </Card>
          
          {product.images && product.images.length > 1 && (
            <Row className="g-2">
              {product.images.map((image, index) => (
                <Col xs={3} key={index}>
                  <Card 
                    className={`border-0 shadow-sm product-thumbnail ${index === activeImage ? 'border border-primary' : ''}`}
                    onClick={() => setActiveImage(index)}
                    style={{ cursor: 'pointer' }}
                  >
                    <Card.Body className="p-1">
                      <Image
                        src={`/uploads/products/${image}`}
                        alt={`${product.name} thumbnail ${index + 1}`}
                        fluid
                        style={{ height: '60px', objectFit: 'contain' }}
                      />
                    </Card.Body>
                  </Card>
                </Col>
              ))}
            </Row>
          )}
        </Col>
        
        {/* Product Details */}
        <Col md={6}>
          <div className="d-flex justify-content-between align-items-start mb-2">
            <div>
              <h2 className="mb-1">{product.name}</h2>
              <div className="d-flex align-items-center">
                <StarRating value={product.rating || 0} />
                <span className="ms-2 text-muted">
                  ({product.numReviews || 0} reviews)
                </span>
              </div>
            </div>
            
            {product.featured && (
              <Badge bg="primary" className="ms-2">
                Featured
              </Badge>
            )}
          </div>
          
          <div className="mb-3">
            <div className="d-flex align-items-center mb-2">
              <FaStore className="text-muted me-2" />
              <Link to={`/shop?vendor=${product.vendor._id}`} className="text-decoration-none">
                {product.vendor.shopName}
              </Link>
            </div>
            
            <div className="d-flex align-items-center mb-2">
              <FaTag className="text-muted me-2" />
              <Link to={`/shop?brand=${product.brand._id}`} className="text-decoration-none">
                {product.brand.name}
              </Link>
            </div>
            
            <div className="d-flex align-items-center">
              {product.vehicleType === 'car' ? (
                <FaCar className="text-muted me-2" />
              ) : product.vehicleType === 'bike' ? (
                <FaMotorcycle className="text-muted me-2" />
              ) : (
                <FaCog className="text-muted me-2" />
              )}
              <span>{product.vehicleModel}</span>
            </div>
          </div>
          
          <hr className="my-3" />
          
          <div className="mb-4">
            <div className="d-flex align-items-center mb-2">
              <h3 className="product-price mb-0">
                {formatCurrency(product.price)}
              </h3>
              {product.originalPrice && product.originalPrice > product.price && (
                <span className="original-price ms-2">
                  {formatCurrency(product.originalPrice)}
                </span>
              )}
            </div>
            
            <Badge 
              bg={product.quantity > 0 ? 'success' : 'danger'}
              className="px-3 py-2"
            >
              {product.quantity > 0 ? 'In Stock' : 'Out of Stock'}
            </Badge>
            
            {product.quantity > 0 && (
              <small className="d-block text-muted mt-1">
                {product.quantity} items available
              </small>
            )}
          </div>
          
          {product.quantity > 0 && (
            <div className="mb-4">
              <div className="d-flex align-items-center mb-3">
                <span className="me-3">Quantity:</span>
                <div className="d-flex border rounded">
                  <Button 
                    variant="light" 
                    className="border-0"
                    onClick={handleDecrementQuantity}
                    disabled={quantity <= 1}
                  >
                    <FaMinus />
                  </Button>
                  <Form.Control
                    type="number"
                    min="1"
                    max={product.quantity}
                    value={quantity}
                    onChange={(e) => setQuantity(Math.min(product.quantity, Math.max(1, parseInt(e.target.value) || 1)))}
                    className="text-center border-0"
                    style={{ width: '60px' }}
                  />
                  <Button 
                    variant="light" 
                    className="border-0"
                    onClick={handleIncrementQuantity}
                    disabled={quantity >= product.quantity}
                  >
                    <FaPlus />
                  </Button>
                </div>
              </div>
              
              <Button 
                variant="primary" 
                size="lg" 
                className="w-100 d-flex align-items-center justify-content-center"
                onClick={handleAddToCart}
              >
                <FaShoppingCart className="me-2" />
                Add to Cart
              </Button>
            </div>
          )}
          
          <hr className="my-4" />
          
          <Tabs defaultActiveKey="description" className="mb-3">
            <Tab eventKey="description" title="Description">
              <Card className="border-0 shadow-sm">
                <Card.Body>
                  <p>{product.description}</p>
                </Card.Body>
              </Card>
            </Tab>
            <Tab eventKey="specifications" title="Specifications">
              <Card className="border-0 shadow-sm">
                <Card.Body>
                  {Object.keys(product.specifications || {}).length > 0 ? (
                    <ListGroup variant="flush">
                      {Object.entries(product.specifications).map(([key, value]) => (
                        <ListGroup.Item key={key} className="d-flex justify-content-between px-0 py-2 bg-transparent">
                          <span className="text-muted">{key}</span>
                          <span className="fw-bold">{value}</span>
                        </ListGroup.Item>
                      ))}
                    </ListGroup>
                  ) : (
                    <p className="text-muted">No specifications available.</p>
                  )}
                </Card.Body>
              </Card>
            </Tab>
          </Tabs>
        </Col>
      </Row>
      
      {/* Similar Products */}
      {similarProducts.length > 0 && (
        <section className="mb-5">
          <h3 className="section-title mb-4">Similar Products</h3>
          <Row className="g-4">
            {similarProducts.map(product => (
              <Col key={product._id} sm={6} md={3}>
                <ProductCard product={product} />
              </Col>
            ))}
          </Row>
        </section>
      )}
    </Container>
  )
}

export default ProductPage