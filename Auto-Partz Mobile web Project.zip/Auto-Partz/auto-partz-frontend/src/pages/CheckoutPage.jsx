// src/pages/CheckoutPage.jsx
import { useState, useEffect } from 'react'
import { Container, Row, Col, Card, Form, Button, Alert, ListGroup } from 'react-bootstrap'
import { useNavigate } from 'react-router-dom'
import { FaShoppingCart, FaMoneyBillWave } from 'react-icons/fa'
import Breadcrumb from '../components/common/Breadcrumb'
import Loading from '../components/common/Loading'
import useCart from '../hooks/useCart'
import useAuth from '../hooks/useAuth'
import orderService from '../services/orderService'
import { formatCurrency } from '../utils/formatters'
import { PAYMENT_METHODS } from '../utils/constants'

const CheckoutPage = () => {
  const { cartItems, calculateTotals, clearCart, coupon } = useCart()
  const { user, isAuthenticated } = useAuth()
  const navigate = useNavigate()
  
  const [formData, setFormData] = useState({
    address: '',
    city: '',
    postalCode: '',
    country: '',
    paymentMethod: 'COD'
  })
  const [errors, setErrors] = useState({})
  const [loading, setLoading] = useState(false)
  const [generalError, setGeneralError] = useState(null)
  
  const totals = calculateTotals()
  
  useEffect(() => {
    // Redirect to cart if cart is empty
    if (cartItems.length === 0) {
      navigate('/cart')
    }
    
    // Redirect to login if not authenticated
    if (!isAuthenticated) {
      navigate('/login?redirect=checkout')
    }
  }, [cartItems, isAuthenticated, navigate])
  
  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData({
      ...formData,
      [name]: value
    })
    
    // Clear error for this field
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: null
      })
    }
    
    // Clear general error
    if (generalError) {
      setGeneralError(null)
    }
  }
  
  const validateForm = () => {
    const newErrors = {}
    
    if (!formData.address.trim()) {
      newErrors.address = 'Address is required'
    }
    
    if (!formData.city.trim()) {
      newErrors.city = 'City is required'
    }
    
    if (!formData.postalCode.trim()) {
      newErrors.postalCode = 'Postal code is required'
    }
    
    if (!formData.country.trim()) {
      newErrors.country = 'Country is required'
    }
    
    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }
  
  const handleSubmit = async (e) => {
    e.preventDefault()
    
    if (!validateForm()) {
      return
    }
    
    try {
      setLoading(true)
      
      const orderData = {
        orderItems: cartItems.map(item => ({
          product: item.product,
          quantity: item.quantity,
        })),
        shippingAddress: {
          address: formData.address,
          city: formData.city,
          postalCode: formData.postalCode,
          country: formData.country,
        },
        paymentMethod: formData.paymentMethod,
        ...(coupon && { couponCode: coupon.code }),
      }
      
      const response = await orderService.createOrder(orderData)
      
      // Clear cart after successful order
      clearCart()
      
      // Redirect to order success page
      navigate(`/order-success/${response.data._id}`)
    } catch (error) {
      setGeneralError(error.response?.data?.error || 'Failed to place order. Please try again.')
    } finally {
      setLoading(false)
    }
  }
  
  if (loading) {
    return <Loading />
  }
  
  return (
    <Container>
      <Breadcrumb items={[
        { label: 'Home', path: '/' },
        { label: 'Cart', path: '/cart' },
        { label: 'Checkout', path: null }
      ]} />
      
      <h1 className="section-title mb-4">Checkout</h1>
      
      <Row>
        <Col lg={8} className="mb-4">
          <Card className="shadow-sm border-0">
            <Card.Body>
              <h5 className="mb-4">Shipping Information</h5>
              
              {generalError && (
                <Alert variant="danger" className="mb-4">
                  {generalError}
                </Alert>
              )}
              
              <Form onSubmit={handleSubmit}>
                <Form.Group className="mb-3" controlId="address">
                  <Form.Label>Address</Form.Label>
                  <Form.Control
                    type="text"
                    name="address"
                    placeholder="Enter your address"
                    value={formData.address}
                    onChange={handleChange}
                    isInvalid={!!errors.address}
                  />
                  <Form.Control.Feedback type="invalid">
                    {errors.address}
                  </Form.Control.Feedback>
                </Form.Group>
                
                <Row>
                  <Col md={6}>
                    <Form.Group className="mb-3" controlId="city">
                      <Form.Label>City</Form.Label>
                      <Form.Control
                        type="text"
                        name="city"
                        placeholder="Enter your city"
                        value={formData.city}
                        onChange={handleChange}
                        isInvalid={!!errors.city}
                      />
                      <Form.Control.Feedback type="invalid">
                        {errors.city}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                  
                  <Col md={6}>
                    <Form.Group className="mb-3" controlId="postalCode">
                      <Form.Label>Postal Code</Form.Label>
                      <Form.Control
                        type="text"
                        name="postalCode"
                        placeholder="Enter your postal code"
                        value={formData.postalCode}
                        onChange={handleChange}
                        isInvalid={!!errors.postalCode}
                      />
                      <Form.Control.Feedback type="invalid">
                        {errors.postalCode}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                </Row>
                
                <Form.Group className="mb-4" controlId="country">
                  <Form.Label>Country</Form.Label>
                  <Form.Control
                    type="text"
                    name="country"
                    placeholder="Enter your country"
                    value={formData.country}
                    onChange={handleChange}
                    isInvalid={!!errors.country}
                  />
                  <Form.Control.Feedback type="invalid">
                    {errors.country}
                  </Form.Control.Feedback>
                </Form.Group>
                
                <h5 className="mb-3">Payment Method</h5>
                
                {PAYMENT_METHODS.map(method => (
                  <Form.Check
                    key={method.value}
                    type="radio"
                    id={`payment-${method.value}`}
                    label={
                      <div className="d-flex align-items-center">
                        <FaMoneyBillWave className="me-2" />
                        {method.label}
                      </div>
                    }
                    name="paymentMethod"
                    value={method.value}
                    checked={formData.paymentMethod === method.value}
                    onChange={handleChange}
                    className="mb-2"
                  />
                ))}
                
                <div className="d-grid mt-4">
                  <Button 
                    variant="primary" 
                    type="submit" 
                    size="lg"
                    disabled={loading || cartItems.length === 0}
                  >
                    <FaShoppingCart className="me-2" /> 
                    Place Order
                  </Button>
                </div>
              </Form>
            </Card.Body>
          </Card>
        </Col>
        
        <Col lg={4}>
          <Card className="shadow-sm border-0 mb-4">
            <Card.Body>
              <h5 className="mb-3">Order Summary</h5>
              
              <ListGroup variant="flush">
                <ListGroup.Item className="px-0">
                  <div className="d-flex justify-content-between">
                    <span>Items ({cartItems.reduce((acc, item) => acc + item.quantity, 0)}):</span>
                    <span>{formatCurrency(totals.itemsPrice)}</span>
                  </div>
                </ListGroup.Item>
                
                {totals.discountAmount > 0 && (
                  <ListGroup.Item className="px-0 text-success">
                    <div className="d-flex justify-content-between">
                      <span>Discount:</span>
                      <span>-{formatCurrency(totals.discountAmount)}</span>
                    </div>
                  </ListGroup.Item>
                )}
                
                <ListGroup.Item className="px-0">
                  <div className="d-flex justify-content-between">
                    <span>Tax (10%):</span>
                    <span>{formatCurrency(totals.taxPrice)}</span>
                  </div>
                </ListGroup.Item>
                
                <ListGroup.Item className="px-0">
                  <div className="d-flex justify-content-between">
                    <span>Shipping:</span>
                    <span>
                      {totals.shippingPrice === 0 
                        ? 'Free' 
                        : formatCurrency(totals.shippingPrice)}
                    </span>
                  </div>
                </ListGroup.Item>
                
                <ListGroup.Item className="px-0 fw-bold">
                  <div className="d-flex justify-content-between">
                    <span>Total:</span>
                    <span>{formatCurrency(totals.totalPrice)}</span>
                  </div>
                </ListGroup.Item>
              </ListGroup>
              
              {coupon && (
                <Alert variant="info" className="mt-3 mb-0">
                  Coupon <strong>{coupon.code}</strong> applied.
                </Alert>
              )}
            </Card.Body>
          </Card>
          
          <Card className="shadow-sm border-0">
            <ListGroup variant="flush">
              <ListGroup.Item className="bg-light fw-bold">
                Order Items ({cartItems.length})
              </ListGroup.Item>
              
              {cartItems.map(item => (
                <ListGroup.Item key={item.product}>
                  <div className="d-flex justify-content-between">
                    <div>
                      <div>{item.name}</div>
                      <div className="text-muted small">
                        {item.quantity} x {formatCurrency(item.price)}
                      </div>
                    </div>
                    <div>
                      {formatCurrency(item.price * item.quantity)}
                    </div>
                  </div>
                </ListGroup.Item>
              ))}
            </ListGroup>
          </Card>
        </Col>
      </Row>
    </Container>
  )
}

export default CheckoutPage