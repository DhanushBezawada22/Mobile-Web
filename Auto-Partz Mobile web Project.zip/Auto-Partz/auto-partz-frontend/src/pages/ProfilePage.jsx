// src/pages/ProfilePage.jsx
import { useState, useEffect } from 'react'
import { Container, Row, Col, Card, Form, Button, Alert, Tab, Nav } from 'react-bootstrap'
import { FaUser, FaLock, FaEnvelope } from 'react-icons/fa'
import Breadcrumb from '../components/common/Breadcrumb'
import Sidebar from '../components/common/Sidebar'
import useAuth from '../hooks/useAuth'
import { isValidEmail } from '../utils/validators'

const ProfilePage = () => {
  const { user, updateProfile } = useAuth()
  
  const [profileData, setProfileData] = useState({
    name: '',
    email: '',
  })
  
  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  })
  
  const [profileErrors, setProfileErrors] = useState({})
  const [passwordErrors, setPasswordErrors] = useState({})
  const [profileLoading, setProfileLoading] = useState(false)
  const [passwordLoading, setPasswordLoading] = useState(false)
  const [profileSuccess, setProfileSuccess] = useState(false)
  const [passwordSuccess, setPasswordSuccess] = useState(false)
  const [profileError, setProfileError] = useState(null)
  const [passwordError, setPasswordError] = useState(null)
  
  useEffect(() => {
    if (user) {
      setProfileData({
        name: user.name || '',
        email: user.email || '',
      })
    }
  }, [user])
  
  const handleProfileChange = (e) => {
    const { name, value } = e.target
    setProfileData({
      ...profileData,
      [name]: value
    })
    
    // Clear error for this field
    if (profileErrors[name]) {
      setProfileErrors({
        ...profileErrors,
        [name]: null
      })
    }
    
    // Clear general error and success
    setProfileError(null)
    setProfileSuccess(false)
  }
  
  const handlePasswordChange = (e) => {
    const { name, value } = e.target
    setPasswordData({
      ...passwordData,
      [name]: value
    })
    
    // Clear error for this field
    if (passwordErrors[name]) {
      setPasswordErrors({
        ...passwordErrors,
        [name]: null
      })
    }
    
    // Clear general error and success
    setPasswordError(null)
    setPasswordSuccess(false)
  }
  
  const validateProfileForm = () => {
    const newErrors = {}
    
    if (!profileData.name.trim()) {
      newErrors.name = 'Name is required'
    }
    
    if (!profileData.email) {
      newErrors.email = 'Email is required'
    } else if (!isValidEmail(profileData.email)) {
      newErrors.email = 'Invalid email address'
    }
    
    setProfileErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }
  
  const validatePasswordForm = () => {
    const newErrors = {}
    
    if (!passwordData.currentPassword) {
      newErrors.currentPassword = 'Current password is required'
    }
    
    if (!passwordData.newPassword) {
      newErrors.newPassword = 'New password is required'
    } else if (passwordData.newPassword.length < 6) {
      newErrors.newPassword = 'Password must be at least 6 characters'
    }
    
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      newErrors.confirmPassword = 'Passwords do not match'
    }
    
    setPasswordErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }
  
  const handleProfileSubmit = async (e) => {
    e.preventDefault()
    
    if (!validateProfileForm()) {
      return
    }
    
    try {
      setProfileLoading(true)
      setProfileError(null)
      setProfileSuccess(false)
      
      await updateProfile(profileData)
      setProfileSuccess(true)
    } catch (error) {
      setProfileError(error.response?.data?.error || 'Failed to update profile')
    } finally {
      setProfileLoading(false)
    }
  }
  
  const handlePasswordSubmit = async (e) => {
    e.preventDefault()
    
    if (!validatePasswordForm()) {
      return
    }
    
    try {
      setPasswordLoading(true)
      setPasswordError(null)
      setPasswordSuccess(false)
      
      await authService.updatePassword(passwordData)
      
      // Clear password fields
      setPasswordData({
        currentPassword: '',
        newPassword: '',
        confirmPassword: '',
      })
      
      setPasswordSuccess(true)
    } catch (error) {
      setPasswordError(error.response?.data?.error || 'Failed to update password')
    } finally {
      setPasswordLoading(false)
    }
  }
  
  return (
    <Container>
      <Breadcrumb items={[
        { label: 'Home', path: '/' },
        { label: 'My Profile', path: null }
      ]} />
      
      <Row>
        <Col lg={3} className="mb-4">
          <Sidebar variant="customer" />
        </Col>
        
        <Col lg={9}>
          <Card className="border-0 shadow-sm">
            <Card.Body>
              <h3 className="mb-4">My Profile</h3>
              
              <Tab.Container defaultActiveKey="profile">
                <Nav variant="tabs" className="mb-4">
                  <Nav.Item>
                    <Nav.Link eventKey="profile">Profile Information</Nav.Link>
                  </Nav.Item>
                  <Nav.Item>
                    <Nav.Link eventKey="password">Change Password</Nav.Link>
                  </Nav.Item>
                </Nav>
                
                <Tab.Content>
                  <Tab.Pane eventKey="profile">
                    {profileSuccess && (
                      <Alert variant="success" className="mb-4">
                        Profile updated successfully!
                      </Alert>
                    )}
                    
                    {profileError && (
                      <Alert variant="danger" className="mb-4">
                        {profileError}
                      </Alert>
                    )}
                    
                    <Form onSubmit={handleProfileSubmit}>
                      <Form.Group className="mb-3" controlId="name">
                        <Form.Label>Full Name</Form.Label>
                        <div className="input-group">
                          <span className="input-group-text">
                            <FaUser />
                          </span>
                          <Form.Control
                            type="text"
                            name="name"
                            placeholder="Enter your full name"
                            value={profileData.name}
                            onChange={handleProfileChange}
                            isInvalid={!!profileErrors.name}
                          />
                        </div>
                        <Form.Control.Feedback type="invalid">
                          {profileErrors.name}
                        </Form.Control.Feedback>
                      </Form.Group>
                      
                      <Form.Group className="mb-4" controlId="email">
                        <Form.Label>Email</Form.Label>
                        <div className="input-group">
                          <span className="input-group-text">
                            <FaEnvelope />
                          </span>
                          <Form.Control
                            type="email"
                            name="email"
                            placeholder="Enter your email"
                            value={profileData.email}
                            onChange={handleProfileChange}
                            isInvalid={!!profileErrors.email}
                          />
                        </div>
                        <Form.Control.Feedback type="invalid">
                          {profileErrors.email}
                        </Form.Control.Feedback>
                      </Form.Group>
                      
                      <Button 
                        variant="primary" 
                        type="submit" 
                        disabled={profileLoading}
                      >
                        {profileLoading ? 'Updating...' : 'Update Profile'}
                      </Button>
                    </Form>
                  </Tab.Pane>
                  
                  <Tab.Pane eventKey="password">
                    {passwordSuccess && (
                      <Alert variant="success" className="mb-4">
                        Password updated successfully!
                      </Alert>
                    )}
                    
                    {passwordError && (
                      <Alert variant="danger" className="mb-4">
                        {passwordError}
                      </Alert>
                    )}
                    
                    <Form onSubmit={handlePasswordSubmit}>
                      <Form.Group className="mb-3" controlId="currentPassword">
                        <Form.Label>Current Password</Form.Label>
                        <div className="input-group">
                          <span className="input-group-text">
                            <FaLock />
                          </span>
                          <Form.Control
                            type="password"
                            name="currentPassword"
                            placeholder="Enter your current password"
                            value={passwordData.currentPassword}
                            onChange={handlePasswordChange}
                            isInvalid={!!passwordErrors.currentPassword}
                          />
                        </div>
                        <Form.Control.Feedback type="invalid">
                          {passwordErrors.currentPassword}
                        </Form.Control.Feedback>
                      </Form.Group>
                      
                      <Form.Group className="mb-3" controlId="newPassword">
                        <Form.Label>New Password</Form.Label>
                        <div className="input-group">
                          <span className="input-group-text">
                            <FaLock />
                          </span>
                          <Form.Control
                            type="password"
                            name="newPassword"
                            placeholder="Enter your new password"
                            value={passwordData.newPassword}
                            onChange={handlePasswordChange}
                            isInvalid={!!passwordErrors.newPassword}
                          />
                        </div>
                        <Form.Control.Feedback type="invalid">
                          {passwordErrors.newPassword}
                        </Form.Control.Feedback>
                      </Form.Group>
                      
                      <Form.Group className="mb-4" controlId="confirmPassword">
                        <Form.Label>Confirm New Password</Form.Label>
                        <div className="input-group">
                          <span className="input-group-text">
                            <FaLock />
                          </span>
                          <Form.Control
                            type="password"
                            name="confirmPassword"
                            placeholder="Confirm your new password"
                            value={passwordData.confirmPassword}
                            onChange={handlePasswordChange}
                            isInvalid={!!passwordErrors.confirmPassword}
                          />
                        </div>
                        <Form.Control.Feedback type="invalid">
                          {passwordErrors.confirmPassword}
                        </Form.Control.Feedback>
                      </Form.Group>
                      
                      <Button 
                        variant="primary" 
                        type="submit" 
                        disabled={passwordLoading}
                      >
                        {passwordLoading ? 'Updating...' : 'Update Password'}
                      </Button>
                    </Form>
                  </Tab.Pane>
                </Tab.Content>
              </Tab.Container>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  )
}

export default ProfilePage