// src/pages/VendorSettingsPage.jsx
import { useState, useEffect } from 'react'
import { Container, Row, Col, Card, Form, Button, Alert, Image } from 'react-bootstrap'
import { FaStore, FaUpload, FaPhone, FaMapMarkerAlt, FaTag, FaExclamationTriangle } from 'react-icons/fa'
import Breadcrumb from '../components/common/Breadcrumb'
import Sidebar from '../components/common/Sidebar'
import Loading from '../components/common/Loading'
import ErrorMessage from '../components/common/ErrorMessage'
import useAuth from '../hooks/useAuth'
import vendorService from '../services/vendorService'
import brandService from '../services/brandService'

const VendorSettingsPage = () => {
  const { user } = useAuth()
  
  const [vendor, setVendor] = useState(null)
  const [brands, setBrands] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [success, setSuccess] = useState(false)
  
  const [formData, setFormData] = useState({
    shopName: '',
    description: '',
    phone: '',
    address: '',
    specialties: '',
    brands: []
  })
  
  const [formErrors, setFormErrors] = useState({})
  const [logoFile, setLogoFile] = useState(null)
  const [logoPreview, setLogoPreview] = useState(null)
  const [updateLoading, setUpdateLoading] = useState(false)
  
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true)
        
        // Fetch vendor profile
        const vendorResponse = await vendorService.getVendorByUser(user._id)
        setVendor(vendorResponse.data)
        
        // Fetch brands for selection
        const brandsResponse = await brandService.getBrands()
        setBrands(brandsResponse.data)
        
        // Initialize form data
        setFormData({
          shopName: vendorResponse.data.shopName || '',
          description: vendorResponse.data.description || '',
          phone: vendorResponse.data.phone || '',
          address: vendorResponse.data.address || '',
          specialties: vendorResponse.data.specialties ? vendorResponse.data.specialties.join(', ') : '',
          brands: vendorResponse.data.brands ? vendorResponse.data.brands.map(b => 
            typeof b === 'object' ? b._id : b
          ) : []
        })
      } catch (err) {
        setError(err.response?.data?.error || 'Failed to load vendor profile')
        console.error('Error fetching vendor settings:', err)
      } finally {
        setLoading(false)
      }
    }
    
    fetchData()
  }, [user])
  
  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData({
      ...formData,
      [name]: value
    })
    
    // Clear error for this field
    if (formErrors[name]) {
      setFormErrors({
        ...formErrors,
        [name]: null
      })
    }
    
    // Clear success message
    setSuccess(false)
  }
  
  const handleBrandChange = (e) => {
    const options = e.target.options
    const selectedValues = []
    
    for (let i = 0; i < options.length; i++) {
      if (options[i].selected) {
        selectedValues.push(options[i].value)
      }
    }
    
    setFormData({
      ...formData,
      brands: selectedValues
    })
    
    // Clear success message
    setSuccess(false)
  }
  
  const handleLogoChange = (e) => {
    const file = e.target.files[0]
    
    if (file) {
      setLogoFile(file)
      
      // Create preview URL
      const previewUrl = URL.createObjectURL(file)
      setLogoPreview(previewUrl)
    }
    
    // Clear success message
    setSuccess(false)
  }
  
  const validateForm = () => {
    const errors = {}
    
    if (!formData.shopName.trim()) {
      errors.shopName = 'Shop name is required'
    }
    
    if (!formData.description.trim()) {
      errors.description = 'Description is required'
    } else if (formData.description.length < 20) {
      errors.description = 'Description must be at least 20 characters'
    }
    
    if (!formData.phone.trim()) {
      errors.phone = 'Phone number is required'
    }
    
    if (!formData.address.trim()) {
      errors.address = 'Address is required'
    }
    
    setFormErrors(errors)
    return Object.keys(errors).length === 0
  }
  
  const handleSubmit = async (e) => {
    e.preventDefault()
    
    if (!validateForm()) {
      return
    }
    
    try {
      setUpdateLoading(true)
      setError(null)
      setSuccess(false)
      
      // Prepare vendor data
      const vendorData = {
        shopName: formData.shopName,
        description: formData.description,
        phone: formData.phone,
        address: formData.address,
        specialties: formData.specialties
          ? formData.specialties.split(',').map(item => item.trim())
          : [],
        brands: formData.brands
      }
      
      // Update vendor profile
      const response = await vendorService.updateVendor(vendor._id, vendorData)
      
      // Upload logo if selected
      if (logoFile) {
        const logoFormData = new FormData()
        logoFormData.append('logo', logoFile)
        
        await vendorService.uploadVendorLogo(vendor._id, logoFormData)
      }
      
      // Update local state
      setVendor(response.data)
      setSuccess(true)
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to update vendor profile')
      console.error('Error updating vendor settings:', err)
    } finally {
      setUpdateLoading(false)
    }
  }
  
  if (loading) return <Loading />
  if (error && !vendor) return <ErrorMessage>{error}</ErrorMessage>
  
  return (
    <Container>
      <Breadcrumb items={[
        { label: 'Home', path: '/' },
        { label: 'Vendor Dashboard', path: '/vendor/dashboard' },
        { label: 'Shop Settings', path: null }
      ]} />
      
      <Row>
        <Col lg={3} className="mb-4">
          <Sidebar variant="vendor" />
        </Col>
        
        <Col lg={9}>
          {!vendor?.isVerified && (
            <Alert variant="warning" className="mb-4">
              <div className="d-flex align-items-center">
                <FaExclamationTriangle className="me-2" />
                <div>
                  <strong>Your vendor account is pending verification.</strong>
                  <div>You can update your shop information, but your shop won't be visible to customers until your account is verified.</div>
                </div>
              </div>
            </Alert>
          )}
          
          <Card className="border-0 shadow-sm mb-4">
            <Card.Body>
              <h3 className="mb-4">Shop Settings</h3>
              
              {success && (
                <Alert variant="success" className="mb-4">
                  Shop information updated successfully!
                </Alert>
              )}
              
              {error && (
                <Alert variant="danger" className="mb-4">
                  {error}
                </Alert>
              )}
              
              <Form onSubmit={handleSubmit}>
                <Row>
                  <Col md={8}>
                    <Form.Group className="mb-3" controlId="shopName">
                      <Form.Label>Shop Name</Form.Label>
                      <div className="input-group">
                        <span className="input-group-text">
                          <FaStore />
                        </span>
                        <Form.Control
                          type="text"
                          name="shopName"
                          value={formData.shopName}
                          onChange={handleChange}
                          isInvalid={!!formErrors.shopName}
                          placeholder="Enter your shop name"
                        />
                      </div>
                      <Form.Control.Feedback type="invalid">
                        {formErrors.shopName}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                  
                  <Col md={4}>
                    <Form.Group controlId="shopLogo" className="mb-3">
                      <Form.Label>Shop Logo</Form.Label>
                      <div className="text-center">
                        <div 
                          className="position-relative d-inline-block mb-2"
                          style={{ width: '120px', height: '120px' }}
                        >
                          <Image 
                            src={logoPreview || (vendor.logo ? `/uploads/vendors/${vendor.logo}` : '/placeholder.jpg')}
                            alt="Shop Logo"
                            width={120}
                            height={120}
                            className="border rounded"
                            style={{ objectFit: 'cover' }}
                          />
                          <div 
                            className="position-absolute top-0 end-0 bottom-0 start-0 d-flex align-items-center justify-content-center bg-dark bg-opacity-50"
                            style={{ cursor: 'pointer', borderRadius: '4px' }}
                            onClick={() => document.getElementById('logoInput').click()}
                          >
                            <FaUpload color="white" size={24} />
                          </div>
                        </div>
                        <Form.Control
                          type="file"
                          onChange={handleLogoChange}
                          className="d-none"
                          id="logoInput"
                          accept="image/*"
                        />
                        <div className="text-muted small">
                          Click to upload a logo
                        </div>
                      </div>
                    </Form.Group>
                  </Col>
                </Row>
                
                <Form.Group className="mb-3" controlId="description">
                  <Form.Label>Shop Description</Form.Label>
                  <Form.Control
                    as="textarea"
                    rows={4}
                    name="description"
                    value={formData.description}
                    onChange={handleChange}
                    isInvalid={!!formErrors.description}
                    placeholder="Describe your shop and products"
                  />
                  <Form.Control.Feedback type="invalid">
                    {formErrors.description}
                  </Form.Control.Feedback>
                </Form.Group>
                
                <Row>
                  <Col md={6}>
                    <Form.Group className="mb-3" controlId="phone">
                      <Form.Label>Phone Number</Form.Label>
                      <div className="input-group">
                        <span className="input-group-text">
                          <FaPhone />
                        </span>
                        <Form.Control
                          type="text"
                          name="phone"
                          value={formData.phone}
                          onChange={handleChange}
                          isInvalid={!!formErrors.phone}
                          placeholder="Enter your phone number"
                        />
                      </div>
                      <Form.Control.Feedback type="invalid">
                        {formErrors.phone}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                  
                  <Col md={6}>
                    <Form.Group className="mb-3" controlId="specialties">
                      <Form.Label>Specialties (Comma Separated)</Form.Label>
                      <Form.Control
                        type="text"
                        name="specialties"
                        value={formData.specialties}
                        onChange={handleChange}
                        placeholder="e.g. Honda Parts, Bike Parts"
                      />
                      <Form.Text className="text-muted">
                        Enter your shop specialties separated by commas
                      </Form.Text>
                    </Form.Group>
                  </Col>
                </Row>
                
                <Form.Group className="mb-4" controlId="address">
                  <Form.Label>Business Address</Form.Label>
                  <div className="input-group">
                    <span className="input-group-text">
                      <FaMapMarkerAlt />
                    </span>
                    <Form.Control
                      type="text"
                      name="address"
                      value={formData.address}
                      onChange={handleChange}
                      isInvalid={!!formErrors.address}
                      placeholder="Enter your business address"
                    />
                  </div>
                  <Form.Control.Feedback type="invalid">
                    {formErrors.address}
                  </Form.Control.Feedback>
                </Form.Group>
                
                <Form.Group className="mb-4" controlId="brands">
                  <Form.Label>Brands You Sell</Form.Label>
                  <div className="input-group">
                    <span className="input-group-text">
                      <FaTag />
                    </span>
                    <Form.Select
                      multiple
                      name="brands"
                      value={formData.brands}
                      onChange={handleBrandChange}
                      style={{ height: '120px' }}
                    >
                      {brands.map(brand => (
                        <option key={brand._id} value={brand._id}>
                          {brand.name}
                        </option>
                      ))}
                    </Form.Select>
                  </div>
                  <Form.Text className="text-muted">
                    Hold Ctrl (Cmd on Mac) to select multiple brands
                  </Form.Text>
                </Form.Group>
                
                <div className="d-grid">
                  <Button 
                    variant="primary" 
                    type="submit"
                    size="lg"
                    disabled={updateLoading}
                  >
                    {updateLoading ? 'Saving...' : 'Save Changes'}
                  </Button>
                </div>
              </Form>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  )
}

export default VendorSettingsPage