// src/pages/ShopPage.jsx
import { useState, useEffect } from 'react'
import { Container, Row, Col, Card, Form, Button, Badge } from 'react-bootstrap'
import { useSearchParams } from 'react-router-dom'
import { FaFilter, FaTimes } from 'react-icons/fa'
import ProductCard from '../components/common/ProductCard'
import Loading from '../components/common/Loading'
import ErrorMessage from '../components/common/ErrorMessage'
import Pagination from '../components/common/Pagination'
import Breadcrumb from '../components/common/Breadcrumb'
import productService from '../services/productService'
import categoryService from '../services/categoryService'
import brandService from '../services/brandService'
import { VEHICLE_TYPES } from '../utils/constants'

const ShopPage = () => {
  const [searchParams, setSearchParams] = useSearchParams()
  const [products, setProducts] = useState([])
  const [categories, setCategories] = useState([])
  const [brands, setBrands] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [pagination, setPagination] = useState({
    page: 1,
    pages: 1,
    count: 0
  })
  const [filters, setFilters] = useState({
    search: searchParams.get('search') || '',
    category: searchParams.get('category') || '',
    brand: searchParams.get('brand') || '',
    vehicleType: searchParams.get('vehicleType') || '',
    minPrice: searchParams.get('minPrice') || '',
    maxPrice: searchParams.get('maxPrice') || '',
    sort: searchParams.get('sort') || 'createdAt',
    page: parseInt(searchParams.get('page')) || 1
  })
  const [showFilters, setShowFilters] = useState(false)

  // Fetch products based on filters
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        setLoading(true)
        
        // Build query params
        const params = { ...filters }
        // Remove empty values
        Object.keys(params).forEach(key => {
          if (!params[key]) delete params[key]
        })
        
        const response = await productService.getProducts(params)
        setProducts(response.data)
        setPagination({
          page: filters.page,
          pages: Math.ceil(response.count / 25), // Assuming limit of 25 per page
          count: response.count
        })
      } catch (err) {
        setError(err.response?.data?.error || 'Failed to load products')
        console.error('Error fetching products:', err)
      } finally {
        setLoading(false)
      }
    }
    
    fetchProducts()
  }, [filters])

  // Fetch categories and brands
  useEffect(() => {
    const fetchFilterOptions = async () => {
      try {
        const [categoriesResponse, brandsResponse] = await Promise.all([
          categoryService.getCategories(),
          brandService.getBrands()
        ])
        
        setCategories(categoriesResponse.data)
        setBrands(brandsResponse.data)
      } catch (err) {
        console.error('Error fetching filter options:', err)
      }
    }
    
    fetchFilterOptions()
  }, [])

  // Update search params whenever filters change
  useEffect(() => {
    const params = { ...filters }
    // Remove empty values and default page
    Object.keys(params).forEach(key => {
      if (!params[key] || (key === 'page' && params[key] === 1)) delete params[key]
    })
    
    setSearchParams(params)
  }, [filters, setSearchParams])

  const handleFilterChange = (e) => {
    const { name, value } = e.target
    setFilters({
      ...filters,
      [name]: value,
      page: 1 // Reset to first page when changing filters
    })
  }

  const handlePageChange = (page) => {
    setFilters({
      ...filters,
      page
    })
    window.scrollTo(0, 0)
  }

  const clearFilters = () => {
    setFilters({
      search: '',
      category: '',
      brand: '',
      vehicleType: '',
      minPrice: '',
      maxPrice: '',
      sort: 'createdAt',
      page: 1
    })
  }

  const toggleFilters = () => {
    setShowFilters(!showFilters)
  }

  // Count active filters (excluding search, sort and page)
  const activeFilterCount = Object.entries(filters).filter(
    ([key, value]) => value && !['search', 'sort', 'page'].includes(key)
  ).length

  return (
    <Container>
      <Breadcrumb items={[
        { label: 'Home', path: '/' },
        { label: 'Shop', path: null }
      ]} />
      
      <Row>
        {/* Filter Sidebar - Desktop */}
        <Col lg={3} className="d-none d-lg-block mb-4">
          <Card className="shadow-sm border-0">
            <Card.Body>
              <div className="d-flex justify-content-between align-items-center mb-3">
                <h5 className="mb-0">Filters</h5>
                {activeFilterCount > 0 && (
                  <Button 
                    variant="link" 
                    className="p-0 text-decoration-none" 
                    onClick={clearFilters}
                  >
                    Clear All
                  </Button>
                )}
              </div>
              
              <Form>
                {/* Categories */}
                <Form.Group className="mb-3">
                  <Form.Label className="fw-bold">Category</Form.Label>
                  <Form.Select 
                    name="category"
                    value={filters.category}
                    onChange={handleFilterChange}
                  >
                    <option value="">All Categories</option>
                    {categories.map(category => (
                      <option key={category._id} value={category._id}>
                        {category.name}
                      </option>
                    ))}
                  </Form.Select>
                </Form.Group>
                
                {/* Brands */}
                <Form.Group className="mb-3">
                  <Form.Label className="fw-bold">Brand</Form.Label>
                  <Form.Select 
                    name="brand"
                    value={filters.brand}
                    onChange={handleFilterChange}
                  >
                    <option value="">All Brands</option>
                    {brands.map(brand => (
                      <option key={brand._id} value={brand._id}>
                        {brand.name}
                      </option>
                    ))}
                  </Form.Select>
                </Form.Group>
                
                {/* Vehicle Type */}
                <Form.Group className="mb-3">
                  <Form.Label className="fw-bold">Vehicle Type</Form.Label>
                  <Form.Select 
                    name="vehicleType"
                    value={filters.vehicleType}
                    onChange={handleFilterChange}
                  >
                    <option value="">All Types</option>
                    {VEHICLE_TYPES.map(type => (
                      <option key={type.value} value={type.value}>
                        {type.label}
                      </option>
                    ))}
                  </Form.Select>
                </Form.Group>
                
                {/* Price Range */}
                <Form.Group className="mb-3">
                  <Form.Label className="fw-bold">Price Range</Form.Label>
                  <Row>
                    <Col xs={6}>
                      <Form.Control 
                        type="number" 
                        placeholder="Min" 
                        name="minPrice"
                        value={filters.minPrice}
                        onChange={handleFilterChange}
                      />
                    </Col>
                    <Col xs={6}>
                      <Form.Control 
                        type="number" 
                        placeholder="Max"
                        name="maxPrice"
                        value={filters.maxPrice}
                        onChange={handleFilterChange}
                      />
                    </Col>
                  </Row>
                </Form.Group>
              </Form>
            </Card.Body>
          </Card>
        </Col>
        
        {/* Product Grid */}
        <Col lg={9}>
          {/* Search and Sort Controls */}
          <div className="d-flex flex-wrap justify-content-between align-items-center mb-4">
            <div className="d-flex align-items-center mb-3 mb-md-0">
              <Button 
                variant="outline-secondary" 
                className="me-2 d-lg-none"
                onClick={toggleFilters}
              >
                <FaFilter /> Filters
                {activeFilterCount > 0 && (
                  <Badge bg="primary" pill className="ms-1">
                    {activeFilterCount}
                  </Badge>
                )}
              </Button>
              
              <div>
                <h4 className="mb-0">Products</h4>
                {pagination.count > 0 && (
                  <small className="text-muted">
                    Showing {products.length} of {pagination.count} results
                  </small>
                )}
              </div>
            </div>
            
            <div className="d-flex">
              <Form.Select 
                className="me-2" 
                style={{ width: 'auto' }}
                name="sort"
                value={filters.sort}
                onChange={handleFilterChange}
              >
                <option value="createdAt">Newest</option>
                <option value="-createdAt">Oldest</option>
                <option value="price">Price: Low to High</option>
                <option value="-price">Price: High to Low</option>
                <option value="name">Name: A to Z</option>
                <option value="-name">Name: Z to A</option>
              </Form.Select>
            </div>
          </div>
          
          {/* Mobile Filters */}
          {showFilters && (
            <Card className="shadow-sm border-0 mb-4 d-lg-none">
              <Card.Body>
                <div className="d-flex justify-content-between align-items-center mb-3">
                  <h5 className="mb-0">Filters</h5>
                  <Button 
                    variant="link"
                    className="p-0"
                    onClick={toggleFilters}
                  >
                    <FaTimes />
                  </Button>
                </div>
                
                <Form>
                  {/* Categories */}
                  <Form.Group className="mb-3">
                    <Form.Label className="fw-bold">Category</Form.Label>
                    <Form.Select 
                      name="category"
                      value={filters.category}
                      onChange={handleFilterChange}
                    >
                      <option value="">All Categories</option>
                      {categories.map(category => (
                        <option key={category._id} value={category._id}>
                          {category.name}
                        </option>
                      ))}
                    </Form.Select>
                  </Form.Group>
                  
                  {/* Brands */}
                  <Form.Group className="mb-3">
                    <Form.Label className="fw-bold">Brand</Form.Label>
                    <Form.Select 
                      name="brand"
                      value={filters.brand}
                      onChange={handleFilterChange}
                    >
                      <option value="">All Brands</option>
                      {brands.map(brand => (
                        <option key={brand._id} value={brand._id}>
                          {brand.name}
                        </option>
                      ))}
                    </Form.Select>
                  </Form.Group>
                  
                  {/* Vehicle Type */}
                  <Form.Group className="mb-3">
                    <Form.Label className="fw-bold">Vehicle Type</Form.Label>
                    <Form.Select 
                      name="vehicleType"
                      value={filters.vehicleType}
                      onChange={handleFilterChange}
                    >
                      <option value="">All Types</option>
                      {VEHICLE_TYPES.map(type => (
                        <option key={type.value} value={type.value}>
                          {type.label}
                        </option>
                      ))}
                    </Form.Select>
                  </Form.Group>
                  
                  {/* Price Range */}
                  <Form.Group className="mb-3">
                    <Form.Label className="fw-bold">Price Range</Form.Label>
                    <Row>
                      <Col xs={6}>
                        <Form.Control 
                          type="number" 
                          placeholder="Min" 
                          name="minPrice"
                          value={filters.minPrice}
                          onChange={handleFilterChange}
                        />
                      </Col>
                      <Col xs={6}>
                        <Form.Control 
                          type="number" 
                          placeholder="Max"
                          name="maxPrice"
                          value={filters.maxPrice}
                          onChange={handleFilterChange}
                        />
                      </Col>
                    </Row>
                  </Form.Group>
                  
                  <div className="d-flex justify-content-between">
                    <Button 
                      variant="outline-secondary"
                      onClick={clearFilters}
                    >
                      Clear All
                    </Button>
                    <Button 
                      variant="primary"
                      onClick={toggleFilters}
                    >
                      Apply Filters
                    </Button>
                  </div>
                </Form>
              </Card.Body>
            </Card>
          )}
          
          {/* Applied Filters */}
          {activeFilterCount > 0 && (
            <div className="mb-3 d-flex flex-wrap gap-2">
              {filters.category && (
                <Badge 
                  bg="light" 
                  text="dark" 
                  className="py-2 px-3 fs-6"
                >
                  Category: {categories.find(c => c._id === filters.category)?.name || 'Unknown'}
                  <Button 
                    variant="link" 
                    className="p-0 ms-2 text-dark" 
                    onClick={() => handleFilterChange({ target: { name: 'category', value: '' } })}
                  >
                    <FaTimes size={12} />
                  </Button>
                </Badge>
              )}
              
              {filters.brand && (
                <Badge 
                  bg="light" 
                  text="dark" 
                  className="py-2 px-3 fs-6"
                >
                  Brand: {brands.find(b => b._id === filters.brand)?.name || 'Unknown'}
                  <Button 
                    variant="link" 
                    className="p-0 ms-2 text-dark"
                    onClick={() => handleFilterChange({ target: { name: 'brand', value: '' } })}
                  >
                    <FaTimes size={12} />
                  </Button>
                </Badge>
              )}
              
              {filters.vehicleType && (
                <Badge 
                  bg="light" 
                  text="dark" 
                  className="py-2 px-3 fs-6"
                >
                  Vehicle: {VEHICLE_TYPES.find(t => t.value === filters.vehicleType)?.label || 'Unknown'}
                  <Button 
                    variant="link" 
                    className="p-0 ms-2 text-dark"
                    onClick={() => handleFilterChange({ target: { name: 'vehicleType', value: '' } })}
                  >
                    <FaTimes size={12} />
                  </Button>
                </Badge>
              )}
              
              {(filters.minPrice || filters.maxPrice) && (
                <Badge 
                  bg="light" 
                  text="dark" 
                  className="py-2 px-3 fs-6"
                >
                  Price: {filters.minPrice ? `$${filters.minPrice}` : '$0'} - {filters.maxPrice ? `$${filters.maxPrice}` : 'Any'}
                  <Button 
                    variant="link" 
                    className="p-0 ms-2 text-dark"
                    onClick={() => {
                      handleFilterChange({ target: { name: 'minPrice', value: '' } })
                      handleFilterChange({ target: { name: 'maxPrice', value: '' } })
                    }}
                  >
                    <FaTimes size={12} />
                  </Button>
                </Badge>
              )}
            </div>
          )}
          
          {/* Product Results */}
          {loading ? (
            <Loading />
          ) : error ? (
            <ErrorMessage>{error}</ErrorMessage>
          ) : products.length === 0 ? (
            <Card className="text-center p-5 border-0 shadow-sm">
              <Card.Body>
                <h3>No Products Found</h3>
                <p>Try changing your filters or check back later.</p>
                {activeFilterCount > 0 && (
                  <Button variant="outline-primary" onClick={clearFilters}>
                    Clear All Filters
                  </Button>
                )}
              </Card.Body>
            </Card>
          ) : (
            <>
              <Row className="g-4">
                {products.map(product => (
                  <Col key={product._id} sm={6} md={6} lg={4}>
                    <ProductCard product={product} />
                  </Col>
                ))}
              </Row>
              
              <Pagination 
                page={pagination.page} 
                pages={pagination.pages}
                onPageChange={handlePageChange}
              />
            </>
          )}
        </Col>
      </Row>
    </Container>
  )
}

export default ShopPage