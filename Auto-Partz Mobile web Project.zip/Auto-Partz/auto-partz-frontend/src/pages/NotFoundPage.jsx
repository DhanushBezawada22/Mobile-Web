// src/pages/NotFoundPage.jsx
import { Container, Row, Col, Button } from 'react-bootstrap'
import { Link } from 'react-router-dom'
import { FaHome, FaArrowLeft } from 'react-icons/fa'
import notFoundImg from '../assets/not-found.jpg'

const NotFoundPage = () => {
  return (
    <Container className="py-5 text-center">
      <Row className="justify-content-center">
        <Col md={8} lg={6}>
          <img 
            src={notFoundImg} 
            alt="Not Found" 
            className="img-fluid mb-4" 
            style={{ maxHeight: '300px' }}
          />
          
          <h1 className="mb-3">Page Not Found</h1>
          <p className="lead text-muted mb-4">
            The page you are looking for doesn't exist or has been moved.
          </p>
          
          <div className="d-flex justify-content-center gap-3">
            <Button as={Link} to="/" variant="primary">
              <FaHome className="me-2" /> Back to Home
            </Button>
            <Button 
              onClick={() => window.history.back()} 
              variant="outline-secondary"
            >
              <FaArrowLeft className="me-2" /> Go Back
            </Button>
          </div>
        </Col>
      </Row>
    </Container>
  )
}

export default NotFoundPage