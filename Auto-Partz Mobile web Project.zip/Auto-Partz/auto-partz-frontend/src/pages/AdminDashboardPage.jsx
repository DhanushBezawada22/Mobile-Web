// src/pages/AdminDashboardPage.jsx
import { useState, useEffect } from 'react'
import { Container, Row, Col, Card, Table, Badge } from 'react-bootstrap'
import { Link } from 'react-router-dom'
import { 
  FaUsers, 
  FaStore, 
  FaShoppingCart, 
  FaBox, 
  FaExclamationTriangle,
  FaUserCheck,
  FaMoneyBillWave,
  FaChartBar
} from 'react-icons/fa'
import Breadcrumb from '../components/common/Breadcrumb'
import Sidebar from '../components/common/Sidebar'
import Loading from '../components/common/Loading'
import ErrorMessage from '../components/common/ErrorMessage'
import userService from '../services/userService'
import vendorService from '../services/vendorService'
import orderService from '../services/orderService'
import productService from '../services/productService'
import { formatCurrency, formatDate } from '../utils/formatters'

const AdminDashboardPage = () => {
  const [stats, setStats] = useState({
    userCount: 0,
    vendorCount: 0,
    productCount: 0,
    orderCount: 0,
    totalSales: 0,
    pendingOrders: 0,
    pendingVendors: 0
  })
  
  const [recentOrders, setRecentOrders] = useState([])
  const [pendingVendors, setPendingVendors] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  
  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        setLoading(true)
        
        // Fetch all the data needed for the dashboard
        const [
          usersResponse,
          vendorsResponse,
          productsResponse,
          ordersResponse
        ] = await Promise.all([
          userService.getUsers(),
          vendorService.getAllVendors(),
          productService.getProducts(),
          orderService.getOrders()
        ])
        
        // Calculate stats
        const users = usersResponse.data
        const vendors = vendorsResponse.data
        const products = productsResponse.data
        const orders = ordersResponse.data
        
        const pendingVendorsList = vendors.filter(vendor => !vendor.isVerified)
        const pendingOrdersList = orders.filter(order => order.status === 'pending')
        const totalSales = orders.reduce((sum, order) => sum + order.totalPrice, 0)
        
        // Set stats
        setStats({
          userCount: users.length,
          vendorCount: vendors.length,
          productCount: products.length,
          orderCount: orders.length,
          totalSales,
          pendingOrders: pendingOrdersList.length,
          pendingVendors: pendingVendorsList.length
        })
        
        // Set recent orders and pending vendors for tables
        setRecentOrders(orders.slice(0, 5))
        setPendingVendors(pendingVendorsList.slice(0, 5))
      } catch (err) {
        setError(err.response?.data?.error || 'Failed to load dashboard data')
        console.error('Error fetching admin dashboard data:', err)
      } finally {
        setLoading(false)
      }
    }
    
    fetchDashboardData()
  }, [])
  
  if (loading) return <Loading />
  if (error) return <ErrorMessage>{error}</ErrorMessage>
  
  return (
    <Container>
      <Breadcrumb items={[
        { label: 'Home', path: '/' },
        { label: 'Admin Dashboard', path: null }
      ]} />
      
      <Row>
        <Col lg={3} className="mb-4">
          <Sidebar variant="admin" />
        </Col>
        
        <Col lg={9}>
          <h3 className="mb-4">Admin Dashboard</h3>
          
          {/* Stats Cards */}
          <Row className="g-4 mb-4">
            <Col md={6} xl={3}>
              <Card className="border-0 shadow-sm">
                <Card.Body className="d-flex align-items-center">
                  <div className="rounded-circle bg-primary bg-opacity-10 p-3 me-3">
                    <FaUsers className="text-primary" size={24} />
                  </div>
                  <div>
                    <h6 className="mb-0 text-muted">Total Users</h6>
                    <h3 className="mt-1 mb-0">{stats.userCount}</h3>
                  </div>
                </Card.Body>
              </Card>
            </Col>
            
            <Col md={6} xl={3}>
              <Card className="border-0 shadow-sm">
                <Card.Body className="d-flex align-items-center">
                  <div className="rounded-circle bg-success bg-opacity-10 p-3 me-3">
                    <FaStore className="text-success" size={24} />
                  </div>
                  <div>
                    <h6 className="mb-0 text-muted">Total Vendors</h6>
                    <h3 className="mt-1 mb-0">{stats.vendorCount}</h3>
                  </div>
                </Card.Body>
              </Card>
            </Col>
            
            <Col md={6} xl={3}>
              <Card className="border-0 shadow-sm">
                <Card.Body className="d-flex align-items-center">
                  <div className="rounded-circle bg-info bg-opacity-10 p-3 me-3">
                    <FaBox className="text-info" size={24} />
                  </div>
                  <div>
                    <h6 className="mb-0 text-muted">Total Products</h6>
                    <h3 className="mt-1 mb-0">{stats.productCount}</h3>
                  </div>
                </Card.Body>
              </Card>
            </Col>
            
            <Col md={6} xl={3}>
              <Card className="border-0 shadow-sm">
                <Card.Body className="d-flex align-items-center">
                  <div className="rounded-circle bg-warning bg-opacity-10 p-3 me-3">
                    <FaShoppingCart className="text-warning" size={24} />
                  </div>
                  <div>
                    <h6 className="mb-0 text-muted">Total Orders</h6>
                    <h3 className="mt-1 mb-0">{stats.orderCount}</h3>
                  </div>
                </Card.Body>
              </Card>
            </Col>
          </Row>
          
          <Row className="g-4 mb-4">
            <Col md={4}>
              <Card className="border-0 shadow-sm h-100">
                <Card.Body className="d-flex flex-column">
                  <div className="d-flex align-items-center mb-3">
                    <div className="rounded-circle bg-success bg-opacity-10 p-3 me-3">
                      <FaMoneyBillWave className="text-success" size={24} />
                    </div>
                    <div>
                      <h6 className="mb-0 text-muted">Total Revenue</h6>
                      <h3 className="mt-1 mb-0">{formatCurrency(stats.totalSales)}</h3>
                    </div>
                  </div>
                  <div className="mt-auto text-center">
                    <FaChartBar size={80} className="text-muted opacity-25" />
                  </div>
                </Card.Body>
              </Card>
            </Col>
            
            <Col md={4}>
              <Card className="border-0 shadow-sm h-100">
                <Card.Body className="d-flex flex-column">
                  <div className="d-flex align-items-center mb-3">
                    <div className="rounded-circle bg-warning bg-opacity-10 p-3 me-3">
                      <FaExclamationTriangle className="text-warning" size={24} />
                    </div>
                    <div>
                      <h6 className="mb-0 text-muted">Pending Orders</h6>
                      <h3 className="mt-1 mb-0">{stats.pendingOrders}</h3>
                    </div>
                  </div>
                  <div className="mt-2">
                    <Link 
                      to="/admin/orders" 
                      className="btn btn-outline-primary btn-sm d-block"
                    >
                      View Pending Orders
                    </Link>
                  </div>
                </Card.Body>
              </Card>
            </Col>
            
            <Col md={4}>
              <Card className="border-0 shadow-sm h-100">
                <Card.Body className="d-flex flex-column">
                  <div className="d-flex align-items-center mb-3">
                    <div className="rounded-circle bg-danger bg-opacity-10 p-3 me-3">
                      <FaUserCheck className="text-danger" size={24} />
                    </div>
                    <div>
                      <h6 className="mb-0 text-muted">Pending Vendors</h6>
                      <h3 className="mt-1 mb-0">{stats.pendingVendors}</h3>
                    </div>
                  </div>
                  <div className="mt-2">
                    <Link 
                      to="/admin/vendors" 
                      className="btn btn-outline-primary btn-sm d-block"
                    >
                      Review Vendor Applications
                    </Link>
                  </div>
                </Card.Body>
              </Card>
            </Col>
          </Row>
          
          <Row className="g-4">
            {/* Recent Orders */}
            <Col lg={7} className="mb-4">
              <Card className="border-0 shadow-sm h-100">
                <Card.Header className="bg-white d-flex justify-content-between align-items-center">
                  <h5 className="mb-0">Recent Orders</h5>
                  <Link to="/admin/orders" className="btn btn-sm btn-outline-primary">
                    View All
                  </Link>
                </Card.Header>
                <Card.Body className="p-0">
                  {recentOrders.length === 0 ? (
                    <div className="text-center py-5">
                      <FaShoppingCart size={32} className="text-muted mb-3" />
                      <p>No orders found</p>
                    </div>
                  ) : (
                    <div className="table-responsive">
                      <Table hover className="mb-0">
                        <thead>
                          <tr>
                            <th>Order ID</th>
                            <th>Customer</th>
                            <th>Date</th>
                            <th>Amount</th>
                            <th>Status</th>
                          </tr>
                        </thead>
                        <tbody>
                          {recentOrders.map(order => (
                            <tr key={order._id}>
                              <td>
                                <Link to={`/admin/orders/${order._id}`}>
                                  #{order._id.substring(order._id.length - 6)}
                                </Link>
                              </td>
                              <td>{order.user?.name || 'Guest'}</td>
                              <td>{formatDate(order.createdAt)}</td>
                              <td>{formatCurrency(order.totalPrice)}</td>
                              <td>
                                <Badge 
                                  bg={
                                    order.status === 'delivered' ? 'success' :
                                    order.status === 'shipped' ? 'primary' :
                                    order.status === 'processing' ? 'info' :
                                    order.status === 'cancelled' ? 'danger' : 'warning'
                                  }
                                >
                                  {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                                </Badge>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </Table>
                    </div>
                  )}
                </Card.Body>
              </Card>
            </Col>
            
            {/* Pending Vendors */}
            <Col lg={5} className="mb-4">
              <Card className="border-0 shadow-sm h-100">
                <Card.Header className="bg-white d-flex justify-content-between align-items-center">
                  <h5 className="mb-0">Pending Vendor Approvals</h5>
                  <Link to="/admin/vendors" className="btn btn-sm btn-outline-primary">
                    View All
                  </Link>
                </Card.Header>
                <Card.Body className="p-0">
                  {pendingVendors.length === 0 ? (
                    <div className="text-center py-5">
                      <FaStore size={32} className="text-muted mb-3" />
                      <p>No pending vendor applications</p>
                    </div>
                  ) : (
                    <div className="table-responsive">
                      <Table hover className="mb-0">
                        <thead>
                          <tr>
                            <th>Shop Name</th>
                            <th>Owner</th>
                            <th>Applied On</th>
                          </tr>
                        </thead>
                        <tbody>
                          {pendingVendors.map(vendor => (
                            <tr key={vendor._id}>
                              <td>
                                <Link to={`/admin/vendors/${vendor._id}`}>
                                  {vendor.shopName}
                                </Link>
                              </td>
                              <td>{vendor.user?.name || 'Unknown'}</td>
                              <td>{formatDate(vendor.createdAt)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </Table>
                    </div>
                  )}
                </Card.Body>
              </Card>
            </Col>
          </Row>
        </Col>
      </Row>
    </Container>
  )
}

export default AdminDashboardPage