// src/pages/OrderSuccessPage.jsx
import { useEffect, useState } from 'react'
import { Container, Card, Button, Alert, Spinner } from 'react-bootstrap'
import { Link, useParams, useNavigate } from 'react-router-dom'
import { FaCheckCircle, FaShoppingCart, FaClipboardList } from 'react-icons/fa'
import orderService from '../services/orderService'
import { formatCurrency, formatDate } from '../utils/formatters'
import useAuth from '../hooks/useAuth'

const OrderSuccessPage = () => {
  const { id } = useParams()
  const { isAuthenticated } = useAuth()
  const navigate = useNavigate()
  
  const [order, setOrder] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  
  useEffect(() => {
    // Redirect to login if not authenticated
    if (!isAuthenticated) {
      navigate('/login')
      return
    }
    
    const fetchOrder = async () => {
      try {
        setLoading(true)
        const response = await orderService.getOrderById(id)
        setOrder(response.data)
      } catch (err) {
        setError('Failed to load order details')
        console.error('Error fetching order:', err)
      } finally {
        setLoading(false)
      }
    }
    
    fetchOrder()
  }, [id, isAuthenticated, navigate])
  
  if (loading) {
    return (
      <Container className="text-center py-5">
        <Spinner animation="border" variant="primary" />
        <p className="mt-3">Loading order details...</p>
      </Container>
    )
  }
  
  if (error || !order) {
    return (
      <Container className="py-5">
        <Alert variant="danger">
          {error || 'Order not found. Please try again.'}
        </Alert>
        <div className="text-center mt-4">
          <Button as={Link} to="/orders" variant="primary">
            View My Orders
          </Button>
        </div>
      </Container>
    )
  }
  
  return (
    <Container className="py-5">
      <Card className="border-0 shadow-sm text-center p-5">
        <Card.Body>
          <FaCheckCircle size={70} className="text-success mb-4" />
          
          <h1 className="mb-4">Order Placed Successfully!</h1>
          
          <p className="lead mb-4">
            Thank you for your order. Your order number is: <strong>#{order._id}</strong>
          </p>
          
          <div className="bg-light p-3 rounded mb-4">
            <div className="mb-2">
              <strong>Order Date:</strong> {formatDate(order.createdAt)}
            </div>
            <div className="mb-2">
              <strong>Total Amount:</strong> {formatCurrency(order.totalPrice)}
            </div>
            <div>
              <strong>Payment Method:</strong> {order.paymentMethod}
            </div>
          </div>
          
          <p className="mb-4">
            We'll send you shipping confirmation once your order is on the way!
          </p>
          
          <div className="d-flex justify-content-center gap-3">
            <Button as={Link} to="/shop" variant="outline-primary">
              <FaShoppingCart className="me-2" /> Continue Shopping
            </Button>
            <Button as={Link} to="/orders" variant="primary">
              <FaClipboardList className="me-2" /> View My Orders
            </Button>
          </div>
        </Card.Body>
      </Card>
    </Container>
  )
}

export default OrderSuccessPage