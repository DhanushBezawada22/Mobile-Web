// src/pages/HomePage.jsx
import { useEffect, useState } from 'react'
import { Container, Row, Col, Button, Card, Carousel, Badge } from 'react-bootstrap'
import { Link } from 'react-router-dom'
import { FaArrowRight, FaCar, FaMotorcycle, FaTools, FaCog } from 'react-icons/fa'
import ProductCard from '../components/common/ProductCard'
import Loading from '../components/common/Loading'
import ErrorMessage from '../components/common/ErrorMessage'
import productService from '../services/productService'
import categoryService from '../services/categoryService'
import brandService from '../services/brandService'
import bannerImg from '../assets/banner.jpg'

const HomePage = () => {
  const [featuredProducts, setFeaturedProducts] = useState([])
  const [categories, setCategories] = useState([])
  const [brands, setBrands] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true)
        setError(null)
        
        // Fetch featured products
        const productsResponse = await productService.getFeaturedProducts(8)
        setFeaturedProducts(productsResponse.data)
        
        // Fetch categories
        const categoriesResponse = await categoryService.getCategories()
        setCategories(categoriesResponse.data)
        
        // Fetch brands
        const brandsResponse = await brandService.getBrands()
        setBrands(brandsResponse.data)
      } catch (err) {
        setError(err.response?.data?.error || 'Failed to load data')
        console.error('Error fetching homepage data:', err)
      } finally {
        setLoading(false)
      }
    }
    
    fetchData()
  }, [])

  if (loading) return <Loading />
  if (error) return <ErrorMessage>{error}</ErrorMessage>

  return (
    <>
      {/* Hero Banner */}
      <div className="hero-section position-relative mb-5">
        <Carousel fade indicators={false} controls={false}>
          <Carousel.Item>
            <img
              className="d-block w-100"
              src={bannerImg}
              alt="Auto parts banner"
              style={{ height: '400px', objectFit: 'cover' }}
            />
            <Carousel.Caption className="text-start">
              <div className="bg-dark bg-opacity-50 p-4 rounded">
                <h1>Quality Auto Parts for Every Vehicle</h1>
                <p>Find the perfect parts for your car or motorcycle</p>
                <Button as={Link} to="/shop" variant="primary" size="lg" className="mt-2">
                  Shop Now <FaArrowRight className="ms-2" />
                </Button>
              </div>
            </Carousel.Caption>
          </Carousel.Item>
        </Carousel>
      </div>

      <Container>
        {/* Vehicle Type Selection */}
        <section className="mb-5">
          <h2 className="section-title mb-4">Shop by Vehicle Type</h2>
          <Row className="g-4">
            <Col md={6}>
              <Card className="h-100 border-0 shadow-sm vehicle-card">
                <Link to="/shop?vehicleType=car" className="text-decoration-none">
                  <Card.Body className="d-flex flex-column align-items-center justify-content-center py-5">
                    <FaCar size={50} className="text-primary mb-3" />
                    <Card.Title className="fw-bold mb-0">Car Parts</Card.Title>
                    <Card.Text className="text-muted mt-2">
                      Browse high-quality car parts and accessories
                    </Card.Text>
                  </Card.Body>
                </Link>
              </Card>
            </Col>
            <Col md={6}>
              <Card className="h-100 border-0 shadow-sm vehicle-card">
                <Link to="/shop?vehicleType=bike" className="text-decoration-none">
                  <Card.Body className="d-flex flex-column align-items-center justify-content-center py-5">
                    <FaMotorcycle size={50} className="text-primary mb-3" />
                    <Card.Title className="fw-bold mb-0">Motorcycle Parts</Card.Title>
                    <Card.Text className="text-muted mt-2">
                      Discover premium motorcycle parts and accessories
                    </Card.Text>
                  </Card.Body>
                </Link>
              </Card>
            </Col>
          </Row>
        </section>
        
        {/* Featured Products */}
        <section className="mb-5">
          <div className="d-flex justify-content-between align-items-center mb-4">
            <h2 className="section-title mb-0">Featured Products</h2>
            <Button as={Link} to="/shop" variant="outline-primary" className="d-flex align-items-center">
              View All <FaArrowRight className="ms-2" />
            </Button>
          </div>
          
          {featuredProducts.length > 0 ? (
            <Row className="g-4">
              {featuredProducts.map(product => (
                <Col key={product._id} sm={6} md={4} lg={3}>
                  <ProductCard product={product} />
                </Col>
              ))}
            </Row>
          ) : (
            <Card className="text-center p-5 border-0 shadow-sm">
              <Card.Body>
                <FaTools size={40} className="text-muted mb-3" />
                <Card.Title>No Featured Products</Card.Title>
                <Card.Text>
                  Check back later for our featured product selections.
                </Card.Text>
                <Button as={Link} to="/shop" variant="primary">
                  Browse All Products
                </Button>
              </Card.Body>
            </Card>
          )}
        </section>
        
        {/* Categories Section */}
        <section className="mb-5">
          <h2 className="section-title mb-4">Shop by Category</h2>
          <Row className="g-4">
            {categories.slice(0, 4).map(category => (
              <Col key={category._id} sm={6} md={3}>
                <Card className="h-100 border-0 shadow-sm category-card">
                  <Link to={`/shop?category=${category._id}`} className="text-decoration-none">
                    <Card.Body className="text-center py-4">
                      <FaCog size={40} className="text-primary mb-3" />
                      <Card.Title>{category.name}</Card.Title>
                    </Card.Body>
                  </Link>
                </Card>
              </Col>
            ))}
          </Row>
        </section>
        
        {/* Brands Section */}
        <section className="mb-5">
          <h2 className="section-title mb-4">Popular Brands</h2>
          <Row className="g-4 align-items-center">
            {brands.map(brand => (
              <Col key={brand._id} xs={6} sm={4} md={3} lg={2}>
                <Link to={`/shop?brand=${brand._id}`} className="text-decoration-none">
                  <Card className="brand-card text-center border-0 shadow-sm p-3 h-100">
                    <Card.Body className="p-2">
                      <h6 className="mb-0">{brand.name}</h6>
                    </Card.Body>
                  </Card>
                </Link>
              </Col>
            ))}
          </Row>
        </section>
        
        {/* Become a Vendor CTA */}
        <section className="mb-5">
          <Card className="border-0 shadow-sm bg-light">
            <Card.Body className="p-5 text-center">
              <h3 className="mb-3">Become a Vendor</h3>
              <p className="mb-4">
                Join our marketplace and start selling your auto parts to thousands of customers.
              </p>
              <Button as={Link} to="/become-vendor" variant="primary" size="lg">
                Apply Now
              </Button>
            </Card.Body>
          </Card>
        </section>
      </Container>
    </>
  )
}

export default HomePage