// src/pages/BecomeVendorPage.jsx
import { useState } from 'react'
import { Container, Row, Col, Card, Form, Button, Alert } from 'react-bootstrap'
import { useNavigate } from 'react-router-dom'
import { FaStore, FaPhone, FaMapMarkerAlt, FaInfoCircle } from 'react-icons/fa'
import Breadcrumb from '../components/common/Breadcrumb'
import useAuth from '../hooks/useAuth'
import vendorService from '../services/vendorService'

const BecomeVendorPage = () => {
  const { user } = useAuth()
  const navigate = useNavigate()
  
  const [formData, setFormData] = useState({
    shopName: '',
    description: '',
    phone: '',
    address: '',
    specialties: '',
  })
  
  const [errors, setErrors] = useState({})
  const [loading, setLoading] = useState(false)
  const [generalError, setGeneralError] = useState(null)
  
  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData({
      ...formData,
      [name]: value
    })
    
    // Clear error for this field
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: null
      })
    }
    
    // Clear general error
    if (generalError) {
      setGeneralError(null)
    }
  }
  
  const validateForm = () => {
    const newErrors = {}
    
    if (!formData.shopName.trim()) {
      newErrors.shopName = 'Shop name is required'
    }
    
    if (!formData.description.trim()) {
      newErrors.description = 'Description is required'
    } else if (formData.description.length < 20) {
      newErrors.description = 'Description must be at least 20 characters'
    }
    
    if (!formData.phone.trim()) {
      newErrors.phone = 'Phone number is required'
    }
    
    if (!formData.address.trim()) {
      newErrors.address = 'Address is required'
    }
    
    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }
  
  const handleSubmit = async (e) => {
    e.preventDefault()
    
    if (!validateForm()) {
      return
    }
    
    try {
      setLoading(true)
      setGeneralError(null)
      
      // Convert specialties string to array
      const vendorData = {
        ...formData,
        specialties: formData.specialties
          ? formData.specialties.split(',').map(item => item.trim())
          : []
      }
      
      await vendorService.registerVendor(vendorData)
      
      // Redirect to vendor dashboard (the user should now have vendor role)
      navigate('/vendor/dashboard')
    } catch (error) {
      setGeneralError(error.response?.data?.error || 'Failed to register as vendor. Please try again.')
    } finally {
      setLoading(false)
    }
  }
  
  return (
    <Container>
      <Breadcrumb items={[
        { label: 'Home', path: '/' },
        { label: 'Become a Vendor', path: null }
      ]} />
      
      <Row className="justify-content-center">
        <Col lg={8}>
          <Card className="border-0 shadow-sm mb-5">
            <Card.Body className="p-5">
              <div className="text-center mb-4">
                <h2>Become a Vendor</h2>
                <p className="text-muted">Join our marketplace and start selling your auto parts</p>
              </div>
              
              {generalError && (
                <Alert variant="danger" className="mb-4">
                  {generalError}
                </Alert>
              )}
              
              <Form onSubmit={handleSubmit}>
                <Form.Group className="mb-3" controlId="shopName">
                  <Form.Label>Shop Name</Form.Label>
                  <div className="input-group">
                    <span className="input-group-text">
                      <FaStore />
                    </span>
                    <Form.Control
                      type="text"
                      name="shopName"
                      placeholder="Enter your shop name"
                      value={formData.shopName}
                      onChange={handleChange}
                      isInvalid={!!errors.shopName}
                    />
                  </div>
                  <Form.Control.Feedback type="invalid">
                    {errors.shopName}
                  </Form.Control.Feedback>
                </Form.Group>
                
                <Form.Group className="mb-3" controlId="description">
                  <Form.Label>Shop Description</Form.Label>
                  <Form.Control
                    as="textarea"
                    rows={4}
                    name="description"
                    placeholder="Describe your shop and products"
                    value={formData.description}
                    onChange={handleChange}
                    isInvalid={!!errors.description}
                  />
                  <Form.Control.Feedback type="invalid">
                    {errors.description}
                  </Form.Control.Feedback>
                </Form.Group>
                
                <Row>
                  <Col md={6}>
                    <Form.Group className="mb-3" controlId="phone">
                      <Form.Label>Phone Number</Form.Label>
                      <div className="input-group">
                        <span className="input-group-text">
                          <FaPhone />
                        </span>
                        <Form.Control
                          type="text"
                          name="phone"
                          placeholder="Enter your phone number"
                          value={formData.phone}
                          onChange={handleChange}
                          isInvalid={!!errors.phone}
                        />
                      </div>
                      <Form.Control.Feedback type="invalid">
                        {errors.phone}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                  
                  <Col md={6}>
                    <Form.Group className="mb-3" controlId="specialties">
                      <Form.Label>Specialties (Comma Separated)</Form.Label>
                      <Form.Control
                        type="text"
                        name="specialties"
                        placeholder="e.g. Honda Parts, Bike Parts"
                        value={formData.specialties}
                        onChange={handleChange}
                        isInvalid={!!errors.specialties}
                      />
                      <Form.Control.Feedback type="invalid">
                        {errors.specialties}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                </Row>
                
                <Form.Group className="mb-4" controlId="address">
                  <Form.Label>Business Address</Form.Label>
                  <div className="input-group">
                    <span className="input-group-text">
                      <FaMapMarkerAlt />
                    </span>
                    <Form.Control
                      type="text"
                      name="address"
                      placeholder="Enter your business address"
                      value={formData.address}
                      onChange={handleChange}
                      isInvalid={!!errors.address}
                    />
                  </div>
                  <Form.Control.Feedback type="invalid">
                    {errors.address}
                  </Form.Control.Feedback>
                </Form.Group>
                
                <Alert variant="info" className="d-flex align-items-start mb-4">
                  <FaInfoCircle className="me-2 mt-1" />
                  <div>
                    <strong>Note:</strong> Your vendor application will be reviewed by our team. 
                    You'll be notified once your shop is approved.
                  </div>
                </Alert>
                
                <Button 
                  variant="primary" 
                  type="submit" 
                  className="w-100"
                  size="lg"
                  disabled={loading}
                >
                  {loading ? 'Submitting...' : 'Submit Application'}
                </Button>
              </Form>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  )
}

export default BecomeVendorPage