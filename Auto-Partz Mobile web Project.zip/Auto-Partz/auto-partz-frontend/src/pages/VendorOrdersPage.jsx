// src/pages/VendorOrdersPage.jsx
import { useState, useEffect } from 'react'
import { Container, Row, Col, Card, Table, Badge, Button, Form, Tab, Tabs, Modal } from 'react-bootstrap'
import { Link } from 'react-router-dom'
import { 
  FaEye, 
  FaTruck, 
  FaCheck, 
  FaFilter, 
  FaTimes,
  FaExclamationTriangle,
  FaClipboardList
} from 'react-icons/fa'
import Breadcrumb from '../components/common/Breadcrumb'
import Sidebar from '../components/common/Sidebar'
import Loading from '../components/common/Loading'
import ErrorMessage from '../components/common/ErrorMessage'
import Pagination from '../components/common/Pagination'
import orderService from '../services/orderService'
import vendorService from '../services/vendorService'
import useAuth from '../hooks/useAuth'
import { formatCurrency, formatDate, formatOrderStatus } from '../utils/formatters'
import { ORDER_STATUSES } from '../utils/constants'

const VendorOrdersPage = () => {
  const { user } = useAuth()
  
  const [vendor, setVendor] = useState(null)
  const [orders, setOrders] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [pagination, setPagination] = useState({
    page: 1,
    pages: 1,
    total: 0
  })
  
  const [activeTab, setActiveTab] = useState('all')
  const [filters, setFilters] = useState({
    status: '',
    dateRange: '',
    search: ''
  })
  const [showFilters, setShowFilters] = useState(false)
  
  // Order details modal
  const [showOrderModal, setShowOrderModal] = useState(false)
  const [selectedOrder, setSelectedOrder] = useState(null)
  const [updatingStatus, setUpdatingStatus] = useState(false)
  
  useEffect(() => {
    const fetchOrders = async () => {
      try {
        setLoading(true)
        
        // Fetch vendor first
        const vendorResponse = await vendorService.getVendorByUser(user._id)
        setVendor(vendorResponse.data)
        
        // Fetch orders for this vendor
        const ordersResponse = await orderService.getVendorOrders()
        setOrders(ordersResponse.data)
        setPagination({
          page: 1,
          pages: Math.ceil(ordersResponse.count / 10),
          total: ordersResponse.count
        })
      } catch (err) {
        setError(err.response?.data?.error || 'Failed to load orders')
        console.error('Error fetching vendor orders:', err)
      } finally {
        setLoading(false)
      }
    }
    
    fetchOrders()
  }, [user])
  
  const handleFilterChange = (e) => {
    const { name, value } = e.target
    setFilters({
      ...filters,
      [name]: value
    })
  }
  
  const applyFilters = () => {
    // Filter orders based on current filters
    // Reset to page 1 when filters change
    setPagination({
      ...pagination,
      page: 1
    })
    
    setShowFilters(false)
  }
  
  const resetFilters = () => {
    setFilters({
      status: '',
      dateRange: '',
      search: ''
    })
  }
  
  const handlePageChange = (page) => {
    setPagination({
      ...pagination,
      page
    })
  }
  
  const handleShowOrderModal = (order) => {
    setSelectedOrder(order)
    setShowOrderModal(true)
  }
  
  const handleUpdateOrderStatus = async (orderId, status) => {
    try {
      setUpdatingStatus(true)
      console.log('Updating order:', orderId, 'to status:', status);
      
      await orderService.updateOrderStatus(orderId, status)
      
      // Update order in state
      setOrders(orders.map(order => 
        order._id === orderId 
          ? { ...order, status } 
          : order
      ))
      
      // If viewing order details, update selected order
      if (selectedOrder && selectedOrder._id === orderId) {
        setSelectedOrder({ ...selectedOrder, status })
      }
    } catch (error) {
      console.error('Error updating order status:', error)
      // Show error message
    } finally {
      setUpdatingStatus(false)
    }
  }
  
  // Filter orders based on selected tab and filters
  const filteredOrders = orders.filter(order => {
    // Filter by tab
    if (activeTab !== 'all' && order.status !== activeTab) {
      return false
    }
    
    // Filter by status (if different from tab)
    if (filters.status && order.status !== filters.status) {
      return false
    }
    
    // Filter by search (order ID or customer name)
    if (filters.search) {
      const searchLower = filters.search.toLowerCase()
      const idMatch = order._id.toLowerCase().includes(searchLower)
      const customerMatch = order.user?.name?.toLowerCase().includes(searchLower)
      
      if (!idMatch && !customerMatch) {
        return false
      }
    }
    
    // Filter by date range
    if (filters.dateRange) {
      const orderDate = new Date(order.createdAt)
      const today = new Date()
      
      if (filters.dateRange === 'today') {
        // Check if order is from today
        return (
          orderDate.getDate() === today.getDate() &&
          orderDate.getMonth() === today.getMonth() &&
          orderDate.getFullYear() === today.getFullYear()
        )
      } else if (filters.dateRange === 'week') {
        // Check if order is from this week
        const weekAgo = new Date(today)
        weekAgo.setDate(today.getDate() - 7)
        return orderDate >= weekAgo
      } else if (filters.dateRange === 'month') {
        // Check if order is from this month
        const monthAgo = new Date(today)
        monthAgo.setMonth(today.getMonth() - 1)
        return orderDate >= monthAgo
      }
    }
    
    return true
  })
  
  if (loading) return <Loading />
  if (error) return <ErrorMessage>{error}</ErrorMessage>
  
  return (
    <Container>
      <Breadcrumb items={[
        { label: 'Home', path: '/' },
        { label: 'Vendor Dashboard', path: '/vendor/dashboard' },
        { label: 'Orders', path: null }
      ]} />
      
      <Row>
        <Col lg={3} className="mb-4">
          <Sidebar variant="vendor" />
        </Col>
        
        <Col lg={9}>
          {!vendor?.isVerified && (
            <Alert variant="warning" className="mb-4">
              <div className="d-flex align-items-center">
                <FaExclamationTriangle className="me-2" />
                <div>
                  <strong>Your vendor account is pending verification.</strong>
                  <div>You can manage orders, but customers cannot place new orders until your account is verified.</div>
                </div>
              </div>
            </Alert>
          )}
          
          <Card className="border-0 shadow-sm mb-4">
            <Card.Body>
              <h3 className="mb-4">My Orders</h3>
              
              <div className="d-flex justify-content-between align-items-center mb-3">
                <div className="d-flex">
                  <Button 
                    variant="outline-secondary" 
                    className="me-2 d-flex align-items-center"
                    onClick={() => setShowFilters(!showFilters)}
                  >
                    <FaFilter className="me-1" /> Filters
                    {Object.values(filters).some(value => value !== '') && (
                      <Badge 
                        bg="primary" 
                        pill 
                        className="ms-1"
                      >
                        {Object.values(filters).filter(value => value !== '').length}
                      </Badge>
                    )}
                  </Button>
                  
                  <Form.Control
                    type="text"
                    placeholder="Search order ID or customer..."
                    value={filters.search}
                    onChange={e => setFilters({...filters, search: e.target.value})}
                    className="me-2"
                    style={{ maxWidth: '250px' }}
                  />
                </div>
                
                <div>
                  <span className="text-muted me-2">
                    {filteredOrders.length} order(s)
                  </span>
                </div>
              </div>
              
              {showFilters && (
                <Card className="mb-3 border">
                  <Card.Body>
                    <div className="d-flex justify-content-between align-items-center mb-3">
                      <h5 className="mb-0">Filter Orders</h5>
                      <Button 
                        variant="link" 
                        className="p-0 text-muted"
                        onClick={() => setShowFilters(false)}
                      >
                        <FaTimes />
                      </Button>
                    </div>
                    
                    <Row className="g-2">
                      <Col sm={6} md={activeTab === 'all' ? 6 : 12}>
                        {activeTab === 'all' && (
                          <Form.Group controlId="statusFilter">
                            <Form.Label>Status</Form.Label>
                            <Form.Select
                              name="status"
                              value={filters.status}
                              onChange={handleFilterChange}
                            >
                              <option value="">All Statuses</option>
                              {ORDER_STATUSES.map(status => (
                                <option key={status.value} value={status.value}>
                                  {status.label}
                                </option>
                              ))}
                            </Form.Select>
                          </Form.Group>
                        )}
                      </Col>
                      
                      <Col sm={6} md={activeTab === 'all' ? 6 : 12}>
                        <Form.Group controlId="dateRangeFilter">
                          <Form.Label>Date Range</Form.Label>
                          <Form.Select
                            name="dateRange"
                            value={filters.dateRange}
                            onChange={handleFilterChange}
                          >
                            <option value="">All Time</option>
                            <option value="today">Today</option>
                            <option value="week">Last 7 Days</option>
                            <option value="month">Last 30 Days</option>
                          </Form.Select>
                        </Form.Group>
                      </Col>
                    </Row>
                    
                    <div className="d-flex justify-content-end mt-3">
                      <Button 
                        variant="outline-secondary" 
                        className="me-2"
                        onClick={resetFilters}
                      >
                        Reset
                      </Button>
                      <Button 
                        variant="primary"
                        onClick={applyFilters}
                      >
                        Apply Filters
                      </Button>
                    </div>
                  </Card.Body>
                </Card>
              )}
              
              <Tabs
                activeKey={activeTab}
                onSelect={(k) => setActiveTab(k)}
                className="mb-4"
              >
                <Tab eventKey="all" title="All Orders" />
                <Tab eventKey="pending" title="Pending" />
                <Tab eventKey="processing" title="Processing" />
                <Tab eventKey="shipped" title="Shipped" />
                <Tab eventKey="delivered" title="Delivered" />
                <Tab eventKey="cancelled" title="Cancelled" />
              </Tabs>
              
              {filteredOrders.length === 0 ? (
                <div className="text-center py-5">
                  <FaClipboardList size={50} className="text-muted mb-3" />
                  <h4>No Orders Found</h4>
                  <p className="mb-4">
                    {Object.values(filters).some(value => value !== '') || activeTab !== 'all'
                      ? 'Try changing your filters to see more orders.'
                      : 'You haven\'t received any orders yet.'}
                  </p>
                </div>
              ) : (
                <>
                  <div className="table-responsive">
                    <Table hover className="align-middle">
                      <thead>
                        <tr>
                          <th>Order ID</th>
                          <th>Date</th>
                          <th>Customer</th>
                          <th>Amount</th>
                          <th>Status</th>
                          <th>Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {filteredOrders.map(order => {
                          const statusInfo = formatOrderStatus(order.status)
                          
                          return (
                            <tr key={order._id}>
                              <td>
                                <Button 
                                  variant="link" 
                                  className="p-0 text-decoration-none"
                                  onClick={() => handleShowOrderModal(order)}
                                >
                                  #{order._id.substring(order._id.length - 6)}
                                </Button>
                              </td>
                              <td>{formatDate(order.createdAt)}</td>
                              <td>
                                {order.user ? order.user.name : 'Guest'}
                              </td>
                              <td>{formatCurrency(order.vendorItemsPrice)}</td>
                              <td>
                                <Badge 
                                  bg={statusInfo.color} 
                                  text={
                                    order.status === 'pending' || 
                                    order.status === 'warning' 
                                      ? 'dark' 
                                      : undefined
                                  }
                                >
                                  {statusInfo.label}
                                </Badge>
                              </td>
                              <td>
                                <Button
                                  variant="outline-secondary"
                                  size="sm"
                                  className="me-1"
                                  onClick={() => handleShowOrderModal(order)}
                                >
                                  <FaEye />
                                </Button>
                                
                                {order.status === 'pending' && (
                                  <Button
                                    variant="outline-primary"
                                    size="sm"
                                    className="me-1"
                                    onClick={() => handleUpdateOrderStatus(order._id, 'processing')}
                                    disabled={updatingStatus}
                                  >
                                    <FaCheck /> Process
                                  </Button>
                                )}
                                
                                {order.status === 'processing' && (
                                  <Button
                                    variant="outline-primary"
                                    size="sm"
                                    onClick={() => handleUpdateOrderStatus(order._id, 'shipped')}
                                    disabled={updatingStatus}
                                  >
                                    <FaTruck /> Ship
                                  </Button>
                                )}
                              </td>
                            </tr>
                          )
                        })}
                      </tbody>
                    </Table>
                  </div>
                  
                  <Pagination 
                    page={pagination.page}
                    pages={pagination.pages}
                    onPageChange={handlePageChange}
                  />
                </>
              )}
            </Card.Body>
          </Card>
        </Col>
      </Row>
      
      {/* Order Detail Modal */}
      <Modal
        show={showOrderModal}
        onHide={() => setShowOrderModal(false)}
        size="lg"
        centered
      >
        <Modal.Header closeButton>
          <Modal.Title>
            Order Details
            <span className="text-muted ms-2">
              (#{selectedOrder?._id?.substring(selectedOrder?._id?.length - 6)})
            </span>
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {selectedOrder && (
            <>
              <Row className="mb-4">
                <Col md={6}>
                  <h6>Order Information</h6>
                  <div className="mb-1">
                    <strong>Order ID:</strong> {selectedOrder._id}
                  </div>
                  <div className="mb-1">
                    <strong>Date:</strong> {formatDate(selectedOrder.createdAt)}
                  </div>
                  <div className="mb-1">
                    <strong>Payment Method:</strong> {selectedOrder.paymentMethod}
                  </div>
                  <div>
                    <strong>Status:</strong>{' '}
                    <Badge 
                      bg={formatOrderStatus(selectedOrder.status).color}
                      text={
                        selectedOrder.status === 'pending' || 
                        selectedOrder.status === 'warning' 
                          ? 'dark' 
                          : undefined
                      }
                    >
                      {formatOrderStatus(selectedOrder.status).label}
                    </Badge>
                  </div>
                </Col>
                
                <Col md={6}>
                  <h6>Customer Information</h6>
                  <div className="mb-1">
                    <strong>Name:</strong> {selectedOrder.user?.name || 'Guest'}
                  </div>
                  <div className="mb-1">
                    <strong>Email:</strong> {selectedOrder.user?.email || 'N/A'}
                  </div>
                  <div>
                    <strong>Shipping Address:</strong>
                    <div>
                      {selectedOrder?.shippingAddress?.address}<br />
                      {selectedOrder?.shippingAddress?.city}, {selectedOrder?.shippingAddress?.postalCode}<br />
                      {selectedOrder?.shippingAddress?.country}
                    </div>
                  </div>
                </Col>
              </Row>
              
              <h6>Order Items (from your shop)</h6>
              <Table responsive className="mt-2">
                <thead>
                  <tr>
                    <th>Product</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Total</th>
                  </tr>
                </thead>
                <tbody>
                  {selectedOrder.orderItems.map((item, index) => (
                    <tr key={index}>
                      <td>
                        <div className="d-flex align-items-center">
                          <img 
                            src={item.image ? `/uploads/products/${item.image}` : placeholderImg}
                            alt={item.name}
                            width="50"
                            height="50"
                            className="me-2"
                          />
                          <div>
                            <div>{item.name}</div>
                          </div>
                        </div>
                      </td>
                      <td>{formatCurrency(item.price)}</td>
                      <td>{item.quantity}</td>
                      <td>{formatCurrency(item.price * item.quantity)}</td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr>
                    <td colSpan="3" className="text-end">
                      <strong>Subtotal:</strong>
                    </td>
                    <td>{formatCurrency(selectedOrder.vendorItemsPrice)}</td>
                  </tr>
                </tfoot>
              </Table>
              
              <div className="mt-4">
                <h6>Update Order Status</h6>
                <div className="d-flex flex-wrap gap-2 mt-3">
                  {ORDER_STATUSES.map(status => (
                    <Button
                      key={status.value}
                      variant={selectedOrder.status === status.value ? status.color : 'outline-secondary'}
                      size="sm"
                      onClick={() => handleUpdateOrderStatus(selectedOrder._id, status.value)}
                      disabled={updatingStatus || selectedOrder.status === status.value}
                      className="me-2 mb-2"
                    >
                      {status.label}
                    </Button>
                  ))}
                </div>
              </div>
            </>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowOrderModal(false)}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </Container>
  )
}

export default VendorOrdersPage