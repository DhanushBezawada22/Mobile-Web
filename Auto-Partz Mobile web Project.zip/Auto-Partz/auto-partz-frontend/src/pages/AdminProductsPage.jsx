// src/pages/AdminProductsPage.jsx
import { useState, useEffect } from 'react'
import { Container, Row, Col, Card, Table, Button, Form, Badge, Modal, Alert } from 'react-bootstrap'
import { FaSearch, FaFilter, FaTimes, FaEye, FaEdit, FaTrash, FaTags, FaTh, FaStar, FaExclamationTriangle } from 'react-icons/fa'
import Breadcrumb from '../components/common/Breadcrumb'
import Sidebar from '../components/common/Sidebar'
import Loading from '../components/common/Loading'
import ErrorMessage from '../components/common/ErrorMessage'
import Pagination from '../components/common/Pagination'
import productService from '../services/productService'
import categoryService from '../services/categoryService'
import brandService from '../services/brandService'
import { formatCurrency } from '../utils/formatters'
import { VEHICLE_TYPES } from '../utils/constants'
import { Link } from 'react-router-dom'
import placeHolder from '../assets/placeholder.jpg'
import { getImageUrl } from '../utils/imageHelper'

const AdminProductsPage = () => {
  const [products, setProducts] = useState([])
  const [categories, setCategories] = useState([])
  const [brands, setBrands] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [filters, setFilters] = useState({
    search: '',
    category: '',
    brand: '',
    vehicleType: '',
    status: ''
  })
  const [showFilters, setShowFilters] = useState(false)
  const [pagination, setPagination] = useState({
    page: 1,
    pages: 1,
    total: 0
  })
  
  // Product Details Modal
  const [showProductModal, setShowProductModal] = useState(false)
  const [selectedProduct, setSelectedProduct] = useState(null)
  
  // Delete Confirmation Modal
  const [showDeleteModal, setShowDeleteModal] = useState(false)
  const [productToDelete, setProductToDelete] = useState(null)
  
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true)
        
        // Fetch products, categories, and brands
        const [
          productsResponse,
          categoriesResponse,
          brandsResponse
        ] = await Promise.all([
          productService.getProducts(),
          categoryService.getCategories(),
          brandService.getBrands()
        ])
        
        setProducts(productsResponse.data)
        setCategories(categoriesResponse.data)
        setBrands(brandsResponse.data)
        
        setPagination({
          page: 1,
          pages: Math.ceil(productsResponse.data.length / 10),
          total: productsResponse.data.length
        })
      } catch (err) {
        setError(err.response?.data?.error || 'Failed to load products')
        console.error('Error fetching products:', err)
      } finally {
        setLoading(false)
      }
    }
    
    fetchData()
  }, [])
  
  const handleFilterChange = (e) => {
    const { name, value } = e.target
    setFilters({
      ...filters,
      [name]: value
    })
  }
  
  const applyFilters = () => {
    // Reset to page 1 when filters change
    setPagination({
      ...pagination,
      page: 1
    })
    
    setShowFilters(false)
  }
  
  const resetFilters = () => {
    setFilters({
      search: '',
      category: '',
      brand: '',
      vehicleType: '',
      status: ''
    })
  }
  
  const handlePageChange = (page) => {
    setPagination({
      ...pagination,
      page
    })
  }
  
  // Filter products client-side
  const filteredProducts = products.filter(product => {
    return (
      (filters.search === '' || 
       product.name.toLowerCase().includes(filters.search.toLowerCase())) &&
      (filters.category === '' || 
       (product.category && product.category._id === filters.category)) &&
      (filters.brand === '' || 
       (product.brand && product.brand._id === filters.brand)) &&
      (filters.vehicleType === '' || product.vehicleType === filters.vehicleType) &&
      (filters.status === '' || 
       (filters.status === 'inStock' && product.quantity > 0) ||
       (filters.status === 'outOfStock' && product.quantity <= 0) ||
       (filters.status === 'featured' && product.featured))
    )
  })
  
  // Calculate paginated products
  const paginatedProducts = filteredProducts.slice(
    (pagination.page - 1) * 10,
    pagination.page * 10
  )
  
  const handleShowProductModal = (product) => {
    setSelectedProduct(product)
    setShowProductModal(true)
  }
  
  const handleToggleFeatured = async (product) => {
    try {
      // Toggle featured status
      const updatedProduct = await productService.updateProduct(product._id, {
        featured: !product.featured
      })
      
      // Update product in state
      setProducts(products.map(p => 
        p._id === product._id ? updatedProduct.data : p
      ))
    } catch (error) {
      console.error('Error updating product:', error)
    }
  }
  
  // Handle delete confirmation
  const handleShowDeleteModal = (product) => {
    setProductToDelete(product)
    setShowDeleteModal(true)
  }
  
  const handleDeleteProduct = async () => {
    try {
      await productService.deleteProduct(productToDelete._id)
      
      // Remove product from state
      setProducts(products.filter(p => p._id !== productToDelete._id))
      setShowDeleteModal(false)
    } catch (error) {
      console.error('Error deleting product:', error)
    }
  }
  
  if (loading) return <Loading />
  if (error) return <ErrorMessage>{error}</ErrorMessage>
  
  return (
    <Container>
      <Breadcrumb items={[
        { label: 'Home', path: '/' },
        { label: 'Admin Dashboard', path: '/admin/dashboard' },
        { label: 'Products', path: null }
      ]} />
      
      <Row>
        <Col lg={3} className="mb-4">
          <Sidebar variant="admin" />
        </Col>
        
        <Col lg={9}>
          <Card className="border-0 shadow-sm mb-4">
            <Card.Body>
              <div className="d-flex justify-content-between align-items-center mb-3">
                <h3 className="mb-0">Manage Products</h3>
                
                <div>
                  <Button 
                    as={Link}
                    to="/admin/categories"
                    variant="outline-secondary" 
                    className="me-2"
                  >
                    <FaTh className="me-1" /> Categories
                  </Button>
                  <Button 
                    as={Link}
                    to="/admin/brands"
                    variant="outline-secondary" 
                    className="me-2"
                  >
                    <FaTags className="me-1" /> Brands
                  </Button>
                </div>
              </div>
              
              <div className="d-flex justify-content-between align-items-center mb-3">
                <div className="d-flex">
                  <Button 
                    variant="outline-secondary" 
                    className="me-2 d-flex align-items-center"
                    onClick={() => setShowFilters(!showFilters)}
                  >
                    <FaFilter className="me-1" /> Filters
                    {Object.values(filters).some(value => value !== '') && (
                      <Badge 
                        bg="primary" 
                        pill 
                        className="ms-1"
                      >
                        {Object.values(filters).filter(value => value !== '').length}
                      </Badge>
                    )}
                  </Button>
                  
                  <Form.Control
                    type="text"
                    placeholder="Search products..."
                    value={filters.search}
                    onChange={e => setFilters({...filters, search: e.target.value})}
                    className="me-2"
                    style={{ maxWidth: '250px' }}
                  />
                </div>
                
                <div>
                  <span className="text-muted me-2">
                    {filteredProducts.length} product(s)
                  </span>
                </div>
              </div>
              
              {showFilters && (
                <Card className="mb-3 border">
                  <Card.Body>
                    <div className="d-flex justify-content-between align-items-center mb-3">
                      <h5 className="mb-0">Filter Products</h5>
                      <Button 
                        variant="link" 
                        className="p-0 text-muted"
                        onClick={() => setShowFilters(false)}
                      >
                        <FaTimes />
                      </Button>
                    </div>
                    
                    <Row className="g-2">
                      <Col sm={6} md={4}>
                        <Form.Group controlId="categoryFilter">
                          <Form.Label>Category</Form.Label>
                          <Form.Select
                            name="category"
                            value={filters.category}
                            onChange={handleFilterChange}
                          >
                            <option value="">All Categories</option>
                            {categories.map(category => (
                              <option key={category._id} value={category._id}>
                                {category.name}
                              </option>
                            ))}
                          </Form.Select>
                        </Form.Group>
                      </Col>
                      
                      <Col sm={6} md={4}>
                        <Form.Group controlId="brandFilter">
                          <Form.Label>Brand</Form.Label>
                          <Form.Select
                            name="brand"
                            value={filters.brand}
                            onChange={handleFilterChange}
                          >
                            <option value="">All Brands</option>
                            {brands.map(brand => (
                              <option key={brand._id} value={brand._id}>
                                {brand.name}
                              </option>
                            ))}
                          </Form.Select>
                        </Form.Group>
                      </Col>
                      
                      <Col sm={6} md={4}>
                        <Form.Group controlId="vehicleTypeFilter">
                          <Form.Label>Vehicle Type</Form.Label>
                          <Form.Select
                            name="vehicleType"
                            value={filters.vehicleType}
                            onChange={handleFilterChange}
                          >
                            <option value="">All Types</option>
                            {VEHICLE_TYPES.map(type => (
                              <option key={type.value} value={type.value}>
                                {type.label}
                              </option>
                            ))}
                          </Form.Select>
                        </Form.Group>
                      </Col>
                      
                      <Col sm={6} md={4}>
                        <Form.Group controlId="statusFilter">
                          <Form.Label>Status</Form.Label>
                          <Form.Select
                            name="status"
                            value={filters.status}
                            onChange={handleFilterChange}
                          >
                            <option value="">All Status</option>
                            <option value="inStock">In Stock</option>
                            <option value="outOfStock">Out of Stock</option>
                            <option value="featured">Featured</option>
                          </Form.Select>
                        </Form.Group>
                      </Col>
                    </Row>
                    
                    <div className="d-flex justify-content-end mt-3">
                      <Button 
                        variant="outline-secondary" 
                        className="me-2"
                        onClick={resetFilters}
                      >
                        Reset
                      </Button>
                      <Button 
                        variant="primary"
                        onClick={applyFilters}
                      >
                        Apply Filters
                      </Button>
                    </div>
                  </Card.Body>
                </Card>
              )}
              
              {filteredProducts.length === 0 ? (
                <div className="text-center py-5">
                  <FaBox size={50} className="text-muted mb-3" />
                  <h4>No Products Found</h4>
                  <p className="mb-4">
                    {Object.values(filters).some(value => value !== '')
                      ? 'Try changing your filters to see more products.'
                      : 'There are no products in the system.'}
                  </p>
                </div>
              ) : (
                <>
                  <div className="table-responsive">
                    <Table hover className="align-middle">
                      <thead>
                        <tr>
                          <th style={{ width: '50px' }}></th>
                          <th>Name</th>
                          <th>Category/Brand</th>
                          <th>Price</th>
                          <th>Stock</th>
                          <th>Status</th>
                          <th>Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {paginatedProducts.map(product => (
                          <tr key={product._id}>
                            <td>
                              <img 
                                src={product.images && product.images.length > 0
                                  ? getImageUrl(`api/image/products/${product.images[0]}`)
                                  : '/placeholder.jpg'}
                                alt={product.name}
                                width="70"
                                height="70"
                                className="img-thumbnail"
                                style={{ objectFit: 'cover' }}
                              />
                            </td>
                            <td>
                              <div className="fw-bold">{product.name}</div>
                              <div className="small text-muted">
                                {product.vehicleType === 'car' ? 'Car' : 
                                 product.vehicleType === 'bike' ? 'Motorcycle' : 'Universal'} | 
                                {product.vehicleModel}
                              </div>
                            </td>
                            <td>
                              <div>{product.category?.name || 'Uncategorized'}</div>
                              <div className="small text-muted">{product.brand?.name || 'No Brand'}</div>
                            </td>
                            <td>
                              <div>{formatCurrency(product.price)}</div>
                              {product.originalPrice && product.originalPrice > product.price && (
                                <div className="small text-muted text-decoration-line-through">
                                  {formatCurrency(product.originalPrice)}
                                </div>
                              )}
                            </td>
                            <td>
                              {product.quantity}
                            </td>
                            <td>
                              <div className="d-flex flex-column gap-1">
                                {product.quantity > 0 ? (
                                  <Badge bg="success">In Stock</Badge>
                                ) : (
                                  <Badge bg="danger">Out of Stock</Badge>
                                )}
                                
                                {product.featured && (
                                  <Badge bg="primary">Featured</Badge>
                                )}
                              </div>
                            </td>
                            <td>
                              <Button 
                                variant="outline-secondary" 
                                size="sm" 
                                className="me-1"
                                onClick={() => handleShowProductModal(product)}
                              >
                                <FaEye />
                              </Button>
                              
                              <Button 
                                variant={product.featured ? "outline-warning" : "outline-primary"} 
                                size="sm" 
                                className="me-1"
                                onClick={() => handleToggleFeatured(product)}
                                title={product.featured ? "Remove from Featured" : "Add to Featured"}
                              >
                                <FaStar />
                              </Button>
                              
                              <Button 
                                variant="outline-danger" 
                                size="sm"
                                onClick={() => handleShowDeleteModal(product)}
                              >
                                <FaTrash />
                              </Button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </Table>
                  </div>
                  
                  <Pagination 
                    page={pagination.page}
                    pages={pagination.pages}
                    onPageChange={handlePageChange}
                  />
                </>
              )}
            </Card.Body>
          </Card>
        </Col>
      </Row>
      
      {/* Product Details Modal */}
      <Modal
        show={showProductModal}
        onHide={() => setShowProductModal(false)}
        size="lg"
        centered
      >
        <Modal.Header closeButton>
          <Modal.Title>
            Product Details
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {selectedProduct && (
            <Row>
              <Col md={5}>
                <div className="text-center mb-3">
                  <img 
                    src={selectedProduct.images && selectedProduct.images.length > 0
                      ? getImageUrl(`api/image/products/${selectedProduct.images[0]}`)
                      : '/placeholder.jpg'}
                    alt={selectedProduct.name}
                    className="img-fluid border rounded"
                    style={{ maxHeight: '200px' }}
                  />
                </div>
                
                <div className="d-flex justify-content-center">
                  {selectedProduct.images && selectedProduct.images.slice(1).map((image, index) => (
                    <div key={index} className="mx-1">
                      <img 
                        src={`/uploads/products/${image}`}
                        alt={`${selectedProduct.name} ${index + 2}`}
                        className="img-thumbnail"
                        style={{ width: '50px', height: '50px', objectFit: 'cover' }}
                      />
                    </div>
                  ))}
                </div>
                
                <div className="mt-3">
                  <h6>Product Information</h6>
                  <Table size="sm" className="mt-2">
                    <tbody>
                      <tr>
                        <td className="fw-bold">Category:</td>
                        <td>{selectedProduct.category?.name || 'Uncategorized'}</td>
                      </tr>
                      <tr>
                        <td className="fw-bold">Brand:</td>
                        <td>{selectedProduct.brand?.name || 'No Brand'}</td>
                      </tr>
                      <tr>
                        <td className="fw-bold">Price:</td>
                        <td>
                          {formatCurrency(selectedProduct.price)}
                          {selectedProduct.originalPrice && selectedProduct.originalPrice > selectedProduct.price && (
                            <span className="ms-2 text-muted text-decoration-line-through">
                              {formatCurrency(selectedProduct.originalPrice)}
                            </span>
                          )}
                        </td>
                      </tr>
                      <tr>
                        <td className="fw-bold">Stock:</td>
                        <td>{selectedProduct.quantity}</td>
                      </tr>
                      <tr>
                        <td className="fw-bold">Vehicle Type:</td>
                        <td>
                          {selectedProduct.vehicleType === 'car' ? 'Car' : 
                           selectedProduct.vehicleType === 'bike' ? 'Motorcycle' : 'Universal'}
                        </td>
                      </tr>
                      <tr>
                        <td className="fw-bold">Vehicle Model:</td>
                        <td>{selectedProduct.vehicleModel}</td>
                      </tr>
                      <tr>
                        <td className="fw-bold">Status:</td>
                        <td>
                          <div className="d-flex flex-wrap gap-1">
                            {selectedProduct.quantity > 0 ? (
                              <Badge bg="success">In Stock</Badge>
                            ) : (
                              <Badge bg="danger">Out of Stock</Badge>
                            )}
                            
                            {selectedProduct.featured && (
                              <Badge bg="primary">Featured</Badge>
                            )}
                          </div>
                        </td>
                      </tr>
                    </tbody>
                  </Table>
                </div>
              </Col>
              
              <Col md={7}>
                <h4>{selectedProduct.name}</h4>
                
                <div className="mb-3">
                  <strong>Vendor:</strong>{' '}
                  {selectedProduct.vendor?.shopName || 'Unknown Vendor'}
                </div>
                
                <h6>Description</h6>
                <p>{selectedProduct.description}</p>
                
                {selectedProduct.specifications && Object.keys(selectedProduct.specifications).length > 0 && (
                  <>
                    <h6 className="mt-3">Specifications</h6>
                    <Table striped bordered hover size="sm" className="mt-2">
                      <tbody>
                        {Object.entries(selectedProduct.specifications).map(([key, value]) => (
                          <tr key={key}>
                            <td className="fw-bold" style={{ width: '40%' }}>{key}</td>
                            <td>{value}</td>
                          </tr>
                        ))}
                      </tbody>
                    </Table>
                  </>
                )}
                
                <div className="mt-3 d-flex gap-2">
                  <Button 
                    variant={selectedProduct.featured ? "warning" : "primary"} 
                    onClick={() => handleToggleFeatured(selectedProduct)}
                  >
                    <FaStar className="me-1" />
                    {selectedProduct.featured ? "Remove from Featured" : "Add to Featured"}
                  </Button>
                  
                  <Button 
                    variant="danger"
                    onClick={() => {
                      setShowProductModal(false)
                      handleShowDeleteModal(selectedProduct)
                    }}
                  >
                    <FaTrash className="me-1" /> Delete Product
                  </Button>
                </div>
              </Col>
            </Row>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowProductModal(false)}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
      
      {/* Delete Confirmation Modal */}
      <Modal
        show={showDeleteModal}
        onHide={() => setShowDeleteModal(false)}
        centered
        backdrop="static"
      >
        <Modal.Header closeButton>
          <Modal.Title>Confirm Deletion</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p>Are you sure you want to delete this product?</p>
          {productToDelete && (
            <div className="d-flex align-items-center p-3 bg-light rounded">
              <img 
                src={productToDelete.images && productToDelete.images.length > 0
                  ? `/uploads/products/${productToDelete.images[0]}`
                  : '/placeholder.jpg'}
                alt={productToDelete.name}
                width="50"
                height="50"
                className="me-3"
              />
              <div>
                <div className="fw-bold">{productToDelete.name}</div>
                <div className="text-muted small">
                  {formatCurrency(productToDelete.price)} | 
                  {productToDelete.brand?.name} | 
                  {productToDelete.vehicleModel}
                </div>
              </div>
            </div>
          )}
          <Alert variant="warning" className="mt-3">
            <FaExclamationTriangle className="me-2" />
            This action cannot be undone. All product data will be permanently deleted.
          </Alert>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowDeleteModal(false)}>
            Cancel
          </Button>
          <Button variant="danger" onClick={handleDeleteProduct}>
            Delete Product
          </Button>
        </Modal.Footer>
      </Modal>
    </Container>
  )
}

export default AdminProductsPage