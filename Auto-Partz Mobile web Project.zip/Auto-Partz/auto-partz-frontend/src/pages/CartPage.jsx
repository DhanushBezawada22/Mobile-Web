// src/pages/CartPage.jsx
import { useState } from 'react'
import { Container, Row, Col, Card, Button, Form, Alert, ListGroup, Image } from 'react-bootstrap'
import { Link, useNavigate } from 'react-router-dom'
import { FaTrash, FaArrowLeft, FaShoppingCart, FaTag } from 'react-icons/fa'
import Breadcrumb from '../components/common/Breadcrumb'
import useCart from '../hooks/useCart'
import useAuth from '../hooks/useAuth'
import orderService from '../services/orderService'
import { formatCurrency } from '../utils/formatters'
import placeholderImg from '../assets/placeholder.jpg'
import { getImageUrl } from '../utils/imageHelper'

const CartPage = () => {
  const { 
    cartItems, 
    removeFromCart, 
    updateQuantity, 
    clearCart, 
    calculateTotals, 
    applyCoupon, 
    removeCoupon, 
    coupon 
  } = useCart()
  const { isAuthenticated } = useAuth()
  const navigate = useNavigate()
  const [couponCode, setCouponCode] = useState('')
  const [couponLoading, setCouponLoading] = useState(false)
  const [couponError, setCouponError] = useState(null)
  
  const totals = calculateTotals()
  
  const handleUpdateQuantity = (id, quantity) => {
    updateQuantity(id, quantity)
  }
  
  const handleRemoveItem = (id) => {
    removeFromCart(id)
  }
  
  const handleClearCart = () => {
    const confirmClear = window.confirm('Are you sure you want to clear your cart?')
    if (confirmClear) {
      clearCart()
    }
  }
  
  const handleApplyCoupon = async (e) => {
    e.preventDefault()
    
    if (!couponCode.trim()) {
      setCouponError('Please enter a coupon code')
      return
    }
    
    try {
      setCouponLoading(true)
      setCouponError(null)
      
      const response = await orderService.validateCoupon(couponCode)
      
      // Check if the coupon has minimum purchase requirement
      if (response.data.minPurchase > totals.itemsPrice) {
        setCouponError(`Minimum purchase of ${formatCurrency(response.data.minPurchase)} required for this coupon`)
        return
      }
      
      applyCoupon(response.data)
      setCouponCode('')
    } catch (error) {
      setCouponError(error.response?.data?.error || 'Invalid coupon code')
    } finally {
      setCouponLoading(false)
    }
  }
  
  const handleRemoveCoupon = () => {
    removeCoupon()
    setCouponCode('')
    setCouponError(null)
  }
  
  const handleCheckout = () => {
    if (isAuthenticated) {
      navigate('/checkout')
    } else {
      navigate('/login?redirect=checkout')
    }
  }

  return (
    <Container>
      <Breadcrumb items={[
        { label: 'Home', path: '/' },
        { label: 'Cart', path: null }
      ]} />
      
      <h1 className="section-title mb-4">Shopping Cart</h1>
      
      {cartItems.length === 0 ? (
        <Card className="shadow-sm border-0 text-center p-5">
          <Card.Body>
            <FaShoppingCart size={50} className="text-muted mb-3" />
            <h3>Your cart is empty</h3>
            <p className="mb-4">Looks like you haven't added any items to your cart yet.</p>
            <Button as={Link} to="/shop" variant="primary" size="lg">
              Start Shopping
            </Button>
          </Card.Body>
        </Card>
      ) : (
        <Row>
          <Col lg={8} className="mb-4">
            <Card className="shadow-sm border-0">
              <Card.Body>
                <div className="d-flex justify-content-between align-items-center mb-3">
                  <h5 className="mb-0">Cart Items ({cartItems.length})</h5>
                  <Button 
                    variant="outline-danger" 
                    size="sm" 
                    onClick={handleClearCart}
                  >
                    <FaTrash className="me-1" /> Clear Cart
                  </Button>
                </div>
                
                <ListGroup variant="flush">
                  {cartItems.map(item => (
                    <ListGroup.Item key={item.product} className="py-3 px-0 border-bottom">
                      <Row className="align-items-center">
                        <Col xs={3} sm={2}>
                          <Image 
                            src={item.product.images && item.product.images.length > 0
                                ? getImageUrl(`api/image/products/${item.images[0]}`)
                                : placeholderImg}
                            alt={item.name}
                            fluid
                            thumbnail
                          />
                        </Col>
                        <Col xs={9} sm={4}>
                          <Link to={`/product/${item.product}`} className="text-decoration-none">
                            <h6 className="mb-1">{item.name}</h6>
                          </Link>
                          <small className="text-muted d-block">
                            Price: {formatCurrency(item.price)}
                          </small>
                        </Col>
                        <Col xs={6} sm={3} className="mt-3 mt-sm-0">
                          <div className="d-flex align-items-center">
                            <Button 
                              variant="outline-secondary" 
                              size="sm"
                              onClick={() => handleUpdateQuantity(item.product, item.quantity - 1)}
                              disabled={item.quantity <= 1}
                            >
                              -
                            </Button>
                            <Form.Control
                              type="number"
                              min="1"
                              max={item.countInStock}
                              value={item.quantity}
                              onChange={(e) => handleUpdateQuantity(item.product, parseInt(e.target.value) || 1)}
                              className="text-center mx-2"
                              style={{ width: '60px' }}
                            />
                            <Button 
                              variant="outline-secondary" 
                              size="sm"
                              onClick={() => handleUpdateQuantity(item.product, item.quantity + 1)}
                              disabled={item.quantity >= item.countInStock}
                            >
                              +
                            </Button>
                          </div>
                        </Col>
                        <Col xs={6} sm={2} className="text-end mt-3 mt-sm-0">
                          <h6 className="mb-0">
                            {formatCurrency(item.price * item.quantity)}
                          </h6>
                        </Col>
                        <Col xs={12} sm={1} className="text-end mt-2 mt-sm-0">
                          <Button 
                            variant="outline-danger" 
                            size="sm"
                            onClick={() => handleRemoveItem(item.product)}
                          >
                            <FaTrash />
                          </Button>
                        </Col>
                      </Row>
                    </ListGroup.Item>
                  ))}
                </ListGroup>
                
                <div className="mt-3">
                  <Button 
                    as={Link} 
                    to="/shop" 
                    variant="outline-primary"
                    className="d-flex align-items-center"
                  >
                    <FaArrowLeft className="me-2" /> Continue Shopping
                  </Button>
                </div>
              </Card.Body>
            </Card>
          </Col>
          
          <Col lg={4}>
            <Card className="shadow-sm border-0 mb-4">
              <Card.Body>
                <h5 className="mb-3">Apply Coupon</h5>
                
                {coupon ? (
                  <Alert variant="success" className="d-flex justify-content-between align-items-center mb-0">
                    <div>
                      <div className="d-flex align-items-center mb-1">
                        <FaTag className="me-2" />
                        <strong>{coupon.code}</strong>
                      </div>
                      <div>
                        {coupon.type === 'percentage'
                          ? `${coupon.value}% off`
                          : `${formatCurrency(coupon.value)} off`}
                      </div>
                    </div>
                    <Button 
                      variant="outline-danger" 
                      size="sm"
                      onClick={handleRemoveCoupon}
                    >
                      Remove
                    </Button>
                  </Alert>
                ) : (
                  <Form onSubmit={handleApplyCoupon}>
                    <Form.Group className="mb-3">
                      <Form.Control
                        type="text"
                        placeholder="Enter coupon code"
                        value={couponCode}
                        onChange={(e) => setCouponCode(e.target.value)}
                      />
                      {couponError && (
                        <Form.Text className="text-danger">
                          {couponError}
                        </Form.Text>
                      )}
                    </Form.Group>
                    <Button 
                      type="submit" 
                      variant="outline-primary" 
                      className="w-100"
                      disabled={couponLoading}
                    >
                      {couponLoading ? 'Applying...' : 'Apply Coupon'}
                    </Button>
                  </Form>
                )}
              </Card.Body>
            </Card>
            
            <Card className="shadow-sm border-0">
              <Card.Body>
                <h5 className="mb-3">Order Summary</h5>
                
                <ListGroup variant="flush">
                  <ListGroup.Item className="d-flex justify-content-between px-0">
                    <span>Subtotal:</span>
                    <span>{formatCurrency(totals.itemsPrice)}</span>
                  </ListGroup.Item>
                  
                  {totals.discountAmount > 0 && (
                    <ListGroup.Item className="d-flex justify-content-between px-0 text-success">
                      <span>Discount:</span>
                      <span>-{formatCurrency(totals.discountAmount)}</span>
                    </ListGroup.Item>
                  )}
                  
                  <ListGroup.Item className="d-flex justify-content-between px-0">
                    <span>Tax (10%):</span>
                    <span>{formatCurrency(totals.taxPrice)}</span>
                  </ListGroup.Item>
                  
                  <ListGroup.Item className="d-flex justify-content-between px-0">
                    <span>Shipping:</span>
                    <span>
                      {totals.shippingPrice === 0 
                        ? 'Free' 
                        : formatCurrency(totals.shippingPrice)}
                    </span>
                  </ListGroup.Item>
                  
                  <ListGroup.Item className="d-flex justify-content-between px-0 fw-bold">
                    <span>Total:</span>
                    <span>{formatCurrency(totals.totalPrice)}</span>
                  </ListGroup.Item>
                </ListGroup>
                
                <Button 
                  variant="primary" 
                  size="lg" 
                  className="w-100 mt-3"
                  onClick={handleCheckout}
                >
                  Proceed to Checkout
                </Button>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      )}
    </Container>
  )
}

export default CartPage