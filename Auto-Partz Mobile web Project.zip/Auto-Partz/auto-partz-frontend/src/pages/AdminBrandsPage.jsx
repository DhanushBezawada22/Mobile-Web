// src/pages/AdminBrandsPage.jsx
import { useState, useEffect } from 'react'
import { Container, Row, Col, Card, Table, Button, Form, Modal, Alert, Image } from 'react-bootstrap'
import { FaPlus, FaEdit, FaTrash, FaUpload, FaExclamationTriangle, FaTags } from 'react-icons/fa'
import Breadcrumb from '../components/common/Breadcrumb'
import Sidebar from '../components/common/Sidebar'
import Loading from '../components/common/Loading'
import ErrorMessage from '../components/common/ErrorMessage'
import brandService from '../services/brandService'
import { isValidUrl } from '../utils/validators'

const AdminBrandsPage = () => {
  const [brands, setBrands] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  
  // Brand Form Modal
  const [showBrandModal, setShowBrandModal] = useState(false)
  const [brandFormData, setBrandFormData] = useState({
    name: '',
    description: '',
    website: ''
  })
  const [brandFormErrors, setBrandFormErrors] = useState({})
  const [isEditMode, setIsEditMode] = useState(false)
  const [formLoading, setFormLoading] = useState(false)
  const [logoFile, setLogoFile] = useState(null)
  const [logoPreview, setLogoPreview] = useState(null)
  
  // Delete Confirmation Modal
  const [showDeleteModal, setShowDeleteModal] = useState(false)
  const [brandToDelete, setBrandToDelete] = useState(null)
  
  useEffect(() => {
    const fetchBrands = async () => {
      try {
        setLoading(true)
        const response = await brandService.getBrands()
        setBrands(response.data)
      } catch (err) {
        setError(err.response?.data?.error || 'Failed to load brands')
        console.error('Error fetching brands:', err)
      } finally {
        setLoading(false)
      }
    }
    
    fetchBrands()
  }, [])
  
  // Brand Form Handlers
  const resetBrandForm = () => {
    setBrandFormData({
      name: '',
      description: '',
      website: ''
    })
    setBrandFormErrors({})
    setIsEditMode(false)
    setLogoFile(null)
    setLogoPreview(null)
  }
  
  const handleShowBrandModal = (brand = null) => {
    resetBrandForm()
    
    if (brand) {
      // Edit mode
      setIsEditMode(true)
      setBrandFormData({
        id: brand._id,
        name: brand.name,
        description: brand.description || '',
        website: brand.website || ''
      })
      
      // Set logo preview if exists
      if (brand.logo && brand.logo !== 'default-brand.jpg') {
        setLogoPreview(`/uploads/brands/${brand.logo}`)
      }
    }
    
    setShowBrandModal(true)
  }
  
  const handleBrandFormChange = (e) => {
    const { name, value } = e.target
    setBrandFormData({
      ...brandFormData,
      [name]: value
    })
    
    // Clear error for this field
    if (brandFormErrors[name]) {
      setBrandFormErrors({
        ...brandFormErrors,
        [name]: null
      })
    }
  }
  
  const handleLogoChange = (e) => {
    const file = e.target.files[0]
    
    if (file) {
      setLogoFile(file)
      
      // Create preview URL
      const previewUrl = URL.createObjectURL(file)
      setLogoPreview(previewUrl)
    }
  }
  
  const validateBrandForm = () => {
    const errors = {}
    
    if (!brandFormData.name.trim()) {
      errors.name = 'Brand name is required'
    }
    
    if (brandFormData.website && !isValidUrl(brandFormData.website)) {
      errors.website = 'Please enter a valid URL'
    }
    
    setBrandFormErrors(errors)
    return Object.keys(errors).length === 0
  }
  
  const handleSubmitBrandForm = async (e) => {
    e.preventDefault()
    
    if (!validateBrandForm()) {
      return
    }
    
    try {
      setFormLoading(true)
      
      let response
      
      if (isEditMode) {
        // Update brand
        const { id, ...updateData } = brandFormData
        response = await brandService.updateBrand(id, updateData)
        
        // Upload logo if selected
        if (logoFile) {
          const logoFormData = new FormData()
          logoFormData.append('brandLogo', logoFile)
          
          await brandService.uploadBrandLogo(id, logoFormData)
        }
        
        // Update brand in state
        setBrands(brands.map(brand => 
          brand._id === id ? response.data : brand
        ))
      } else {
        // Create brand
        response = await brandService.createBrand(brandFormData)
        
        // Upload logo if selected
        if (logoFile) {
          const logoFormData = new FormData()
          logoFormData.append('brandLogo', logoFile)
          
          await brandService.uploadBrandLogo(response.data._id, logoFormData)
        }
        
        // Add new brand to state
        setBrands([...brands, response.data])
      }
      
      setShowBrandModal(false)
      resetBrandForm()
    } catch (error) {
      const errorMsg = error.response?.data?.error || 'An error occurred'
      setBrandFormErrors({
        ...brandFormErrors,
        general: errorMsg
      })
    } finally {
      setFormLoading(false)
    }
  }
  
  // Delete Modal Handlers
  const handleShowDeleteModal = (brand) => {
    setBrandToDelete(brand)
    setShowDeleteModal(true)
  }
  
  const handleDeleteBrand = async () => {
    if (!brandToDelete) return
    
    try {
      await brandService.deleteBrand(brandToDelete._id)
      
      // Remove brand from state
      setBrands(brands.filter(brand => brand._id !== brandToDelete._id))
      setShowDeleteModal(false)
    } catch (error) {
      console.error('Error deleting brand:', error)
      // Show error message
    }
  }
  
  if (loading) return <Loading />
  if (error) return <ErrorMessage>{error}</ErrorMessage>
  
  return (
    <Container>
      <Breadcrumb items={[
        { label: 'Home', path: '/' },
        { label: 'Admin Dashboard', path: '/admin/dashboard' },
        { label: 'Brands', path: null }
      ]} />
      
      <Row>
        <Col lg={3} className="mb-4">
          <Sidebar variant="admin" />
        </Col>
        
        <Col lg={9}>
          <Card className="border-0 shadow-sm mb-4">
            <Card.Body>
              <div className="d-flex justify-content-between align-items-center mb-3">
                <h3 className="mb-0">Brands</h3>
                
                <Button 
                  variant="primary" 
                  onClick={() => handleShowBrandModal()}
                >
                  <FaPlus className="me-1" /> Add Brand
                </Button>
              </div>
              
              {brands.length === 0 ? (
                <div className="text-center py-5">
                  <FaTags size={50} className="text-muted mb-3" />
                  <h4>No Brands Found</h4>
                  <p className="mb-4">
                    Start by adding your first brand.
                  </p>
                  <Button 
                    variant="primary"
                    onClick={() => handleShowBrandModal()}
                  >
                    <FaPlus className="me-1" /> Add Brand
                  </Button>
                </div>
              ) : (
                <div className="table-responsive">
                  <Table hover className="align-middle">
                    <thead>
                      <tr>
                        <th style={{ width: '60px' }}></th>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Website</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {brands.map(brand => (
                        <tr key={brand._id}>
                          <td>
                            <img 
                              src={brand.logo ? `/uploads/brands/${brand.logo}` : '/placeholder.jpg'}
                              alt={brand.name}
                              width="40"
                              height="40"
                              className="img-thumbnail"
                              style={{ objectFit: 'contain' }}
                            />
                          </td>
                          <td>
                            <div className="fw-bold">{brand.name}</div>
                          </td>
                          <td>
                            {brand.description ? 
                              (brand.description.length > 100 ? 
                                `${brand.description.substring(0, 100)}...` : 
                                brand.description) : 
                              'No description'}
                          </td>
                          <td>
                            {brand.website ? (
                              <a 
                                href={brand.website} 
                                target="_blank" 
                                rel="noopener noreferrer"
                                className="text-decoration-none"
                              >
                                {brand.website.replace(/^https?:\/\//, '').replace(/\/$/, '')}
                              </a>
                            ) : (
                              'No website'
                            )}
                          </td>
                          <td>
                            <Button 
                              variant="outline-primary" 
                              size="sm" 
                              className="me-1"
                              onClick={() => handleShowBrandModal(brand)}
                            >
                              <FaEdit />
                            </Button>
                            <Button 
                              variant="outline-danger" 
                              size="sm"
                              onClick={() => handleShowDeleteModal(brand)}
                            >
                              <FaTrash />
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </Table>
                </div>
              )}
            </Card.Body>
          </Card>
        </Col>
      </Row>
      
      {/* Brand Form Modal */}
      <Modal
        show={showBrandModal}
        onHide={() => setShowBrandModal(false)}
        centered
        backdrop="static"
      >
        <Modal.Header closeButton>
          <Modal.Title>
            {isEditMode ? 'Edit Brand' : 'Add New Brand'}
          </Modal.Title>
        </Modal.Header>
        <Form onSubmit={handleSubmitBrandForm}>
          <Modal.Body>
            {brandFormErrors.general && (
              <Alert variant="danger">{brandFormErrors.general}</Alert>
            )}
            
            <Form.Group className="mb-3 text-center">
              <div className="position-relative d-inline-block mb-2">
                <Image 
                  src={logoPreview || '/placeholder.jpg'}
                  alt="Brand Logo"
                  width={120}
                  height={120}
                  className="border rounded p-2"
                  style={{ objectFit: 'contain' }}
                />
                <div 
                  className="position-absolute top-0 end-0 bottom-0 start-0 d-flex align-items-center justify-content-center bg-dark bg-opacity-50"
                  style={{ cursor: 'pointer', borderRadius: '4px' }}
                  onClick={() => document.getElementById('logoInput').click()}
                >
                  <FaUpload color="white" size={24} />
                </div>
              </div>
              <Form.Control
                type="file"
                id="logoInput"
                onChange={handleLogoChange}
                className="d-none"
                accept="image/*"
              />
              <div className="text-muted small">
                Click to upload brand logo
              </div>
            </Form.Group>
            
            <Form.Group className="mb-3" controlId="brandName">
              <Form.Label>Brand Name</Form.Label>
              <Form.Control
                type="text"
                name="name"
                value={brandFormData.name}
                onChange={handleBrandFormChange}
                isInvalid={!!brandFormErrors.name}
                placeholder="Enter brand name"
              />
              <Form.Control.Feedback type="invalid">
                {brandFormErrors.name}
              </Form.Control.Feedback>
            </Form.Group>
            
            <Form.Group className="mb-3" controlId="brandDescription">
              <Form.Label>Description (Optional)</Form.Label>
              <Form.Control
                as="textarea"
                rows={3}
                name="description"
                value={brandFormData.description}
                onChange={handleBrandFormChange}
                placeholder="Enter brand description"
              />
            </Form.Group>
            
            <Form.Group className="mb-3" controlId="brandWebsite">
              <Form.Label>Website URL (Optional)</Form.Label>
              <Form.Control
                type="url"
                name="website"
                value={brandFormData.website}
                onChange={handleBrandFormChange}
                isInvalid={!!brandFormErrors.website}
                placeholder="https://example.com"
              />
              <Form.Control.Feedback type="invalid">
                {brandFormErrors.website}
              </Form.Control.Feedback>
            </Form.Group>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={() => setShowBrandModal(false)}>
              Cancel
            </Button>
            <Button 
              variant="primary" 
              type="submit"
              disabled={formLoading}
            >
              {formLoading ? 'Saving...' : (isEditMode ? 'Update Brand' : 'Add Brand')}
            </Button>
          </Modal.Footer>
        </Form>
      </Modal>
      
      {/* Delete Confirmation Modal */}
      <Modal
        show={showDeleteModal}
        onHide={() => setShowDeleteModal(false)}
        centered
        backdrop="static"
      >
        <Modal.Header closeButton>
          <Modal.Title>Confirm Deletion</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p>Are you sure you want to delete this brand?</p>
          {brandToDelete && (
            <div className="d-flex align-items-center p-3 bg-light rounded">
              <img 
                src={brandToDelete.logo ? `/uploads/brands/${brandToDelete.logo}` : '/placeholder.jpg'}
                alt={brandToDelete.name}
                width="60"
                height="60"
                className="me-3"
                style={{ objectFit: 'contain' }}
              />
              <div>
                <div className="fw-bold">{brandToDelete.name}</div>
                {brandToDelete.description && (
                  <div className="text-muted small mt-1">
                    {brandToDelete.description.length > 100 ? 
                      `${brandToDelete.description.substring(0, 100)}...` : 
                      brandToDelete.description}
                  </div>
                )}
              </div>
            </div>
          )}
          <Alert variant="warning" className="mt-3">
            <FaExclamationTriangle className="me-2" />
            This action cannot be undone. Products associated with this brand may become orphaned.
          </Alert>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowDeleteModal(false)}>
            Cancel
          </Button>
          <Button variant="danger" onClick={handleDeleteBrand}>
            Delete Brand
          </Button>
        </Modal.Footer>
      </Modal>
    </Container>
  )
}

export default AdminBrandsPage