// src/pages/AdminUsersPage.jsx
import { useState, useEffect } from 'react'
import { Container, Row, Col, Card, Table, Button, Form, Badge, Modal, Alert } from 'react-bootstrap'
import { FaPlus, FaEdit, FaTrash, FaSearch, FaFilter, FaTimes, FaUserShield, FaExclamationTriangle } from 'react-icons/fa'
import Breadcrumb from '../components/common/Breadcrumb'
import Sidebar from '../components/common/Sidebar'
import Loading from '../components/common/Loading'
import ErrorMessage from '../components/common/ErrorMessage'
import Pagination from '../components/common/Pagination'
import userService from '../services/userService'
import { formatDate } from '../utils/formatters'
import { USER_ROLES } from '../utils/constants'
import { isValidEmail, isValidPassword } from '../utils/validators'

const AdminUsersPage = () => {
  const [users, setUsers] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [filters, setFilters] = useState({
    search: '',
    role: ''
  })
  const [showFilters, setShowFilters] = useState(false)
  const [pagination, setPagination] = useState({
    page: 1,
    pages: 1,
    total: 0
  })
  
  // Edit/Add User Modal
  const [showUserModal, setShowUserModal] = useState(false)
  const [userFormData, setUserFormData] = useState({
    name: '',
    email: '',
    password: '',
    role: 'customer'
  })
  const [userFormErrors, setUserFormErrors] = useState({})
  const [isEditMode, setIsEditMode] = useState(false)
  const [formLoading, setFormLoading] = useState(false)
  
  // Delete User Modal
  const [showDeleteModal, setShowDeleteModal] = useState(false)
  const [userToDelete, setUserToDelete] = useState(null)
  
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        setLoading(true)
        const response = await userService.getUsers()
        setUsers(response.data)
        setPagination({
          page: 1,
          pages: Math.ceil(response.data.length / 10),
          total: response.data.length
        })
      } catch (err) {
        setError(err.response?.data?.error || 'Failed to load users')
        console.error('Error fetching users:', err)
      } finally {
        setLoading(false)
      }
    }
    
    fetchUsers()
  }, [])
  
  const handleFilterChange = (e) => {
    const { name, value } = e.target
    setFilters({
      ...filters,
      [name]: value
    })
  }
  
  const applyFilters = () => {
    // Reset to page 1 when filters change
    setPagination({
      ...pagination,
      page: 1
    })
    
    setShowFilters(false)
  }
  
  const resetFilters = () => {
    setFilters({
      search: '',
      role: ''
    })
  }
  
  const handlePageChange = (page) => {
    setPagination({
      ...pagination,
      page
    })
  }
  
  // Filter users client-side
  const filteredUsers = users.filter(user => {
    return (
      (filters.search === '' || 
       user.name.toLowerCase().includes(filters.search.toLowerCase()) ||
       user.email.toLowerCase().includes(filters.search.toLowerCase())) &&
      (filters.role === '' || user.role === filters.role)
    )
  })
  
  // Calculate paginated users
  const paginatedUsers = filteredUsers.slice(
    (pagination.page - 1) * 10,
    pagination.page * 10
  )
  
  // Handle user form
  const resetUserForm = () => {
    setUserFormData({
      name: '',
      email: '',
      password: '',
      role: 'customer'
    })
    setUserFormErrors({})
    setIsEditMode(false)
  }
  
  const handleShowUserModal = (user = null) => {
    resetUserForm()
    
    if (user) {
      // Edit mode
      setIsEditMode(true)
      setUserFormData({
        id: user._id,
        name: user.name,
        email: user.email,
        password: '',
        role: user.role
      })
    }
    
    setShowUserModal(true)
  }
  
  const handleUserFormChange = (e) => {
    const { name, value } = e.target
    setUserFormData({
      ...userFormData,
      [name]: value
    })
    
    // Clear error for this field
    if (userFormErrors[name]) {
      setUserFormErrors({
        ...userFormErrors,
        [name]: null
      })
    }
  }
  
  const validateUserForm = () => {
    const errors = {}
    
    if (!userFormData.name.trim()) {
      errors.name = 'Name is required'
    }
    
    if (!userFormData.email) {
      errors.email = 'Email is required'
    } else if (!isValidEmail(userFormData.email)) {
      errors.email = 'Invalid email address'
    }
    
    if (!isEditMode && !userFormData.password) {
      errors.password = 'Password is required'
    } else if (userFormData.password && !isValidPassword(userFormData.password)) {
      errors.password = 'Password must be at least 6 characters'
    }
    
    setUserFormErrors(errors)
    return Object.keys(errors).length === 0
  }
  
  const handleSubmitUserForm = async (e) => {
    e.preventDefault()
    
    if (!validateUserForm()) {
      return
    }
    
    try {
      setFormLoading(true)
      
      if (isEditMode) {
        // Update user
        const { id, ...updateData } = userFormData
        
        // Remove password if not provided (don't update it)
        if (!updateData.password) {
          delete updateData.password
        }
        
        const response = await userService.updateUser(id, updateData)
        
        // Update user in state
        setUsers(users.map(user => 
          user._id === id ? response.data : user
        ))
      } else {
        // Create user
        const response = await userService.createUser(userFormData)
        
        // Add new user to state
        setUsers([response.data, ...users])
      }
      
      setShowUserModal(false)
      resetUserForm()
    } catch (error) {
      const errorMsg = error.response?.data?.error || 'An error occurred'
      setUserFormErrors({
        ...userFormErrors,
        general: errorMsg
      })
    } finally {
      setFormLoading(false)
    }
  }
  
  // Handle user deletion
  const handleShowDeleteModal = (user) => {
    setUserToDelete(user)
    setShowDeleteModal(true)
  }
  
  const handleDeleteUser = async () => {
    if (!userToDelete) return
    
    try {
      await userService.deleteUser(userToDelete._id)
      
      // Remove user from state
      setUsers(users.filter(user => user._id !== userToDelete._id))
      setShowDeleteModal(false)
      setUserToDelete(null)
    } catch (error) {
      console.error('Error deleting user:', error)
      // Show error message
    }
  }
  
  if (loading) return <Loading />
  if (error) return <ErrorMessage>{error}</ErrorMessage>
  
  return (
    <Container>
      <Breadcrumb items={[
        { label: 'Home', path: '/' },
        { label: 'Admin Dashboard', path: '/admin/dashboard' },
        { label: 'Users', path: null }
      ]} />
      
      <Row>
        <Col lg={3} className="mb-4">
          <Sidebar variant="admin" />
        </Col>
        
        <Col lg={9}>
          <Card className="border-0 shadow-sm mb-4">
            <Card.Body>
              <div className="d-flex justify-content-between align-items-center mb-3">
                <h3 className="mb-0">Manage Users</h3>
                
                <Button 
                  variant="primary" 
                  onClick={() => handleShowUserModal()}
                >
                  <FaPlus className="me-1" /> Add User
                </Button>
              </div>
              
              <div className="d-flex justify-content-between align-items-center mb-3">
                <div className="d-flex">
                  <Button 
                    variant="outline-secondary" 
                    className="me-2 d-flex align-items-center"
                    onClick={() => setShowFilters(!showFilters)}
                  >
                    <FaFilter className="me-1" /> Filters
                    {Object.values(filters).some(value => value !== '') && (
                      <Badge 
                        bg="primary" 
                        pill 
                        className="ms-1"
                      >
                        {Object.values(filters).filter(value => value !== '').length}
                      </Badge>
                    )}
                  </Button>
                  
                  <Form.Control
                    type="text"
                    placeholder="Search users..."
                    value={filters.search}
                    onChange={e => setFilters({...filters, search: e.target.value})}
                    className="me-2"
                    style={{ maxWidth: '250px' }}
                  />
                </div>
                
                <div>
                  <span className="text-muted me-2">
                    {filteredUsers.length} user(s)
                  </span>
                </div>
              </div>
              
              {showFilters && (
                <Card className="mb-3 border">
                  <Card.Body>
                    <div className="d-flex justify-content-between align-items-center mb-3">
                      <h5 className="mb-0">Filter Users</h5>
                      <Button 
                        variant="link" 
                        className="p-0 text-muted"
                        onClick={() => setShowFilters(false)}
                      >
                        <FaTimes />
                      </Button>
                    </div>
                    
                    <Row className="g-2">
                      <Col sm={6}>
                        <Form.Group controlId="roleFilter">
                          <Form.Label>Role</Form.Label>
                          <Form.Select
                            name="role"
                            value={filters.role}
                            onChange={handleFilterChange}
                          >
                            <option value="">All Roles</option>
                            {USER_ROLES.map(role => (
                              <option key={role.value} value={role.value}>
                                {role.label}
                              </option>
                            ))}
                          </Form.Select>
                        </Form.Group>
                      </Col>
                    </Row>
                    
                    <div className="d-flex justify-content-end mt-3">
                      <Button 
                        variant="outline-secondary" 
                        className="me-2"
                        onClick={resetFilters}
                      >
                        Reset
                      </Button>
                      <Button 
                        variant="primary"
                        onClick={applyFilters}
                      >
                        Apply Filters
                      </Button>
                    </div>
                  </Card.Body>
                </Card>
              )}
              
              {filteredUsers.length === 0 ? (
                <div className="text-center py-5">
                  <FaUserShield size={50} className="text-muted mb-3" />
                  <h4>No Users Found</h4>
                  <p className="mb-4">
                    {Object.values(filters).some(value => value !== '')
                      ? 'Try changing your filters or add a new user.'
                      : 'There are no users in the system.'}
                  </p>
                  <Button 
                    variant="primary"
                    onClick={() => handleShowUserModal()}
                  >
                    <FaPlus className="me-1" /> Add User
                  </Button>
                </div>
              ) : (
                <>
                  <div className="table-responsive">
                    <Table hover className="align-middle">
                      <thead>
                        <tr>
                          <th>Name</th>
                          <th>Email</th>
                          <th>Role</th>
                          <th>Joined</th>
                          <th>Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {paginatedUsers.map(user => (
                          <tr key={user._id}>
                            <td>
                              <div className="d-flex align-items-center">
                                <div className="rounded-circle bg-primary text-white d-flex justify-content-center align-items-center me-2" 
                                  style={{ width: '40px', height: '40px' }}>
                                  {user.name.charAt(0).toUpperCase()}
                                </div>
                                <div>
                                  {user.name}
                                </div>
                              </div>
                            </td>
                            <td>{user.email}</td>
                            <td>
                              <Badge 
                                bg={
                                  user.role === 'admin' ? 'danger' :
                                  user.role === 'vendor' ? 'success' : 'primary'
                                }
                              >
                                {user.role.charAt(0).toUpperCase() + user.role.slice(1)}
                              </Badge>
                            </td>
                            <td>{formatDate(user.createdAt)}</td>
                            <td>
                              <Button 
                                variant="outline-primary" 
                                size="sm" 
                                className="me-1"
                                onClick={() => handleShowUserModal(user)}
                              >
                                <FaEdit />
                              </Button>
                              <Button 
                                variant="outline-danger" 
                                size="sm"
                                onClick={() => handleShowDeleteModal(user)}
                              >
                                <FaTrash />
                              </Button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </Table>
                  </div>
                  
                  <Pagination 
                    page={pagination.page}
                    pages={pagination.pages}
                    onPageChange={handlePageChange}
                  />
                </>
              )}
            </Card.Body>
          </Card>
        </Col>
      </Row>
      
      {/* User Form Modal */}
      <Modal
        show={showUserModal}
        onHide={() => setShowUserModal(false)}
        centered
        backdrop="static"
      >
        <Modal.Header closeButton>
          <Modal.Title>
            {isEditMode ? 'Edit User' : 'Add New User'}
          </Modal.Title>
        </Modal.Header>
        <Form onSubmit={handleSubmitUserForm}>
          <Modal.Body>
            {userFormErrors.general && (
              <Alert variant="danger">{userFormErrors.general}</Alert>
            )}
            
            <Form.Group className="mb-3" controlId="userName">
              <Form.Label>Name</Form.Label>
              <Form.Control
                type="text"
                name="name"
                value={userFormData.name}
                onChange={handleUserFormChange}
                isInvalid={!!userFormErrors.name}
                placeholder="Enter user name"
              />
              <Form.Control.Feedback type="invalid">
                {userFormErrors.name}
              </Form.Control.Feedback>
            </Form.Group>
            
            <Form.Group className="mb-3" controlId="userEmail">
              <Form.Label>Email</Form.Label>
              <Form.Control
                type="email"
                name="email"
                value={userFormData.email}
                onChange={handleUserFormChange}
                isInvalid={!!userFormErrors.email}
                placeholder="Enter email address"
              />
              <Form.Control.Feedback type="invalid">
                {userFormErrors.email}
              </Form.Control.Feedback>
            </Form.Group>
            
            <Form.Group className="mb-3" controlId="userPassword">
              <Form.Label>
                {isEditMode ? 'Password (leave blank to keep current)' : 'Password'}
              </Form.Label>
              <Form.Control
                type="password"
                name="password"
                value={userFormData.password}
                onChange={handleUserFormChange}
                isInvalid={!!userFormErrors.password}
                placeholder={isEditMode ? "Enter new password (optional)" : "Enter password"}
              />
              <Form.Control.Feedback type="invalid">
                {userFormErrors.password}
              </Form.Control.Feedback>
            </Form.Group>
            
            <Form.Group className="mb-3" controlId="userRole">
              <Form.Label>Role</Form.Label>
              <Form.Select
                name="role"
                value={userFormData.role}
                onChange={handleUserFormChange}
              >
                {USER_ROLES.map(role => (
                  <option key={role.value} value={role.value}>
                    {role.label}
                  </option>
                ))}
              </Form.Select>
              <Form.Text className="text-muted">
                Be careful when assigning admin rights.
              </Form.Text>
            </Form.Group>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={() => setShowUserModal(false)}>
              Cancel
            </Button>
            <Button 
              variant="primary" 
              type="submit"
              disabled={formLoading}
            >
              {formLoading ? 'Saving...' : (isEditMode ? 'Update User' : 'Add User')}
            </Button>
          </Modal.Footer>
        </Form>
      </Modal>
      
      {/* Delete Confirmation Modal */}
      <Modal
        show={showDeleteModal}
        onHide={() => setShowDeleteModal(false)}
        centered
        backdrop="static"
      >
        <Modal.Header closeButton>
          <Modal.Title>Confirm Deletion</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p>Are you sure you want to delete this user?</p>
          {userToDelete && (
            <div className="p-3 bg-light rounded">
              <div className="fw-bold">{userToDelete.name}</div>
              <div>{userToDelete.email}</div>
              <div>
                <Badge 
                  bg={
                    userToDelete.role === 'admin' ? 'danger' :
                    userToDelete.role === 'vendor' ? 'success' : 'primary'
                  }
                  className="mt-1"
                >
                  {userToDelete.role.charAt(0).toUpperCase() + userToDelete.role.slice(1)}
                </Badge>
              </div>
            </div>
          )}
          <Alert variant="warning" className="mt-3">
            <FaExclamationTriangle className="me-2" />
            This action cannot be undone. All user data will be permanently deleted.
          </Alert>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowDeleteModal(false)}>
            Cancel
          </Button>
          <Button variant="danger" onClick={handleDeleteUser}>
            Delete User
          </Button>
        </Modal.Footer>
      </Modal>
    </Container>
  )
}

export default AdminUsersPage