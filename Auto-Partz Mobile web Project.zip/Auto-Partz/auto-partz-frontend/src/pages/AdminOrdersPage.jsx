// src/pages/AdminOrdersPage.jsx
import { useState, useEffect } from 'react'
import { Container, Row, Col, Card, Table, Button, Form, Badge, Modal, Alert, Tabs, Tab } from 'react-bootstrap'
import { FaEye, FaSearch, FaFilter, FaTimes, FaExclamationTriangle, FaMoneyBillWave } from 'react-icons/fa'
import Breadcrumb from '../components/common/Breadcrumb'
import Sidebar from '../components/common/Sidebar'
import Loading from '../components/common/Loading'
import ErrorMessage from '../components/common/ErrorMessage'
import Pagination from '../components/common/Pagination'
import orderService from '../services/orderService'
import { formatCurrency, formatDate, formatOrderStatus } from '../utils/formatters'
import { ORDER_STATUSES } from '../utils/constants'

const AdminOrdersPage = () => {
  const [orders, setOrders] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [activeTab, setActiveTab] = useState('all')
  const [filters, setFilters] = useState({
    search: '',
    dateRange: '',
    paymentStatus: ''
  })
  const [showFilters, setShowFilters] = useState(false)
  const [pagination, setPagination] = useState({
    page: 1,
    pages: 1,
    total: 0
  })
  
  // Order Details Modal
  const [showOrderModal, setShowOrderModal] = useState(false)
  const [selectedOrder, setSelectedOrder] = useState(null)
  const [updatingStatus, setUpdatingStatus] = useState(false)
  const [updatingPayment, setUpdatingPayment] = useState(false)
  
  useEffect(() => {
    const fetchOrders = async () => {
      try {
        setLoading(true)
        const response = await orderService.getOrders()
        setOrders(response.data)
        setPagination({
          page: 1,
          pages: Math.ceil(response.data.length / 10),
          total: response.data.length
        })
      } catch (err) {
        setError(err.response?.data?.error || 'Failed to load orders')
        console.error('Error fetching orders:', err)
      } finally {
        setLoading(false)
      }
    }
    
    fetchOrders()
  }, [])
  
  const handleFilterChange = (e) => {
    const { name, value } = e.target
    setFilters({
      ...filters,
      [name]: value
    })
  }
  
  const applyFilters = () => {
    // Reset to page 1 when filters change
    setPagination({
      ...pagination,
      page: 1
    })
    
    setShowFilters(false)
  }
  
  const resetFilters = () => {
    setFilters({
      search: '',
      dateRange: '',
      paymentStatus: ''
    })
  }
  
  const handlePageChange = (page) => {
    setPagination({
      ...pagination,
      page
    })
  }
  
  const handleShowOrderModal = (order) => {
    setSelectedOrder(order)
    setShowOrderModal(true)
  }
  
  const handleUpdateOrderStatus = async (orderId, status) => {
    try {
      setUpdatingStatus(true)
      
      await orderService.updateOrderStatus(orderId, { status })
      
      // Update order in state
      setOrders(orders.map(order => 
        order._id === orderId 
          ? { ...order, status } 
          : order
      ))
      
      // If viewing order details, update selected order
      if (selectedOrder && selectedOrder._id === orderId) {
        setSelectedOrder({ ...selectedOrder, status })
      }
    } catch (error) {
      console.error('Error updating order status:', error)
      // Show error message
    } finally {
      setUpdatingStatus(false)
    }
  }
  
  const handleUpdatePaymentStatus = async (orderId, isPaid) => {
    try {
      setUpdatingPayment(true)
      
      // In a real app, there would be more details for payment
      // For simplicity, we'll just toggle the isPaid status
      await orderService.updateOrderToPaid(orderId, {
        id: `manual-${Date.now()}`,
        status: 'completed',
        update_time: new Date().toISOString(),
        email_address: selectedOrder?.user?.email || 'admin@autopartz.com'
      })
      
      // Update order in state
      setOrders(orders.map(order => 
        order._id === orderId 
          ? { ...order, isPaid, paidAt: isPaid ? new Date().toISOString() : null } 
          : order
      ))
      
      // If viewing order details, update selected order
      if (selectedOrder && selectedOrder._id === orderId) {
        setSelectedOrder({ 
          ...selectedOrder, 
          isPaid, 
          paidAt: isPaid ? new Date().toISOString() : null 
        })
      }
    } catch (error) {
      console.error('Error updating payment status:', error)
      // Show error message
    } finally {
      setUpdatingPayment(false)
    }
  }
  
  // Filter orders based on selected tab and filters
  const filteredOrders = orders.filter(order => {
    // Filter by tab
    if (activeTab !== 'all' && order.status !== activeTab) {
      return false
    }
    
    // Filter by search (order ID or customer name)
    if (filters.search) {
      const searchLower = filters.search.toLowerCase()
      const idMatch = order._id.toLowerCase().includes(searchLower)
      const customerMatch = order.user?.name?.toLowerCase().includes(searchLower)
      
      if (!idMatch && !customerMatch) {
        return false
      }
    }
    
    // Filter by payment status
    if (filters.paymentStatus) {
      if (filters.paymentStatus === 'paid' && !order.isPaid) {
        return false
      }
      if (filters.paymentStatus === 'unpaid' && order.isPaid) {
        return false
      }
    }
    
    // Filter by date range
    if (filters.dateRange) {
      const orderDate = new Date(order.createdAt)
      const today = new Date()
      
      if (filters.dateRange === 'today') {
        // Check if order is from today
        return (
          orderDate.getDate() === today.getDate() &&
          orderDate.getMonth() === today.getMonth() &&
          orderDate.getFullYear() === today.getFullYear()
        )
      } else if (filters.dateRange === 'week') {
        // Check if order is from this week
        const weekAgo = new Date(today)
        weekAgo.setDate(today.getDate() - 7)
        return orderDate >= weekAgo
      } else if (filters.dateRange === 'month') {
        // Check if order is from this month
        const monthAgo = new Date(today)
        monthAgo.setMonth(today.getMonth() - 1)
        return orderDate >= monthAgo
      }
    }
    
    return true
  })
  
  // Calculate paginated orders
  const paginatedOrders = filteredOrders.slice(
    (pagination.page - 1) * 10,
    pagination.page * 10
  )
  
  // Calculate statistics
  const totalRevenue = orders.reduce((sum, order) => sum + (order.isPaid ? order.totalPrice : 0), 0)
  const pendingRevenue = orders.reduce((sum, order) => sum + (!order.isPaid ? order.totalPrice : 0), 0)
  
  if (loading) return <Loading />
  if (error) return <ErrorMessage>{error}</ErrorMessage>
    
      
        return (
          <Container>
            <Breadcrumb items={[
              { label: 'Home', path: '/' },
              { label: 'Admin Dashboard', path: '/admin/dashboard' },
              { label: 'Orders', path: null }
            ]} />
            
            <Row>
              <Col lg={3} className="mb-4">
                <Sidebar variant="admin" />
              </Col>
              
              <Col lg={9}>
                <Row className="g-4 mb-4">
                  <Col md={6}>
                    <Card className="border-0 shadow-sm h-100">
                      <Card.Body className="d-flex align-items-center">
                        <div className="rounded-circle bg-success bg-opacity-10 p-3 me-3">
                          <FaMoneyBillWave className="text-success" size={24} />
                        </div>
                        <div>
                          <h6 className="mb-0 text-muted">Total Revenue</h6>
                          <h3 className="mt-1 mb-0">{formatCurrency(totalRevenue)}</h3>
                        </div>
                      </Card.Body>
                    </Card>
                  </Col>
                  
                  <Col md={6}>
                    <Card className="border-0 shadow-sm h-100">
                      <Card.Body className="d-flex align-items-center">
                        <div className="rounded-circle bg-warning bg-opacity-10 p-3 me-3">
                          <FaMoneyBillWave className="text-warning" size={24} />
                        </div>
                        <div>
                          <h6 className="mb-0 text-muted">Pending Payments</h6>
                          <h3 className="mt-1 mb-0">{formatCurrency(pendingRevenue)}</h3>
                        </div>
                      </Card.Body>
                    </Card>
                  </Col>
                </Row>
                
                <Card className="border-0 shadow-sm mb-4">
                  <Card.Body>
                    <h3 className="mb-4">Order Management</h3>
                    
                    <div className="d-flex justify-content-between align-items-center mb-3">
                      <div className="d-flex">
                        <Button 
                          variant="outline-secondary" 
                          className="me-2 d-flex align-items-center"
                          onClick={() => setShowFilters(!showFilters)}
                        >
                          <FaFilter className="me-1" /> Filters
                          {Object.values(filters).some(value => value !== '') && (
                            <Badge pill bg="primary" className="ms-2">
                              Active
                            </Badge>
                          )}
                        </Button>
                        
                        {showFilters && (
                          <Button 
                            variant="outline-danger" 
                            className="d-flex align-items-center"
                            onClick={resetFilters}
                          >
                            <FaTimes className="me-1" /> Clear
                          </Button>
                        )}
                      </div>
                      
                      <Form.Group className="mb-0" style={{ width: '300px' }}>
                        <Form.Control
                          type="text"
                          placeholder="Search orders..."
                          name="search"
                          value={filters.search}
                          onChange={handleFilterChange}
                        />
                      </Form.Group>
                    </div>
                    
                    {showFilters && (
                      <Card className="mb-4 border-0 shadow-sm">
                        <Card.Body>
                          <Row>
                            <Col md={4}>
                              <Form.Group className="mb-3">
                                <Form.Label>Date Range</Form.Label>
                                <Form.Select
                                  name="dateRange"
                                  value={filters.dateRange}
                                  onChange={handleFilterChange}
                                >
                                  <option value="">All Dates</option>
                                  <option value="today">Today</option>
                                  <option value="week">Last 7 Days</option>
                                  <option value="month">Last 30 Days</option>
                                </Form.Select>
                              </Form.Group>
                            </Col>
                            
                            <Col md={4}>
                              <Form.Group className="mb-3">
                                <Form.Label>Payment Status</Form.Label>
                                <Form.Select
                                  name="paymentStatus"
                                  value={filters.paymentStatus}
                                  onChange={handleFilterChange}
                                >
                                  <option value="">All</option>
                                  <option value="paid">Paid</option>
                                  <option value="unpaid">Unpaid</option>
                                </Form.Select>
                              </Form.Group>
                            </Col>
                            
                            <Col md={4} className="d-flex align-items-end">
                              <Button variant="primary" onClick={applyFilters}>
                                Apply Filters
                              </Button>
                            </Col>
                          </Row>
                        </Card.Body>
                      </Card>
                    )}
                    
                    <Tabs
                      activeKey={activeTab}
                      onSelect={(k) => setActiveTab(k)}
                      className="mb-4"
                    >
                      <Tab eventKey="all" title="All Orders" />
                      {Object.entries(ORDER_STATUSES).map(([key, label]) => (
                        <Tab 
                          key={key} 
                          eventKey={key} 
                          title={typeof status === 'object' ? status.label : status} 
                        />
                      ))}
                    </Tabs>
                    
                    <div className="table-responsive">
                      <Table striped bordered hover className="mb-0">
                        <thead>
                          <tr>
                            <th>Order ID</th>
                            <th>Customer</th>
                            <th>Date</th>
                            <th>Total</th>
                            <th>Status</th>
                            <th>Payment</th>
                            <th>Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {paginatedOrders.length > 0 ? (
                            paginatedOrders.map((order) => (
                              <tr key={order._id}>
                                <td>{order._id.substring(0, 8)}...</td>
                                <td>{order.user?.name || 'Guest'}</td>
                                <td>{formatDate(order.createdAt)}</td>
                                <td>{formatCurrency(order.totalPrice)}</td>
                                <td>
                                  <Badge bg={order.status === 'completed' ? 'success' : 
                                            order.status === 'cancelled' ? 'danger' : 
                                            order.status === 'processing' ? 'warning' : 'info'}>
                                    {formatOrderStatus(order.status)}
                                  </Badge>
                                </td>
                                <td>
                                  {order.isPaid ? (
                                    <Badge bg="success">Paid</Badge>
                                  ) : (
                                    <Badge bg="danger">Unpaid</Badge>
                                  )}
                                </td>
                                <td>
                                  <Button
                                    variant="outline-primary"
                                    size="sm"
                                    onClick={() => handleShowOrderModal(order)}
                                  >
                                    <FaEye /> View
                                  </Button>
                                </td>
                              </tr>
                            ))
                          ) : (
                            <tr>
                              <td colSpan="7" className="text-center py-4">
                                {filteredOrders.length === 0 ? 'No orders found matching your criteria' : 'Loading...'}
                              </td>
                            </tr>
                          )}
                        </tbody>
                      </Table>
                    </div>
                    
                    {pagination.pages > 1 && (
                      <div className="d-flex justify-content-center mt-4">
                        <Pagination
                          currentPage={pagination.page}
                          totalPages={pagination.pages}
                          onPageChange={handlePageChange}
                        />
                      </div>
                    )}
                  </Card.Body>
                </Card>
              </Col>
            </Row>
            
            {/* Order Details Modal */}
            <Modal 
              show={showOrderModal} 
              onHide={() => setShowOrderModal(false)}
              size="lg"
            >
              <Modal.Header closeButton>
                <Modal.Title>Order Details</Modal.Title>
              </Modal.Header>
              
              {selectedOrder && (
                <Modal.Body>
                  <Row className="mb-4">
                    <Col md={6}>
                      <h5>Order Information</h5>
                      <p>
                        <strong>Order ID:</strong> {selectedOrder._id}<br />
                        <strong>Date:</strong> {formatDate(selectedOrder.createdAt)}<br />
                        <strong>Status:</strong> {formatOrderStatus(selectedOrder.status)}<br />
                        <strong>Payment:</strong> {selectedOrder.isPaid ? 
                          `Paid on ${formatDate(selectedOrder.paidAt)}` : 'Not Paid'}
                      </p>
                    </Col>
                    
                    <Col md={6}>
                      <h5>Customer Information</h5>
                      <p>
                        <strong>Name:</strong> {selectedOrder.user?.name || 'Guest'}<br />
                        <strong>Email:</strong> {selectedOrder.user?.email || 'N/A'}<br />
                        <strong>Phone:</strong> {selectedOrder.shippingAddress?.phone || 'N/A'}
                      </p>
                      
                      <h5 className="mt-3">Shipping Address</h5>
                      <p>
                        {selectedOrder.shippingAddress?.address},<br />
                        {selectedOrder.shippingAddress?.city}, {selectedOrder.shippingAddress?.state}<br />
                        {selectedOrder.shippingAddress?.postalCode}, {selectedOrder.shippingAddress?.country}
                      </p>
                    </Col>
                  </Row>
                  
                  <h5>Order Items</h5>
                  <Table striped bordered hover>
                    <thead>
                      <tr>
                        <th>Product</th>
                        <th>Price</th>
                        <th>Qty</th>
                        <th>Subtotal</th>
                      </tr>
                    </thead>
                    <tbody>
                      {selectedOrder.orderItems.map((item) => (
                        <tr key={item._id}>
                          <td>
                            <div className="d-flex align-items-center">
                              <img 
                                src={item.image} 
                                alt={item.name} 
                                style={{ width: '50px', height: '50px', objectFit: 'cover', marginRight: '10px' }} 
                              />
                              {item.name}
                            </div>
                          </td>
                          <td>{formatCurrency(item.price)}</td>
                          <td>{item.quantity}</td>
                          <td>{formatCurrency(item.price * item.quantity)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </Table>
                  
                  <div className="text-end">
                    <Table borderless className="w-50 float-end">
                      <tbody>
                        <tr>
                          <td><strong>Items Price:</strong></td>
                          <td>{formatCurrency(selectedOrder.itemsPrice)}</td>
                        </tr>
                        {selectedOrder.discountAmount > 0 && (
                          <tr>
                            <td><strong>Discount:</strong></td>
                            <td className="text-danger">-{formatCurrency(selectedOrder.discountAmount)}</td>
                          </tr>
                        )}
                        <tr>
                          <td><strong>Shipping:</strong></td>
                          <td>{formatCurrency(selectedOrder.shippingPrice)}</td>
                        </tr>
                        <tr>
                          <td><strong>Tax:</strong></td>
                          <td>{formatCurrency(selectedOrder.taxPrice)}</td>
                        </tr>
                        <tr>
                          <td><strong>Total:</strong></td>
                          <td><strong>{formatCurrency(selectedOrder.totalPrice)}</strong></td>
                        </tr>
                      </tbody>
                    </Table>
                  </div>
                  
                  <hr className="my-4" />
                  
                  <div className="d-flex justify-content-between">
                    <div>
                      <h5>Update Order Status</h5>
                      <div className="d-flex">
                        <Form.Select
                          value={selectedOrder.status}
                          onChange={(e) => handleUpdateOrderStatus(selectedOrder._id, e.target.value)}
                          disabled={updatingStatus}
                          className="me-2"
                        >
                          {Object.entries(ORDER_STATUSES).map(([key, label]) => (
                            <option key={key} value={key}>{label}</option>
                          ))}
                        </Form.Select>
                        <Button 
                          variant="primary"
                          disabled={updatingStatus}
                        >
                          {updatingStatus ? 'Updating...' : 'Update'}
                        </Button>
                      </div>
                    </div>
                    
                    <div>
                      <h5>Update Payment Status</h5>
                      <Button
                        variant={selectedOrder.isPaid ? 'danger' : 'success'}
                        onClick={() => handleUpdatePaymentStatus(selectedOrder._id, !selectedOrder.isPaid)}
                        disabled={updatingPayment}
                      >
                        {updatingPayment ? 'Updating...' : 
                         selectedOrder.isPaid ? 'Mark as Unpaid' : 'Mark as Paid'}
                      </Button>
                      {selectedOrder.isPaid && (
                        <div className="text-muted mt-1">
                          Paid on: {formatDate(selectedOrder.paidAt)}
                        </div>
                      )}
                    </div>
                  </div>
                </Modal.Body>
              )}
              
              <Modal.Footer>
                <Button variant="secondary" onClick={() => setShowOrderModal(false)}>
                  Close
                </Button>
              </Modal.Footer>
            </Modal>
          </Container>
        )
      }
      
      export default AdminOrdersPage