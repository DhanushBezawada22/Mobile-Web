// src/pages/VendorProductsPage.jsx
import { useState, useEffect } from 'react'
import { Container, Row, Col, Card, Table, Button, Form, Badge, Modal } from 'react-bootstrap'
import { Link } from 'react-router-dom'
import { 
  FaPlus, 
  FaEdit, 
  FaTrash,
  FaCloudUploadAlt,
  FaImages,
  FaSearch, 
  FaSort, 
  FaFilter,
  FaTimes,
  FaInfoCircle,
  FaExclamationTriangle
} from 'react-icons/fa'
import Breadcrumb from '../components/common/Breadcrumb'
import Sidebar from '../components/common/Sidebar'
import Loading from '../components/common/Loading'
import ErrorMessage from '../components/common/ErrorMessage'
import Pagination from '../components/common/Pagination'
import productService from '../services/productService'
import vendorService from '../services/vendorService'
import categoryService from '../services/categoryService'
import brandService from '../services/brandService'
import useAuth from '../hooks/useAuth'
import { VEHICLE_TYPES } from '../utils/constants'
import { formatCurrency, formatDate } from '../utils/formatters'
import placeholderImg from '../assets/placeholder.jpg'
import { getImageUrl } from '../utils/imageHelper'

const VendorProductsPage = () => {
  const { user } = useAuth()
  
  const [products, setProducts] = useState([])
  const [vendor, setVendor] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [pagination, setPagination] = useState({
    page: 1,
    pages: 1,
    total: 0
  })
  
  const [filters, setFilters] = useState({
    search: '',
    category: '',
    brand: '',
    vehicleType: '',
    status: ''
  })
  
  const [categories, setCategories] = useState([])
  const [brands, setBrands] = useState([])
  const [showFilters, setShowFilters] = useState(false)
  
  // Delete confirmation modal
  const [showDeleteModal, setShowDeleteModal] = useState(false)
  const [productToDelete, setProductToDelete] = useState(null)
  
  // Product form modal
  const [showProductModal, setShowProductModal] = useState(false)
  const [productFormData, setProductFormData] = useState({
    name: '',
    description: '',
    price: '',
    originalPrice: '',
    quantity: '',
    category: '',
    brand: '',
    vehicleType: '',
    vehicleModel: '',
    specifications: {}
  })
  const [productFormErrors, setProductFormErrors] = useState({})
  const [specKeys, setSpecKeys] = useState([''])
  const [specValues, setSpecValues] = useState([''])
  const [isEditMode, setIsEditMode] = useState(false)
  const [formLoading, setFormLoading] = useState(false)
  
  const [productImages, setProductImages] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true)
        
        // Fetch vendor first
        const vendorResponse = await vendorService.getVendorByUser(user._id)
        setVendor(vendorResponse.data)
        
        // Fetch products for this vendor
        const productsResponse = await vendorService.getVendorProducts(vendorResponse.data._id)
        setProducts(productsResponse.data)
        setPagination({
          page: 1,
          pages: Math.ceil(productsResponse.count / 10),
          total: productsResponse.count
        })
        
        // Fetch categories and brands for filters
        const [categoriesResponse, brandsResponse] = await Promise.all([
          categoryService.getCategories(),
          brandService.getBrands()
        ])
        
        setCategories(categoriesResponse.data)
        setBrands(brandsResponse.data)
      } catch (err) {
        setError(err.response?.data?.error || 'Failed to load products')
        console.error('Error fetching vendor products:', err)
      } finally {
        setLoading(false)
      }
    }
    
    fetchData()
  }, [user])
  
  const handleFilterChange = (e) => {
    const { name, value } = e.target
    setFilters({
      ...filters,
      [name]: value
    })
  }
  
  const applyFilters = () => {
    // Filter products based on current filters
    // This is a client-side filter for simplicity
    // In a real app, you'd want to send these filters to the API
    
    // Reset to page 1 when filters change
    setPagination({
      ...pagination,
      page: 1
    })
    
    setShowFilters(false)
  }
  
  const resetFilters = () => {
    setFilters({
      search: '',
      category: '',
      brand: '',
      vehicleType: '',
      status: ''
    })
  }
  
  const handlePageChange = (page) => {
    setPagination({
      ...pagination,
      page
    })
    
    // In a real app, fetch the data for the new page
    // For now, we'll just update the page number
  }
  
  // Filter products client-side (for demo purposes)
  const filteredProducts = products.filter(product => {
    return (
      (filters.search === '' || 
       product.name.toLowerCase().includes(filters.search.toLowerCase())) &&
      (filters.category === '' || product.category._id === filters.category) &&
      (filters.brand === '' || product.brand._id === filters.brand) &&
      (filters.vehicleType === '' || product.vehicleType === filters.vehicleType) &&
      (filters.status === '' || 
       (filters.status === 'inStock' && product.quantity > 0) ||
       (filters.status === 'outOfStock' && product.quantity <= 0) ||
       (filters.status === 'lowStock' && product.quantity > 0 && product.quantity <= 5))
    )
  })
  
  // Confirm product deletion
  const handleShowDeleteModal = (product) => {
    setProductToDelete(product)
    setShowDeleteModal(true)
  }
  
  const handleDeleteProduct = async () => {
    if (!productToDelete) return
    
    try {
      await productService.deleteProduct(productToDelete._id)
      
      // Remove product from state
      setProducts(products.filter(p => p._id !== productToDelete._id))
      
      setShowDeleteModal(false)
      setProductToDelete(null)
    } catch (error) {
      console.error('Error deleting product:', error)
      // Show error message
    }
  }
  
  // Handle product form
  const resetProductForm = () => {
    setProductFormData({
      name: '',
      description: '',
      price: '',
      originalPrice: '',
      quantity: '',
      category: '',
      brand: '',
      vehicleType: '',
      vehicleModel: '',
      specifications: {}
    });
    setProductFormErrors({});
    setSpecKeys(['']);
    setSpecValues(['']);
    setProductImages([]);  // Add this line
    setIsEditMode(false);
  };

  const handleShowProductModal = (product = null) => {
    resetProductForm()
    
    if (product) {
      // Edit mode
      setIsEditMode(true)
      setProductFormData({
        id: product._id,
        name: product.name,
        description: product.description,
        price: product.price,
        originalPrice: product.originalPrice || '',
        quantity: product.quantity,
        category: product.category._id,
        brand: product.brand._id,
        vehicleType: product.vehicleType,
        vehicleModel: product.vehicleModel,
        specifications: product.specifications || {}
      })
      
      // Set up specification fields
      if (product.specifications && Object.keys(product.specifications).length > 0) {
        const keys = Object.keys(product.specifications)
        const values = keys.map(key => product.specifications[key])
        setSpecKeys(keys)
        setSpecValues(values)
      }
    }
    
    setShowProductModal(true)
  }
  
  const handleProductFormChange = (e) => {
    const { name, value } = e.target
    setProductFormData({
      ...productFormData,
      [name]: value
    })
    
    // Clear error for this field
    if (productFormErrors[name]) {
      setProductFormErrors({
        ...productFormErrors,
        [name]: null
      })
    }
  }
  
  const handleSpecKeyChange = (index, value) => {
    const newSpecKeys = [...specKeys]
    newSpecKeys[index] = value
    setSpecKeys(newSpecKeys)
    
    // If this is the last key and it's not empty, add a new empty field
    if (index === specKeys.length - 1 && value.trim() !== '') {
      setSpecKeys([...newSpecKeys, ''])
      setSpecValues([...specValues, ''])
    }
  }
  
  const handleSpecValueChange = (index, value) => {
    const newSpecValues = [...specValues]
    newSpecValues[index] = value
    setSpecValues(newSpecValues)
  }
  
  const validateProductForm = () => {
    const errors = {}
    
    if (!productFormData.name.trim()) {
      errors.name = 'Product name is required'
    }
    
    if (!productFormData.description.trim()) {
      errors.description = 'Description is required'
    }
    
    if (!productFormData.price) {
      errors.price = 'Price is required'
    } else if (isNaN(productFormData.price) || parseFloat(productFormData.price) <= 0) {
      errors.price = 'Price must be a positive number'
    }
    
    if (productFormData.originalPrice && (isNaN(productFormData.originalPrice) || parseFloat(productFormData.originalPrice) <= 0)) {
      errors.originalPrice = 'Original price must be a positive number'
    }
    
    if (!productFormData.quantity) {
      errors.quantity = 'Quantity is required'
    } else if (isNaN(productFormData.quantity) || parseInt(productFormData.quantity) < 0) {
      errors.quantity = 'Quantity must be a non-negative number'
    }
    
    if (!productFormData.category) {
      errors.category = 'Category is required'
    }
    
    if (!productFormData.brand) {
      errors.brand = 'Brand is required'
    }
    
    if (!productFormData.vehicleType) {
      errors.vehicleType = 'Vehicle type is required'
    }
    
    if (!productFormData.vehicleModel.trim()) {
      errors.vehicleModel = 'Vehicle model is required'
    }
    
    setProductFormErrors(errors)
    return Object.keys(errors).length === 0
  }


  // Handle image upload
  const handleProductImageChange = (e) => {
    const files = Array.from(e.target.files);
    
    // Filter files larger than 1MB
    const validFiles = files.filter(file => file.size <= 1000000);
    
    // Limit to 5 files
    const selectedFiles = validFiles.slice(0, 5);
    
    setProductImages(selectedFiles);
    
    // Show warning if some files were filtered out
    if (validFiles.length < files.length) {
      // You could add toast notifications here
      console.warn('Some files were skipped because they exceed the size limit (1MB)');
    }
    
    if (files.length > 5) {
      // You could add toast notifications here
      console.warn('Only the first 5 images were selected');
    }
  };
  
  const handleSubmitProductForm = async (e) => {
    e.preventDefault();
    
    if (!validateProductForm()) {
      return;
    }
    
    try {
      setFormLoading(true);
      
      // Process specifications
      const specifications = {};
      specKeys.forEach((key, index) => {
        if (key.trim() && specValues[index].trim()) {
          specifications[key.trim()] = specValues[index].trim();
        }
      });
      
      // Prepare data
      const productData = {
        ...productFormData,
        specifications,
        price: parseFloat(productFormData.price),
        originalPrice: productFormData.originalPrice ? parseFloat(productFormData.originalPrice) : undefined,
        quantity: parseInt(productFormData.quantity),
        vendor: vendor._id
      };
      
      let response;
      
      if (isEditMode) {
        // Update product
        const { id, ...updateData } = productData;
        response = await productService.updateProduct(id, updateData);
        
        // Update product in state first
        setProducts(products.map(p => 
          p._id === id ? { ...p, ...response.data } : p
        ));
        
        // Upload images if there are any
        if (productImages.length > 0) {
          const formData = new FormData();
          productImages.forEach(file => {
            formData.append('productImages', file);
          });
          
          const imageResponse = await productService.uploadProductImages(id, formData);
          
          // Update product again after image upload
          setProducts(products.map(p => 
            p._id === id ? imageResponse.data : p
          ));
        }
      } else {
        // Create product
        response = await productService.createProduct(productData);
        
        // If there are images, upload them
        if (productImages.length > 0) {
          const formData = new FormData();
          productImages.forEach(file => {
            formData.append('productImages', file);
          });
          
          const imageResponse = await productService.uploadProductImages(response.data._id, formData);
          
          // Add new product with images to state
          setProducts([imageResponse.data, ...products.filter(p => p._id !== response.data._id)]);
        } else {
          // Add new product to state
          setProducts([response.data, ...products]);
        }
      }
      
      setShowProductModal(false);
      resetProductForm();
    } catch (error) {
      console.error('Error saving product:', error);
      // Show error message
    } finally {
      setFormLoading(false);
    }
  };

  if (loading) return <Loading />
  if (error) return <ErrorMessage>{error}</ErrorMessage>
  
  return (
    <Container>
      <Breadcrumb items={[
        { label: 'Home', path: '/' },
        { label: 'Vendor Dashboard', path: '/vendor/dashboard' },
        { label: 'Products', path: null }
      ]} />
      
      <Row>
        <Col lg={3} className="mb-4">
          <Sidebar variant="vendor" />
        </Col>
        
        <Col lg={9}>
          {!vendor?.isVerified && (
            <Alert variant="warning" className="mb-4">
              <div className="d-flex align-items-center">
                <FaExclamationTriangle className="me-2" />
                <div>
                  <strong>Your vendor account is pending verification.</strong>
                  <div>You can add products, but they won't be visible to customers until your account is verified.</div>
                </div>
              </div>
            </Alert>
          )}
          
          <Card className="border-0 shadow-sm mb-4">
            <Card.Body>
              <div className="d-flex justify-content-between align-items-center mb-3">
                <h3 className="mb-0">My Products</h3>
                
                <Button 
                  variant="primary" 
                  onClick={() => handleShowProductModal()}
                >
                  <FaPlus className="me-1" /> Add Product
                </Button>
              </div>
              
              <div className="d-flex justify-content-between align-items-center mb-3">
                <div className="d-flex">
                  <Button 
                    variant="outline-secondary" 
                    className="me-2 d-flex align-items-center"
                    onClick={() => setShowFilters(!showFilters)}
                  >
                    <FaFilter className="me-1" /> Filters
                    {Object.values(filters).some(value => value !== '') && (
                      <Badge 
                        bg="primary" 
                        pill 
                        className="ms-1"
                      >
                        {Object.values(filters).filter(value => value !== '').length}
                      </Badge>
                    )}
                  </Button>
                  
                  <Form.Control
                    type="text"
                    placeholder="Search products..."
                    value={filters.search}
                    onChange={e => setFilters({...filters, search: e.target.value})}
                    className="me-2"
                    style={{ maxWidth: '250px' }}
                  />
                </div>
                
                <div>
                  <span className="text-muted me-2">
                    {filteredProducts.length} product(s)
                  </span>
                </div>
              </div>
              
              {showFilters && (
                <Card className="mb-3 border">
                  <Card.Body>
                    <div className="d-flex justify-content-between align-items-center mb-3">
                      <h5 className="mb-0">Filter Products</h5>
                      <Button 
                        variant="link" 
                        className="p-0 text-muted"
                        onClick={() => setShowFilters(false)}
                      >
                        <FaTimes />
                      </Button>
                    </div>
                    
                    <Row className="g-2">
                      <Col sm={6} md={4}>
                        <Form.Group controlId="categoryFilter">
                          <Form.Label>Category</Form.Label>
                          <Form.Select
                            name="category"
                            value={filters.category}
                            onChange={handleFilterChange}
                          >
                            <option value="">All Categories</option>
                            {categories.map(category => (
                              <option key={category._id} value={category._id}>
                                {category.name}
                              </option>
                            ))}
                          </Form.Select>
                        </Form.Group>
                      </Col>
                      
                      <Col sm={6} md={4}>
                        <Form.Group controlId="brandFilter">
                          <Form.Label>Brand</Form.Label>
                          <Form.Select
                            name="brand"
                            value={filters.brand}
                            onChange={handleFilterChange}
                          >
                            <option value="">All Brands</option>
                            {brands.map(brand => (
                              <option key={brand._id} value={brand._id}>
                                {brand.name}
                              </option>
                            ))}
                          </Form.Select>
                        </Form.Group>
                      </Col>
                      
                      <Col sm={6} md={4}>
                        <Form.Group controlId="vehicleTypeFilter">
                          <Form.Label>Vehicle Type</Form.Label>
                          <Form.Select
                            name="vehicleType"
                            value={filters.vehicleType}
                            onChange={handleFilterChange}
                          >
                            <option value="">All Types</option>
                            {VEHICLE_TYPES.map(type => (
                              <option key={type.value} value={type.value}>
                                {type.label}
                              </option>
                            ))}
                          </Form.Select>
                        </Form.Group>
                      </Col>
                      
                      <Col sm={6} md={4}>
                        <Form.Group controlId="statusFilter">
                          <Form.Label>Stock Status</Form.Label>
                          <Form.Select
                            name="status"
                            value={filters.status}
                            onChange={handleFilterChange}
                          >
                            <option value="">All Status</option>
                            <option value="inStock">In Stock</option>
                            <option value="outOfStock">Out of Stock</option>
                            <option value="lowStock">Low Stock</option>
                          </Form.Select>
                        </Form.Group>
                      </Col>
                    </Row>
                    
                    <div className="d-flex justify-content-end mt-3">
                      <Button 
                        variant="outline-secondary" 
                        className="me-2"
                        onClick={resetFilters}
                      >
                        Reset
                      </Button>
                      <Button 
                        variant="primary"
                        onClick={applyFilters}
                      >
                        Apply Filters
                      </Button>
                    </div>
                  </Card.Body>
                </Card>
              )}
              
              {filteredProducts.length === 0 ? (
                <div className="text-center py-5">
                  <FaInfoCircle size={50} className="text-muted mb-3" />
                  <h4>No Products Found</h4>
                  <p className="mb-3">
                    {Object.values(filters).some(value => value !== '')
                      ? 'Try changing your filters or create a new product.'
                      : 'You haven\'t added any products yet.'}
                  </p>
                  <Button 
                    variant="primary"
                    onClick={() => handleShowProductModal()}
                  >
                    <FaPlus className="me-1" /> Add Your First Product
                  </Button>
                </div>
              ) : (
                <>
                  <div className="table-responsive">
                    <Table hover className="align-middle">
                      <thead>
                        <tr>
                          <th style={{ width: '60px' }}></th>
                          <th>Name</th>
                          <th>Category</th>
                          <th>Price</th>
                          <th>Stock</th>
                          <th>Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {filteredProducts.map(product => (
                          <tr key={product._id}>
                            <td>
                              <img 
                                src={product.images && product.images.length > 0
                                  ? getImageUrl(`api/image/products/${product.images[0]}`)
                                  : placeholderImg}
                                alt={product.name}
                                width="50"
                                height="50"
                                className="img-thumbnail"
                                style={{ objectFit: 'cover' }}
                              />
                            </td>
                            <td>
                              <div className="fw-bold">{product.name}</div>
                              <div className="small text-muted">
                                {product.vehicleType === 'car' ? 'Car' : 
                                 product.vehicleType === 'bike' ? 'Motorcycle' : 'Universal'} | 
                                {product.vehicleModel}
                              </div>
                            </td>
                            <td>
                              <div>{product.category.name}</div>
                              <div className="small text-muted">{product.brand.name}</div>
                            </td>
                            <td>
                              <div>{formatCurrency(product.price)}</div>
                              {product.originalPrice && product.originalPrice > product.price && (
                                <div className="small text-muted text-decoration-line-through">
                                  {formatCurrency(product.originalPrice)}
                                </div>
                              )}
                            </td>
                            <td>
                              <span 
                                className={`badge bg-${
                                  product.quantity <= 0 ? 'danger' :
                                  product.quantity <= 5 ? 'warning' : 'success'
                                }`}
                              >
                                {product.quantity <= 0 
                                  ? 'Out of Stock' 
                                  : `${product.quantity} in stock`}
                              </span>
                            </td>
                            <td>
                              <Button 
                                variant="outline-primary" 
                                size="sm" 
                                className="me-1"
                                onClick={() => handleShowProductModal(product)}
                              >
                                <FaEdit />
                              </Button>
                              <Button 
                                variant="outline-danger" 
                                size="sm"
                                onClick={() => handleShowDeleteModal(product)}
                              >
                                <FaTrash />
                              </Button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </Table>
                  </div>
                  
                  <Pagination 
                    page={pagination.page}
                    pages={pagination.pages}
                    onPageChange={handlePageChange}
                  />
                </>
              )}
            </Card.Body>
          </Card>
        </Col>
      </Row>
      
      {/* Delete Confirmation Modal */}
      <Modal
        show={showDeleteModal}
        onHide={() => setShowDeleteModal(false)}
        centered
        backdrop="static"
      >
        <Modal.Header closeButton>
          <Modal.Title>Confirm Deletion</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p>Are you sure you want to delete this product?</p>
          {productToDelete && (
            <div className="d-flex align-items-center p-2 bg-light rounded">
              <img 
                src={productToDelete.images && productToDelete.images.length > 0
                  ? `/uploads/products/${productToDelete.images[0]}`
                  : placeholderImg}
                alt={productToDelete.name}
                width="50"
                height="50"
                className="me-3"
              />
              <div>
                <div className="fw-bold">{productToDelete.name}</div>
                <div className="text-muted small">{formatCurrency(productToDelete.price)}</div>
              </div>
            </div>
          )}
          <p className="mt-3 mb-0 text-danger">
            <FaExclamationTriangle className="me-1" />
            This action cannot be undone.
          </p>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowDeleteModal(false)}>
            Cancel
          </Button>
          <Button variant="danger" onClick={handleDeleteProduct}>
            Delete Product
          </Button>
        </Modal.Footer>
      </Modal>
      
      {/* Product Form Modal */}
      <Modal
        show={showProductModal}
        onHide={() => setShowProductModal(false)}
        size="lg"
        centered
        backdrop="static"
      >
        <Modal.Header closeButton>
          <Modal.Title>
            {isEditMode ? 'Edit Product' : 'Add New Product'}
          </Modal.Title>
        </Modal.Header>
        <Form onSubmit={handleSubmitProductForm}>
          <Modal.Body>
            <Row>
              <Col md={6}>
                <Form.Group className="mb-3" controlId="productName">
                  <Form.Label>Product Name *</Form.Label>
                  <Form.Control
                    type="text"
                    name="name"
                    value={productFormData.name}
                    onChange={handleProductFormChange}
                    isInvalid={!!productFormErrors.name}
                    placeholder="Enter product name"
                  />
                  <Form.Control.Feedback type="invalid">
                    {productFormErrors.name}
                  </Form.Control.Feedback>
                </Form.Group>
              </Col>
              
              <Col md={6}>
                <Form.Group className="mb-3" controlId="productCategory">
                  <Form.Label>Category *</Form.Label>
                  <Form.Select
                    name="category"
                    value={productFormData.category}
                    onChange={handleProductFormChange}
                    isInvalid={!!productFormErrors.category}
                  >
                    <option value="">Select Category</option>
                    {categories.map(category => (
                      <option key={category._id} value={category._id}>
                        {category.name}
                      </option>
                    ))}
                  </Form.Select>
                  <Form.Control.Feedback type="invalid">
                    {productFormErrors.category}
                  </Form.Control.Feedback>
                </Form.Group>
              </Col>
            </Row>
            
            <Row>
              <Col md={6}>
                <Form.Group className="mb-3" controlId="productBrand">
                  <Form.Label>Brand *</Form.Label>
                  <Form.Select
                    name="brand"
                    value={productFormData.brand}
                    onChange={handleProductFormChange}
                    isInvalid={!!productFormErrors.brand}
                  >
                    <option value="">Select Brand</option>
                    {brands.map(brand => (
                      <option key={brand._id} value={brand._id}>
                        {brand.name}
                      </option>
                    ))}
                  </Form.Select>
                  <Form.Control.Feedback type="invalid">
                    {productFormErrors.brand}
                  </Form.Control.Feedback>
                </Form.Group>
              </Col>
              
              <Col md={6}>
                <Form.Group className="mb-3" controlId="productVehicleType">
                  <Form.Label>Vehicle Type *</Form.Label>
                  <Form.Select
                    name="vehicleType"
                    value={productFormData.vehicleType}
                    onChange={handleProductFormChange}
                    isInvalid={!!productFormErrors.vehicleType}
                  >
                    <option value="">Select Vehicle Type</option>
                    {VEHICLE_TYPES.map(type => (
                      <option key={type.value} value={type.value}>
                        {type.label}
                      </option>
                    ))}
                  </Form.Select>
                  <Form.Control.Feedback type="invalid">
                    {productFormErrors.vehicleType}
                  </Form.Control.Feedback>
                </Form.Group>
              </Col>
            </Row>
            
            <Form.Group className="mb-3" controlId="productVehicleModel">
              <Form.Label>Vehicle Model *</Form.Label>
              <Form.Control
                type="text"
                name="vehicleModel"
                value={productFormData.vehicleModel}
                onChange={handleProductFormChange}
                isInvalid={!!productFormErrors.vehicleModel}
                placeholder="e.g. Honda CB Shine, BMW 3 Series"
              />
              <Form.Control.Feedback type="invalid">
                {productFormErrors.vehicleModel}
              </Form.Control.Feedback>
            </Form.Group>
            
            <Row>
              <Col md={4}>
                <Form.Group className="mb-3" controlId="productPrice">
                  <Form.Label>Price ($) *</Form.Label>
                  <Form.Control
                    type="number"
                    name="price"
                    value={productFormData.price}
                    onChange={handleProductFormChange}
                    isInvalid={!!productFormErrors.price}
                    placeholder="Enter price"
                    min="0"
                    step="0.01"
                  />
                  <Form.Control.Feedback type="invalid">
                    {productFormErrors.price}
                  </Form.Control.Feedback>
                </Form.Group>
              </Col>
              
              <Col md={4}>
                <Form.Group className="mb-3" controlId="productOriginalPrice">
                  <Form.Label>Original Price ($)</Form.Label>
                  <Form.Control
                    type="number"
                    name="originalPrice"
                    value={productFormData.originalPrice}
                    onChange={handleProductFormChange}
                    isInvalid={!!productFormErrors.originalPrice}
                    placeholder="Optional"
                    min="0"
                    step="0.01"
                  />
                  <Form.Control.Feedback type="invalid">
                    {productFormErrors.originalPrice}
                  </Form.Control.Feedback>
                </Form.Group>
              </Col>
              
              <Col md={4}>
                <Form.Group className="mb-3" controlId="productQuantity">
                  <Form.Label>Quantity *</Form.Label>
                  <Form.Control
                    type="number"
                    name="quantity"
                    value={productFormData.quantity}
                    onChange={handleProductFormChange}
                    isInvalid={!!productFormErrors.quantity}
                    placeholder="Enter quantity"
                    min="0"
                  />
                  <Form.Control.Feedback type="invalid">
                    {productFormErrors.quantity}
                  </Form.Control.Feedback>
                </Form.Group>
              </Col>
            </Row>
            
            <Form.Group className="mb-3" controlId="productDescription">
              <Form.Label>Description *</Form.Label>
              <Form.Control
                as="textarea"
                rows={3}
                name="description"
                value={productFormData.description}
                onChange={handleProductFormChange}
                isInvalid={!!productFormErrors.description}
                placeholder="Enter product description"
              />
              <Form.Control.Feedback type="invalid">
                {productFormErrors.description}
              </Form.Control.Feedback>
            </Form.Group>


            {/* Image Upload Section */}
<h6 className="mt-4 mb-3">Product Images</h6>
<div className="mb-3">
  <div className="mb-3">
    {isEditMode && productFormData.id && (
      <div className="mb-3">
        <p className="mb-2">Current Images:</p>
        <div className="d-flex flex-wrap gap-2 mb-2">
          {products.find(p => p._id === productFormData.id)?.images?.length > 0 ? (
            products.find(p => p._id === productFormData.id).images.map((image, idx) => (
              <div key={idx} className="position-relative" style={{ width: '100px' }}>
                <img
                  src={`/uploads/products/${image}`}
                  alt={`Product image ${idx + 1}`}
                  className="img-thumbnail"
                  style={{ width: '100px', height: '100px', objectFit: 'cover' }}
                />
              </div>
            ))
          ) : (
            <p className="text-muted">No images available</p>
          )}
        </div>
      </div>
    )}
    
    <Form.Group controlId="productImages">
      <Form.Label>Upload Images</Form.Label>
      <div className="border rounded p-3">
        <div className="mb-3 text-center">
          <FaCloudUploadAlt size={40} className="text-primary mb-2" />
          <p className="mb-1">Drag & drop your images here or click to browse</p>
          <small className="text-muted">
            Maximum 5 images, JPEG/PNG/GIF, max 1MB each
          </small>
        </div>
        
        <Form.Control
          type="file"
          accept="image/jpeg,image/png,image/gif"
          multiple
          onChange={handleProductImageChange}
          className="mb-3"
        />
        
        {productImages.length > 0 && (
          <div>
            <p className="mb-2">Selected images:</p>
            <div className="d-flex flex-wrap gap-2">
              {productImages.map((file, idx) => (
                <div key={idx} className="position-relative" style={{ width: '100px' }}>
                  <img
                    src={URL.createObjectURL(file)}
                    alt={`Preview ${idx + 1}`}
                    className="img-thumbnail"
                    style={{ width: '100px', height: '100px', objectFit: 'cover' }}
                  />
                  <Button
                    variant="danger"
                    size="sm"
                    className="position-absolute top-0 end-0 rounded-circle p-0"
                    style={{ width: '24px', height: '24px', fontSize: '12px' }}
                    onClick={() => {
                      const newImages = [...productImages];
                      newImages.splice(idx, 1);
                      setProductImages(newImages);
                    }}
                  >
                    <FaTimes />
                  </Button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </Form.Group>
  </div>
</div>


            
            <h6 className="mt-4 mb-3">Specifications</h6>
            
            {specKeys.map((key, index) => (
              <Row key={index} className="mb-2">
                <Col>
                  <Form.Control
                    type="text"
                    placeholder="e.g. Material"
                    value={key}
                    onChange={(e) => handleSpecKeyChange(index, e.target.value)}
                  />
                </Col>
                <Col>
                  <Form.Control
                    type="text"
                    placeholder="e.g. Aluminum"
                    value={specValues[index]}
                    onChange={(e) => handleSpecValueChange(index, e.target.value)}
                  />
                </Col>
                {index < specKeys.length - 1 && (
                  <Col xs="auto">
                    <Button 
                      variant="outline-danger" 
                      onClick={() => {
                        setSpecKeys(specKeys.filter((_, i) => i !== index))
                        setSpecValues(specValues.filter((_, i) => i !== index))
                      }}
                    >
                      <FaTimes />
                    </Button>
                  </Col>
                )}
              </Row>
            ))}
            
            <Form.Text className="text-muted">
              Add specifications by filling out the key-value pairs above.
            </Form.Text>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={() => setShowProductModal(false)}>
              Cancel
            </Button>
            <Button 
              variant="primary" 
              type="submit"
              disabled={formLoading}
            >
              {formLoading ? 'Saving...' : (isEditMode ? 'Update Product' : 'Add Product')}
            </Button>
          </Modal.Footer>
        </Form>
      </Modal>
    </Container>
  )
}

export default VendorProductsPage