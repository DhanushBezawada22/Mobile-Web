// src/pages/AdminVendorsPage.jsx
import { useState, useEffect } from 'react'
import { Container, Row, Col, Card, Table, Button, Form, Badge, Modal, Alert } from 'react-bootstrap'
import { FaSearch, FaFilter, FaTimes, FaCheckCircle, FaTimesCircle, FaEye } from 'react-icons/fa'
import Breadcrumb from '../components/common/Breadcrumb'
import Sidebar from '../components/common/Sidebar'
import Loading from '../components/common/Loading'
import ErrorMessage from '../components/common/ErrorMessage'
import Pagination from '../components/common/Pagination'
import vendorService from '../services/vendorService'
import { formatDate } from '../utils/formatters'

const AdminVendorsPage = () => {
  const [vendors, setVendors] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [filters, setFilters] = useState({
    search: '',
    status: ''
  })
  const [showFilters, setShowFilters] = useState(false)
  const [pagination, setPagination] = useState({
    page: 1,
    pages: 1,
    total: 0
  })
  
  // Vendor Details Modal
  const [showVendorModal, setShowVendorModal] = useState(false)
  const [selectedVendor, setSelectedVendor] = useState(null)
  const [verifying, setVerifying] = useState(false)
  
  useEffect(() => {
    const fetchVendors = async () => {
      try {
        setLoading(true)
        const response = await vendorService.getAllVendors()
        setVendors(response.data)
        setPagination({
          page: 1,
          pages: Math.ceil(response.data.length / 10),
          total: response.data.length
        })
      } catch (err) {
        setError(err.response?.data?.error || 'Failed to load vendors')
        console.error('Error fetching vendors:', err)
      } finally {
        setLoading(false)
      }
    }
    
    fetchVendors()
  }, [])
  
  const handleFilterChange = (e) => {
    const { name, value } = e.target
    setFilters({
      ...filters,
      [name]: value
    })
  }
  
  const applyFilters = () => {
    // Reset to page 1 when filters change
    setPagination({
      ...pagination,
      page: 1
    })
    
    setShowFilters(false)
  }
  
  const resetFilters = () => {
    setFilters({
      search: '',
      status: ''
    })
  }
  
  const handlePageChange = (page) => {
    setPagination({
      ...pagination,
      page
    })
  }
  
  // Filter vendors client-side
  const filteredVendors = vendors.filter(vendor => {
    return (
      (filters.search === '' || 
       vendor.shopName.toLowerCase().includes(filters.search.toLowerCase()) ||
       (vendor.user?.name && vendor.user.name.toLowerCase().includes(filters.search.toLowerCase()))) &&
      (filters.status === '' || 
       (filters.status === 'verified' && vendor.isVerified) ||
       (filters.status === 'pending' && !vendor.isVerified))
    )
  })
  
  // Calculate paginated vendors
  const paginatedVendors = filteredVendors.slice(
    (pagination.page - 1) * 10,
    pagination.page * 10
  )
  
  const handleShowVendorModal = (vendor) => {
    setSelectedVendor(vendor)
    setShowVendorModal(true)
  }
  
  const handleVerifyVendor = async (id, isVerify) => {
    try {
      setVerifying(true)
      
      if (isVerify) {
        await vendorService.verifyVendor(id)
      } else {
        // For rejecting, we would ideally have an API endpoint
        // Since we don't, we'll just update the UI for demonstration
        console.log('Rejecting vendor is not implemented in the API')
      }
      
      // Update vendor in state
      setVendors(vendors.map(vendor => 
        vendor._id === id 
          ? { ...vendor, isVerified: isVerify } 
          : vendor
      ))
      
      // If viewing vendor details, update selected vendor
      if (selectedVendor && selectedVendor._id === id) {
        setSelectedVendor({ ...selectedVendor, isVerified: isVerify })
      }
    } catch (error) {
      console.error('Error updating vendor status:', error)
      // Show error message
    } finally {
      setVerifying(false)
    }
  }
  
  if (loading) return <Loading />
  if (error) return <ErrorMessage>{error}</ErrorMessage>
  
  return (
    <Container>
      <Breadcrumb items={[
        { label: 'Home', path: '/' },
        { label: 'Admin Dashboard', path: '/admin/dashboard' },
        { label: 'Vendors', path: null }
      ]} />
      
      <Row>
        <Col lg={3} className="mb-4">
          <Sidebar variant="admin" />
        </Col>
        
        <Col lg={9}>
          <Card className="border-0 shadow-sm mb-4">
            <Card.Body>
              <div className="d-flex justify-content-between align-items-center mb-3">
                <h3 className="mb-0">Manage Vendors</h3>
              </div>
              
              <div className="d-flex justify-content-between align-items-center mb-3">
                <div className="d-flex">
                  <Button 
                    variant="outline-secondary" 
                    className="me-2 d-flex align-items-center"
                    onClick={() => setShowFilters(!showFilters)}
                  >
                    <FaFilter className="me-1" /> Filters
                    {Object.values(filters).some(value => value !== '') && (
                      <Badge 
                        bg="primary" 
                        pill 
                        className="ms-1"
                      >
                        {Object.values(filters).filter(value => value !== '').length}
                      </Badge>
                    )}
                  </Button>
                  
                  <Form.Control
                    type="text"
                    placeholder="Search vendors..."
                    value={filters.search}
                    onChange={e => setFilters({...filters, search: e.target.value})}
                    className="me-2"
                    style={{ maxWidth: '250px' }}
                  />
                </div>
                
                <div>
                  <span className="text-muted me-2">
                    {filteredVendors.length} vendor(s)
                  </span>
                </div>
              </div>
              
              {showFilters && (
                <Card className="mb-3 border">
                  <Card.Body>
                    <div className="d-flex justify-content-between align-items-center mb-3">
                      <h5 className="mb-0">Filter Vendors</h5>
                      <Button 
                        variant="link" 
                        className="p-0 text-muted"
                        onClick={() => setShowFilters(false)}
                      >
                        <FaTimes />
                      </Button>
                    </div>
                    
                    <Row className="g-2">
                      <Col sm={6}>
                        <Form.Group controlId="statusFilter">
                          <Form.Label>Status</Form.Label>
                          <Form.Select
                            name="status"
                            value={filters.status}
                            onChange={handleFilterChange}
                          >
                            <option value="">All Status</option>
                            <option value="verified">Verified</option>
                            <option value="pending">Pending Verification</option>
                          </Form.Select>
                        </Form.Group>
                      </Col>
                    </Row>
                    
                    <div className="d-flex justify-content-end mt-3">
                      <Button 
                        variant="outline-secondary" 
                        className="me-2"
                        onClick={resetFilters}
                      >
                        Reset
                      </Button>
                      <Button 
                        variant="primary"
                        onClick={applyFilters}
                      >
                        Apply Filters
                      </Button>
                    </div>
                  </Card.Body>
                </Card>
              )}
              
              {filteredVendors.length === 0 ? (
                <div className="text-center py-5">
                  <FaStore size={50} className="text-muted mb-3" />
                  <h4>No Vendors Found</h4>
                  <p className="mb-4">
                    {Object.values(filters).some(value => value !== '')
                      ? 'Try changing your filters to see more vendors.'
                      : 'There are no vendors in the system.'}
                  </p>
                </div>
              ) : (
                <>
                  <div className="table-responsive">
                    <Table hover className="align-middle">
                      <thead>
                        <tr>
                          <th>Shop Name</th>
                          <th>Owner</th>
                          <th>Contact</th>
                          <th>Status</th>
                          <th>Joined</th>
                          <th>Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {paginatedVendors.map(vendor => (
                          <tr key={vendor._id}>
                            <td>
                              <div className="fw-bold">{vendor.shopName}</div>
                              <div className="small text-muted">
                                {vendor.specialties?.join(', ') || 'No specialties listed'}
                              </div>
                            </td>
                            <td>{vendor.user?.name || 'Unknown'}</td>
                            <td>
                              <div>{vendor.phone}</div>
                              <div className="small text-muted">{vendor.user?.email}</div>
                            </td>
                            <td>
                              {vendor.isVerified ? (
                                <Badge bg="success">Verified</Badge>
                              ) : (
                                <Badge bg="warning" text="dark">Pending Verification</Badge>
                              )}
                            </td>
                            <td>{formatDate(vendor.createdAt)}</td>
                            <td>
                              <Button 
                                variant="outline-secondary" 
                                size="sm" 
                                className="me-1"
                                onClick={() => handleShowVendorModal(vendor)}
                              >
                                <FaEye />
                              </Button>
                              
                              {!vendor.isVerified && (
                                <Button 
                                  variant="outline-success" 
                                  size="sm"
                                  className="me-1"
                                  onClick={() => handleVerifyVendor(vendor._id, true)}
                                  disabled={verifying}
                                >
                                  <FaCheckCircle />
                                </Button>
                              )}
                              
                              {vendor.isVerified && (
                                <Button 
                                  variant="outline-danger" 
                                  size="sm"
                                  onClick={() => handleVerifyVendor(vendor._id, false)}
                                  disabled={verifying}
                                >
                                  <FaTimesCircle />
                                </Button>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </Table>
                  </div>
                  
                  <Pagination 
                    page={pagination.page}
                    pages={pagination.pages}
                    onPageChange={handlePageChange}
                  />
                </>
              )}
            </Card.Body>
          </Card>
        </Col>
      </Row>
      
      {/* Vendor Details Modal */}
      <Modal
        show={showVendorModal}
        onHide={() => setShowVendorModal(false)}
        size="lg"
        centered
      >
        <Modal.Header closeButton>
          <Modal.Title>
            Vendor Details
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {selectedVendor && (
            <>
              <Row className="mb-4">
                <Col md={4} className="text-center">
                  <img 
                    src={selectedVendor.logo ? `/uploads/vendors/${selectedVendor.logo}` : '/placeholder.jpg'}
                    alt={selectedVendor.shopName}
                    className="img-fluid border rounded mb-2"
                    style={{ maxHeight: '150px', width: 'auto' }}
                  />
                  
                  <div className="mt-2">
                    {selectedVendor.isVerified ? (
                      <Badge bg="success" className="px-3 py-2">Verified Vendor</Badge>
                    ) : (
                      <Badge bg="warning" text="dark" className="px-3 py-2">Pending Verification</Badge>
                    )}
                  </div>
                </Col>
                
                <Col md={8}>
                  <h4>{selectedVendor.shopName}</h4>
                  
                  <div className="mb-2">
                    <strong>Owner:</strong> {selectedVendor.user?.name || 'Unknown'}
                  </div>
                  
                  <div className="mb-2">
                    <strong>Contact:</strong> {selectedVendor.phone}
                  </div>
                  
                  <div className="mb-2">
                    <strong>Email:</strong> {selectedVendor.user?.email || 'N/A'}
                  </div>
                  
                  <div className="mb-2">
                    <strong>Address:</strong> {selectedVendor.address}
                  </div>
                  
                  <div className="mb-2">
                    <strong>Joined:</strong> {formatDate(selectedVendor.createdAt)}
                  </div>
                  
                  {selectedVendor.specialties && selectedVendor.specialties.length > 0 && (
                    <div className="mb-2">
                      <strong>Specialties:</strong>
                      <div className="d-flex flex-wrap gap-1 mt-1">
                        {selectedVendor.specialties.map((specialty, index) => (
                          <Badge key={index} bg="light" text="dark" className="me-1">
                            {specialty}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </Col>
              </Row>
              
              <hr />
              
              <h5>Shop Description</h5>
              <p>{selectedVendor.description}</p>
              
              {!selectedVendor.isVerified && (
                <div className="mt-4">
                  <h5>Verification Action</h5>
                  <div className="d-flex gap-2 mt-2">
                    <Button 
                      variant="success" 
                      onClick={() => handleVerifyVendor(selectedVendor._id, true)}
                      disabled={verifying}
                    >
                      <FaCheckCircle className="me-1" /> Approve Vendor
                    </Button>
                    <Button 
                      variant="danger"
                      onClick={() => handleVerifyVendor(selectedVendor._id, false)}
                      disabled={verifying}
                    >
                      <FaTimesCircle className="me-1" /> Reject Vendor
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowVendorModal(false)}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </Container>
  )
}

export default AdminVendorsPage