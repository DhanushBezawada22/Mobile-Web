// src/pages/OrdersPage.jsx
import { useState, useEffect } from 'react'
import { Container, Row, Col, Card, Table, Badge, Button } from 'react-bootstrap'
import { Link } from 'react-router-dom'
import { FaEye, FaClipboardList } from 'react-icons/fa'
import Breadcrumb from '../components/common/Breadcrumb'
import Sidebar from '../components/common/Sidebar'
import Loading from '../components/common/Loading'
import ErrorMessage from '../components/common/ErrorMessage'
import orderService from '../services/orderService'
import { formatCurrency, formatDate, formatOrderStatus } from '../utils/formatters'

const OrdersPage = () => {
  const [orders, setOrders] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  
  useEffect(() => {
    const fetchOrders = async () => {
      try {
        setLoading(true)
        const response = await orderService.getMyOrders()
        setOrders(response.data)
      } catch (err) {
        setError(err.response?.data?.error || 'Failed to load orders')
        console.error('Error fetching orders:', err)
      } finally {
        setLoading(false)
      }
    }
    
    fetchOrders()
  }, [])
  
  return (
    <Container>
      <Breadcrumb items={[
        { label: 'Home', path: '/' },
        { label: 'My Orders', path: null }
      ]} />
      
      <Row>
        <Col lg={3} className="mb-4">
          <Sidebar variant="customer" />
        </Col>
        
        <Col lg={9}>
          <Card className="border-0 shadow-sm">
            <Card.Body>
              <h3 className="mb-4">My Orders</h3>
              
              {loading ? (
                <Loading />
              ) : error ? (
                <ErrorMessage>{error}</ErrorMessage>
              ) : orders.length === 0 ? (
                <div className="text-center py-5">
                  <FaClipboardList size={50} className="text-muted mb-3" />
                  <h4>No Orders Found</h4>
                  <p className="text-muted mb-4">You haven't placed any orders yet.</p>
                  <Button as={Link} to="/shop" variant="primary">
                    Start Shopping
                  </Button>
                </div>
              ) : (
                <div className="table-responsive">
                  <Table hover className="align-middle">
                    <thead>
                      <tr>
                        <th>Order ID</th>
                        <th>Date</th>
                        <th>Total</th>
                        <th>Status</th>
                        <th>Paid</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {orders.map((order) => {
                        const statusInfo = formatOrderStatus(order.status)
                        
                        return (
                          <tr key={order._id}>
                            <td>
                              <small className="text-muted">{order._id}</small>
                            </td>
                            <td>{formatDate(order.createdAt)}</td>
                            <td>{formatCurrency(order.totalPrice)}</td>
                            <td>
                              <Badge bg={statusInfo.color} className="px-3 py-2">
                                {statusInfo.label}
                              </Badge>
                            </td>
                            <td>
                              {order.isPaid ? (
                                <Badge bg="success">Paid</Badge>
                              ) : (
                                <Badge bg="warning" text="dark">Pending</Badge>
                              )}
                            </td>
                            <td>
                              <Button
                                as={Link}
                                to={`/order/${order._id}`}
                                variant="outline-primary"
                                size="sm"
                              >
                                <FaEye className="me-1" /> Details
                              </Button>
                            </td>
                          </tr>
                        )
                      })}
                    </tbody>
                  </Table>
                </div>
              )}
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  )
}

export default OrdersPage