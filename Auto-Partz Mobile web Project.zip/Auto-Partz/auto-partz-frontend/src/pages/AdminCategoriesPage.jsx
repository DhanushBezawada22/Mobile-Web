// src/pages/AdminCategoriesPage.jsx
import { useState, useEffect } from 'react'
import { Container, Row, Col, Card, Table, Button, Form, Modal, Alert, Tabs, Tab } from 'react-bootstrap'
import { FaPlus, FaEdit, FaTrash, FaTh, FaLayerGroup, FaExclamationTriangle } from 'react-icons/fa'
import Breadcrumb from '../components/common/Breadcrumb'
import Sidebar from '../components/common/Sidebar'
import Loading from '../components/common/Loading'
import ErrorMessage from '../components/common/ErrorMessage'
import categoryService from '../services/categoryService'

const AdminCategoriesPage = () => {
  const [categories, setCategories] = useState([])
  const [subcategories, setSubcategories] = useState({})
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [activeTab, setActiveTab] = useState('categories')
  
  // Category Form Modal
  const [showCategoryModal, setShowCategoryModal] = useState(false)
  const [categoryFormData, setCategoryFormData] = useState({
    name: '',
    description: ''
  })
  const [categoryFormErrors, setCategoryFormErrors] = useState({})
  const [isEditMode, setIsEditMode] = useState(false)
  const [formLoading, setFormLoading] = useState(false)
  
  // Subcategory Form Modal
  const [showSubcategoryModal, setShowSubcategoryModal] = useState(false)
  const [subcategoryFormData, setSubcategoryFormData] = useState({
    name: '',
    description: '',
    category: ''
  })
  const [subcategoryFormErrors, setSubcategoryFormErrors] = useState({})
  const [isSubcategoryEditMode, setIsSubcategoryEditMode] = useState(false)
  
  // Delete Confirmation Modal
  const [showDeleteModal, setShowDeleteModal] = useState(false)
  const [itemToDelete, setItemToDelete] = useState(null)
  const [deleteType, setDeleteType] = useState('category') // 'category' or 'subcategory'
  
  useEffect(() => {
    const fetchCategories = async () => {
      try {
        setLoading(true)
        
        // Fetch all categories
        const categoriesResponse = await categoryService.getCategories()
        setCategories(categoriesResponse.data)
        
        // Fetch subcategories for each category
        const subcategoriesData = {}
        
        await Promise.all(
          categoriesResponse.data.map(async (category) => {
            try {
              const subcategoriesResponse = await categoryService.getSubcategories(category._id)
              subcategoriesData[category._id] = subcategoriesResponse.data
            } catch (err) {
              console.error(`Error fetching subcategories for ${category.name}:`, err)
              subcategoriesData[category._id] = []
            }
          })
        )
        
        setSubcategories(subcategoriesData)
      } catch (err) {
        setError(err.response?.data?.error || 'Failed to load categories')
        console.error('Error fetching categories:', err)
      } finally {
        setLoading(false)
      }
    }
    
    fetchCategories()
  }, [])
  
  // Category Modal Handlers
  const resetCategoryForm = () => {
    setCategoryFormData({
      name: '',
      description: ''
    })
    setCategoryFormErrors({})
    setIsEditMode(false)
  }
  
  const handleShowCategoryModal = (category = null) => {
    resetCategoryForm()
    
    if (category) {
      // Edit mode
      setIsEditMode(true)
      setCategoryFormData({
        id: category._id,
        name: category.name,
        description: category.description || ''
      })
    }
    
    setShowCategoryModal(true)
  }
  
  const handleCategoryFormChange = (e) => {
    const { name, value } = e.target
    setCategoryFormData({
      ...categoryFormData,
      [name]: value
    })
    
    // Clear error for this field
    if (categoryFormErrors[name]) {
      setCategoryFormErrors({
        ...categoryFormErrors,
        [name]: null
      })
    }
  }
  
  const validateCategoryForm = () => {
    const errors = {}
    
    if (!categoryFormData.name.trim()) {
      errors.name = 'Category name is required'
    }
    
    setCategoryFormErrors(errors)
    return Object.keys(errors).length === 0
  }
  
  const handleSubmitCategoryForm = async (e) => {
    e.preventDefault()
    
    if (!validateCategoryForm()) {
      return
    }
    
    try {
      setFormLoading(true)
      
      if (isEditMode) {
        // Update category
        const { id, ...updateData } = categoryFormData
        const response = await categoryService.updateCategory(id, updateData)
        
        // Update category in state
        setCategories(categories.map(category => 
          category._id === id ? response.data : category
        ))
      } else {
        // Create category
        const response = await categoryService.createCategory(categoryFormData)
        
        // Add new category to state
        setCategories([...categories, response.data])
        
        // Initialize empty subcategories array
        setSubcategories({
          ...subcategories,
          [response.data._id]: []
        })
      }
      
      setShowCategoryModal(false)
      resetCategoryForm()
    } catch (error) {
      const errorMsg = error.response?.data?.error || 'An error occurred'
      setCategoryFormErrors({
        ...categoryFormErrors,
        general: errorMsg
      })
    } finally {
      setFormLoading(false)
    }
  }
  
  // Subcategory Modal Handlers
  const resetSubcategoryForm = () => {
    setSubcategoryFormData({
      name: '',
      description: '',
      category: ''
    })
    setSubcategoryFormErrors({})
    setIsSubcategoryEditMode(false)
  }
  
  const handleShowSubcategoryModal = (subcategory = null, categoryId = null) => {
    resetSubcategoryForm()
    
    if (subcategory) {
      // Edit mode
      setIsSubcategoryEditMode(true)
      setSubcategoryFormData({
        id: subcategory._id,
        name: subcategory.name,
        description: subcategory.description || '',
        category: subcategory.category
      })
    } else if (categoryId) {
      // New subcategory for specific category
      setSubcategoryFormData({
        ...subcategoryFormData,
        category: categoryId
      })
    }
    
    setShowSubcategoryModal(true)
  }
  
  const handleSubcategoryFormChange = (e) => {
    const { name, value } = e.target
    setSubcategoryFormData({
      ...subcategoryFormData,
      [name]: value
    })
    
    // Clear error for this field
    if (subcategoryFormErrors[name]) {
      setSubcategoryFormErrors({
        ...subcategoryFormErrors,
        [name]: null
      })
    }
  }
  
  const validateSubcategoryForm = () => {
    const errors = {}
    
    if (!subcategoryFormData.name.trim()) {
      errors.name = 'Subcategory name is required'
    }
    
    if (!subcategoryFormData.category) {
      errors.category = 'Parent category is required'
    }
    
    setSubcategoryFormErrors(errors)
    return Object.keys(errors).length === 0
  }
  
  const handleSubmitSubcategoryForm = async (e) => {
    e.preventDefault()
    
    if (!validateSubcategoryForm()) {
      return
    }
    
    try {
      setFormLoading(true)
      
      if (isSubcategoryEditMode) {
        // Update subcategory
        // Note: In a real app, you'd have an API endpoint for this
        // For now, we'll just update the state
        console.log('Update subcategory not implemented in the API')
        
        // Simulate updated subcategory
        const updatedSubcategory = {
          ...subcategoryFormData,
          _id: subcategoryFormData.id
        }
        
        // Update subcategory in state
        setSubcategories({
          ...subcategories,
          [subcategoryFormData.category]: subcategories[subcategoryFormData.category].map(
            sub => sub._id === subcategoryFormData.id ? updatedSubcategory : sub
          )
        })
      } else {
        // Create subcategory
        const response = await categoryService.createSubcategory(
          subcategoryFormData.category,
          {
            name: subcategoryFormData.name,
            description: subcategoryFormData.description
          }
        )
        
        // Add new subcategory to state
        setSubcategories({
          ...subcategories,
          [subcategoryFormData.category]: [
            ...(subcategories[subcategoryFormData.category] || []),
            response.data
          ]
        })
      }
      
      setShowSubcategoryModal(false)
      resetSubcategoryForm()
    } catch (error) {
      const errorMsg = error.response?.data?.error || 'An error occurred'
      setSubcategoryFormErrors({
        ...subcategoryFormErrors,
        general: errorMsg
      })
    } finally {
      setFormLoading(false)
    }
  }
  
  // Delete Modal Handlers
  const handleShowDeleteModal = (item, type) => {
    setItemToDelete(item)
    setDeleteType(type)
    setShowDeleteModal(true)
  }
  
  const handleDeleteItem = async () => {
    if (!itemToDelete) return
    
    try {
      if (deleteType === 'category') {
        await categoryService.deleteCategory(itemToDelete._id)
        
        // Remove category from state
        setCategories(categories.filter(cat => cat._id !== itemToDelete._id))
        
        // Remove associated subcategories
        const newSubcategories = { ...subcategories }
        delete newSubcategories[itemToDelete._id]
        setSubcategories(newSubcategories)
      } else {
        // Delete subcategory
        // Note: In a real app, you'd have an API endpoint for this
        console.log('Delete subcategory not implemented in the API')
        
        // Update state (remove subcategory)
        setSubcategories({
          ...subcategories,
          [itemToDelete.category]: subcategories[itemToDelete.category].filter(
            sub => sub._id !== itemToDelete._id
          )
        })
      }
      
      setShowDeleteModal(false)
      setItemToDelete(null)
    } catch (error) {
      console.error('Error deleting item:', error)
      // Show error message
    }
  }
  
  if (loading) return <Loading />
  if (error) return <ErrorMessage>{error}</ErrorMessage>
  
  return (
    <Container>
      <Breadcrumb items={[
        { label: 'Home', path: '/' },
        { label: 'Admin Dashboard', path: '/admin/dashboard' },
        { label: 'Categories', path: null }
      ]} />
      
      <Row>
        <Col lg={3} className="mb-4">
          <Sidebar variant="admin" />
        </Col>
        
        <Col lg={9}>
          <Card className="border-0 shadow-sm mb-4">
            <Card.Body>
              <Tabs
                activeKey={activeTab}
                onSelect={(k) => setActiveTab(k)}
                className="mb-4"
              >
                <Tab eventKey="categories" title="Categories">
                  <div className="d-flex justify-content-between align-items-center mb-3">
                    <h3 className="mb-0">Categories</h3>
                    
                    <Button 
                      variant="primary" 
                      onClick={() => handleShowCategoryModal()}
                    >
                      <FaPlus className="me-1" /> Add Category
                    </Button>
                  </div>
                  
                  {categories.length === 0 ? (
                    <div className="text-center py-5">
                      <FaTh size={50} className="text-muted mb-3" />
                      <h4>No Categories Found</h4>
                      <p className="mb-4">
                        Start by adding your first category.
                      </p>
                      <Button 
                        variant="primary"
                        onClick={() => handleShowCategoryModal()}
                      >
                        <FaPlus className="me-1" /> Add Category
                      </Button>
                    </div>
                  ) : (
                    <div className="table-responsive">
                      <Table hover className="align-middle">
                        <thead>
                          <tr>
                            <th>Name</th>
                            <th>Description</th>
                            <th>Subcategories</th>
                            <th>Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {categories.map(category => (
                            <tr key={category._id}>
                              <td>
                                <div className="fw-bold">{category.name}</div>
                              </td>
                              <td>
                                {category.description ? 
                                  (category.description.length > 100 ? 
                                    `${category.description.substring(0, 100)}...` : 
                                    category.description) : 
                                  'No description'}
                              </td>
                              <td>
                                <div className="d-flex align-items-center">
                                  <span className="me-2">
                                    {subcategories[category._id]?.length || 0}
                                  </span>
                                  
                                  <Button 
                                    variant="outline-primary" 
                                    size="sm"
                                    onClick={() => handleShowSubcategoryModal(null, category._id)}
                                  >
                                    <FaPlus className="me-1" /> Add
                                  </Button>
                                </div>
                              </td>
                              <td>
                                <Button 
                                  variant="outline-primary" 
                                  size="sm" 
                                  className="me-1"
                                  onClick={() => handleShowCategoryModal(category)}
                                >
                                  <FaEdit />
                                </Button>
                                <Button 
                                  variant="outline-danger" 
                                  size="sm"
                                  onClick={() => handleShowDeleteModal(category, 'category')}
                                >
                                  <FaTrash />
                                </Button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </Table>
                    </div>
                  )}
                </Tab>
                
                <Tab eventKey="subcategories" title="Subcategories">
                  <div className="d-flex justify-content-between align-items-center mb-3">
                    <h3 className="mb-0">Subcategories</h3>
                    
                    <Button 
                      variant="primary" 
                      onClick={() => handleShowSubcategoryModal()}
                      disabled={categories.length === 0}
                    >
                      <FaPlus className="me-1" /> Add Subcategory
                    </Button>
                  </div>
                  
                  {categories.length === 0 ? (
                    <Alert variant="info">
                      You need to create categories before adding subcategories.
                    </Alert>
                  ) : (
                    <>
                      {Object.values(subcategories).flat().length === 0 ? (
                        <div className="text-center py-5">
                          <FaLayerGroup size={50} className="text-muted mb-3" />
                          <h4>No Subcategories Found</h4>
                          <p className="mb-4">
                            Start by adding your first subcategory.
                          </p>
                          <Button 
                            variant="primary"
                            onClick={() => handleShowSubcategoryModal()}
                          >
                            <FaPlus className="me-1" /> Add Subcategory
                          </Button>
                        </div>
                      ) : (
                        <div className="table-responsive">
                          <Table hover className="align-middle">
                            <thead>
                              <tr>
                                <th>Name</th>
                                <th>Parent Category</th>
                                <th>Description</th>
                                <th>Actions</th>
                              </tr>
                            </thead>
                            <tbody>
                              {categories.map(category => (
                                subcategories[category._id]?.map(subcategory => (
                                  <tr key={subcategory._id}>
                                    <td>
                                      <div className="fw-bold">{subcategory.name}</div>
                                    </td>
                                    <td>{category.name}</td>
                                    <td>
                                      {subcategory.description ? 
                                        (subcategory.description.length > 100 ? 
                                          `${subcategory.description.substring(0, 100)}...` : 
                                          subcategory.description) : 
                                        'No description'}
                                    </td>
                                    <td>
                                      <Button 
                                        variant="outline-primary" 
                                        size="sm" 
                                        className="me-1"
                                        onClick={() => handleShowSubcategoryModal(subcategory)}
                                      >
                                        <FaEdit />
                                      </Button>
                                      <Button 
                                        variant="outline-danger" 
                                        size="sm"
                                        onClick={() => handleShowDeleteModal(subcategory, 'subcategory')}
                                      >
                                        <FaTrash />
                                      </Button>
                                    </td>
                                  </tr>
                                ))
                              ))}
                            </tbody>
                          </Table>
                        </div>
                      )}
                    </>
                  )}
                </Tab>
              </Tabs>
            </Card.Body>
          </Card>
        </Col>
      </Row>
      
      {/* Category Form Modal */}
      <Modal
        show={showCategoryModal}
        onHide={() => setShowCategoryModal(false)}
        centered
        backdrop="static"
      >
        <Modal.Header closeButton>
          <Modal.Title>
            {isEditMode ? 'Edit Category' : 'Add New Category'}
          </Modal.Title>
        </Modal.Header>
        <Form onSubmit={handleSubmitCategoryForm}>
          <Modal.Body>
            {categoryFormErrors.general && (
              <Alert variant="danger">{categoryFormErrors.general}</Alert>
            )}
            
            <Form.Group className="mb-3" controlId="categoryName">
              <Form.Label>Category Name</Form.Label>
              <Form.Control
                type="text"
                name="name"
                value={categoryFormData.name}
                onChange={handleCategoryFormChange}
                isInvalid={!!categoryFormErrors.name}
                placeholder="Enter category name"
              />
              <Form.Control.Feedback type="invalid">
                {categoryFormErrors.name}
              </Form.Control.Feedback>
            </Form.Group>
            
            <Form.Group className="mb-3" controlId="categoryDescription">
              <Form.Label>Description (Optional)</Form.Label>
              <Form.Control
                as="textarea"
                rows={3}
                name="description"
                value={categoryFormData.description}
                onChange={handleCategoryFormChange}
                placeholder="Enter category description"
              />
            </Form.Group>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={() => setShowCategoryModal(false)}>
              Cancel
            </Button>
            <Button 
              variant="primary" 
              type="submit"
              disabled={formLoading}
            >
              {formLoading ? 'Saving...' : (isEditMode ? 'Update Category' : 'Add Category')}
            </Button>
          </Modal.Footer>
        </Form>
      </Modal>
      
      {/* Subcategory Form Modal */}
      <Modal
        show={showSubcategoryModal}
        onHide={() => setShowSubcategoryModal(false)}
        centered
        backdrop="static"
      >
        <Modal.Header closeButton>
          <Modal.Title>
            {isSubcategoryEditMode ? 'Edit Subcategory' : 'Add New Subcategory'}
          </Modal.Title>
        </Modal.Header>
        <Form onSubmit={handleSubmitSubcategoryForm}>
          <Modal.Body>
            {subcategoryFormErrors.general && (
              <Alert variant="danger">{subcategoryFormErrors.general}</Alert>
            )}
            
            <Form.Group className="mb-3" controlId="subcategoryName">
              <Form.Label>Subcategory Name</Form.Label>
              <Form.Control
                type="text"
                name="name"
                value={subcategoryFormData.name}
                onChange={handleSubcategoryFormChange}
                isInvalid={!!subcategoryFormErrors.name}
                placeholder="Enter subcategory name"
              />
              <Form.Control.Feedback type="invalid">
                {subcategoryFormErrors.name}
              </Form.Control.Feedback>
            </Form.Group>
            
            <Form.Group className="mb-3" controlId="parentCategory">
              <Form.Label>Parent Category</Form.Label>
              <Form.Select
                name="category"
                value={subcategoryFormData.category}
                onChange={handleSubcategoryFormChange}
                isInvalid={!!subcategoryFormErrors.category}
                disabled={isSubcategoryEditMode} // Can't change parent category when editing
              >
                <option value="">Select Parent Category</option>
                {categories.map(category => (
                  <option key={category._id} value={category._id}>
                    {category.name}
                  </option>
                ))}
              </Form.Select>
              <Form.Control.Feedback type="invalid">
                {subcategoryFormErrors.category}
              </Form.Control.Feedback>
            </Form.Group>
            
            <Form.Group className="mb-3" controlId="subcategoryDescription">
              <Form.Label>Description (Optional)</Form.Label>
              <Form.Control
                as="textarea"
                rows={3}
                name="description"
                value={subcategoryFormData.description}
                onChange={handleSubcategoryFormChange}
                placeholder="Enter subcategory description"
              />
            </Form.Group>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={() => setShowSubcategoryModal(false)}>
              Cancel
            </Button>
            <Button 
              variant="primary" 
              type="submit"
              disabled={formLoading}
            >
              {formLoading ? 'Saving...' : (isSubcategoryEditMode ? 'Update Subcategory' : 'Add Subcategory')}
            </Button>
          </Modal.Footer>
        </Form>
      </Modal>
      
      {/* Delete Confirmation Modal */}
      <Modal
        show={showDeleteModal}
        onHide={() => setShowDeleteModal(false)}
        centered
        backdrop="static"
      >
        <Modal.Header closeButton>
          <Modal.Title>Confirm Deletion</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p>
            Are you sure you want to delete this {deleteType}?
          </p>
          {itemToDelete && (
            <div className="p-3 bg-light rounded">
              <div className="fw-bold">{itemToDelete.name}</div>
              {itemToDelete.description && (
                <div className="text-muted mt-1">
                  {itemToDelete.description.length > 100 ? 
                    `${itemToDelete.description.substring(0, 100)}...` : 
                    itemToDelete.description}
                </div>
              )}
            </div>
          )}
          
          {deleteType === 'category' && itemToDelete && subcategories[itemToDelete._id]?.length > 0 && (
            <Alert variant="warning" className="mt-3">
              <FaExclamationTriangle className="me-2" />
              This category has {subcategories[itemToDelete._id]?.length} subcategories.
              Deleting it will also delete all associated subcategories.
            </Alert>
          )}
          
          <Alert variant="danger" className="mt-3">
            <FaExclamationTriangle className="me-2" />
            This action cannot be undone.
          </Alert>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowDeleteModal(false)}>
            Cancel
          </Button>
          <Button variant="danger" onClick={handleDeleteItem}>
            Delete {deleteType === 'category' ? 'Category' : 'Subcategory'}
          </Button>
        </Modal.Footer>
      </Modal>
    </Container>
  )
}

export default AdminCategoriesPage